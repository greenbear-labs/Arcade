using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// The spell book the Aspidochelone gives you: a key item on your tool dial. Hold it
    /// and press F to throw a small fireball the way you're facing. It flies up to 3
    /// tiles and bursts on the first thing it hits (a slime, a pot), or at the end of
    /// its flight. It glows as it goes, so it lights up the dark for a moment.
    /// </summary>
    public class Spells : MonoBehaviour
    {
        const float Range = 3f, Speed = 10f, Cooldown = 0.45f, HitRadius = 0.4f;
        const int Damage = 2;

        Sprite[] _ball, _burst;
        float _cooldown;

        public void Build()
        {
            _ball = Art.Strip("fireball", 8, 8, new Vector2(0.5f, 0.5f));
            _burst = Art.Strip("fireburst", 16, 16, new Vector2(0.5f, 0.5f));
        }

        void Update()
        {
            _cooldown -= Time.deltaTime;
            var player = PlayerController.Instance;
            if (player == null || _ball == null || Inventory.SelectedItem != Items.SpellBook) return;
            if (Hud.Busy || player.Locked || player.IsAttacking || Creatures.Riding || Creatures.WantUse) return;
            if (!GameInput.FishPressed() || _cooldown > 0f) return;
            _cooldown = Cooldown;
            var go = new GameObject("Fireball");
            go.transform.SetParent(transform, false);
            go.AddComponent<Fireball>().Launch(player, Art.Dir(player.Facing), _ball, _burst);
        }

        class Fireball : MonoBehaviour
        {
            PlayerController _player;
            Vector2 _dir, _pos;
            float _flown, _clock, _burstT = -1f;
            Sprite[] _ball, _burst;
            SpriteRenderer _sprite;

            public void Launch(PlayerController player, Vector2 dir, Sprite[] ball, Sprite[] burst)
            {
                _player = player;
                _dir = dir;
                _ball = ball;
                _burst = burst;
                _pos = player.Center + dir * 0.45f;
                _sprite = gameObject.AddComponent<SpriteRenderer>();
                _sprite.sprite = ball[0];
                transform.position = _pos;
                Lighting.Add(this, () => _pos, () => _burstT >= 0f ? 2.2f * (1f - _burstT) : 1.6f);
                Place();
            }

            void Update()
            {
                _clock += Time.deltaTime;
                if (_burstT >= 0f)
                {
                    _burstT += Time.deltaTime / 0.3f;
                    if (_burstT >= 1f || _burst == null) { Destroy(gameObject); return; }
                    _sprite.sprite = _burst[Mathf.Min(_burst.Length - 1, Mathf.FloorToInt(_burstT * _burst.Length))];
                    return;
                }
                float step = Speed * Time.deltaTime;
                _pos += _dir * step;
                _flown += step;
                _sprite.sprite = _ball[Mathf.FloorToInt(_clock * 14f) % _ball.Length];
                Place();
                if (HitSomething() || _flown >= Range) _burstT = 0f;
            }

            // Drawn by its shadow line on the ground (0.4 below), so it sorts among things sensibly.
            void Place()
            {
                transform.position = _pos;
                _sprite.sortingOrder = YSort.Order(_pos.y - 0.4f) + 1;
            }

            bool HitSomething()
            {
                foreach (var col in Physics2D.OverlapCircleAll(_pos - new Vector2(0f, 0.3f), HitRadius))
                {
                    if (_player != null && col.attachedRigidbody != null && col.attachedRigidbody.gameObject == _player.gameObject) continue;
                    var target = col.GetComponentInParent<IHittable>();
                    if (target == null) continue;
                    target.Hit(_player != null ? _player.Center : _pos - _dir, Damage);
                    return true;
                }
                return false;
            }
        }
    }
}
