using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// The forest south of town. A lane runs down from the road, past the workshops,
    /// through a gap in the trees, and a trail winds on to three clearings: the
    /// Ventara's huts, a ring of toadstools and standing stones, and a great old oak.
    /// The world reads this to lay the ground and the trees; anywhere not on the trail
    /// or in a clearing is too thick with trees to walk through.
    /// </summary>
    public static class Forest
    {
        /// <summary>The forest's west and east edges (the trees go on beyond, for looks).</summary>
        public const int Left = 48, Right = 108;

        /// <summary>The clearings: centre and half-size.</summary>
        public static readonly (Vector2 at, Vector2 size)[] Groves =
        {
            (new Vector2(60f, -14f), new Vector2(7f, 5f)),      // the Ventara's huts
            (new Vector2(86f, -9f), new Vector2(5f, 4f)),       // the toadstool ring
            (new Vector2(96f, -18f), new Vector2(6f, 4.5f)),    // the old oak
        };
        public static Vector2 Huts => Groves[0].at;
        public static Vector2 Ring => Groves[1].at + new Vector2(0.5f, 1.8f);
        public static Vector2 Oak => Groves[2].at;

        /// <summary>The trail, as a few bends from the gate. It forks a little way in.</summary>
        static readonly Vector2[][] Trails =
        {
            new[] { new Vector2(70f, 0.5f), new Vector2(70f, -4f), new Vector2(66f, -7f), new Vector2(62f, -10f), new Vector2(60f, -13f) },
            new[] { new Vector2(70f, -4f), new Vector2(76f, -6f), new Vector2(81f, -9f), new Vector2(86f, -10.5f) },
            new[] { new Vector2(86f, -10.5f), new Vector2(89f, -13f), new Vector2(92f, -16f), new Vector2(96f, -18f) },
        };

        static float TrailDistance(Vector2 p)
        {
            float best = float.MaxValue;
            foreach (var trail in Trails) best = Mathf.Min(best, Town.Wander(p, trail));
            return best;
        }

        static bool InGrove(Vector2 p, float grow = 0f)
        {
            foreach (var (at, size) in Groves)
            {
                float dx = (p.x - at.x) / (size.x + grow), dy = (p.y - at.y) / (size.y + grow);
                if (dx * dx + dy * dy <= 1f) return true;
            }
            return false;
        }

        /// <summary>Can you walk on this tile? (Only below the map's old south edge.)</summary>
        public static bool IsOpen(int x, int y)
        {
            if (y >= 0 || x < Left || x > Right) return false;
            var p = new Vector2(x + 0.5f, y + 0.5f);
            return TrailDistance(p) <= 1.6f || InGrove(p);
        }

        /// <summary>Is this tile the trodden dirt of the trail?</summary>
        public static bool IsTrail(int x, int y) => y < 0 && x >= Left && x <= Right && TrailDistance(new Vector2(x + 0.5f, y + 0.5f)) <= 1.05f;

        /// <summary>Spots for the forest's trees: thick everywhere you can't walk, thinner far from the town.</summary>
        public static List<Vector2> TreeSpots(int mapLeft, int mapRight, int bottom)
        {
            var rng = new System.Random(29);
            var spots = new List<Vector2>();
            for (int y = -1; y >= bottom; y -= 2)
            for (int x = mapLeft + 1; x < mapRight; x += 2)
            {
                // Away from the forest, only the rows you might glimpse from the edge of the map.
                bool near = x >= Left - 12 && x <= Right + 12;
                if (!near && y < -7) continue;
                float jx = (float)rng.NextDouble() * 1.2f - 0.6f, jy = (float)rng.NextDouble() * 0.8f - 0.4f;
                var at = new Vector2(x + 0.5f + jx, y + 0.1f + jy);
                int cx = Mathf.FloorToInt(at.x), cy = Mathf.FloorToInt(at.y);
                if (IsOpen(cx, cy) || IsOpen(cx, cy - 1) || IsOpen(cx - 1, cy) || IsOpen(cx + 1, cy)) continue;
                spots.Add(at);
            }
            return spots;
        }

        /// <summary>What the Ventara has heard on the wind. The first time is a hello.</summary>
        public static readonly string[] Rumours =
        {
            "Oh! A ground-walker! I'm Ventara folk. We live up in the high branches, mostly. Want to hear what the wind's been saying?",
            "Ever seen tracks that just stop? Right at a stone wall, or a thorn hedge? That's an Enfield. Fox's head, eagle's talons, feathered wings. They step between things.",
            "When autumn turns to winter, the Enfields go quiet for twenty-one days. Nobody knows why. I asked one. It didn't answer. Obviously.",
            "Some Enfields glow like lanterns, some trail embers, some ride the wind. Light-Bringer, Ember-Wing, Zephyr-Tail. I've only ever found a feather.",
            "My gran saw a Peryton once. Stag's head, a hawk's wings, and its shadow was the shadow of a man. She stood very, very still. That's how you make friends with one, she says.",
            "Up in the high peaks, once every ten years, the Perytons weep. Gran says if you ever hear it, you'll know what it is. I hope I'm awake for it.",
            "There's a kind of Peryton with mossy fur and antlers like iron-wood. Earth-Bound, they're called. They walk the forest floor instead of flying. Brave, if you ask me.",
            "Something's been napping in the orchards. A mountain lion's body and an elephant's trunk. A Baku! They adore star-apples. Leave one out and listen for the purr.",
            "They say a Baku eats bad dreams. I had a nightmare about a Brawler Frog last week and woke up feeling lovely. Coincidence? Hmm.",
            "The Moss-Back Baku are the forest's gardeners. If you ever find a clearing that's a little too tidy, one's been through it.",
            "If you meet a frog the size of a gorilla asking for bananas, that's a Brawler Frog. We Ventara don't deal with them. They think we're spicy dragonflies.",
            "You can't catch any of them, you know. Mythical creatures choose you. All you can do is be the sort of person worth choosing.",
            "That ring of toadstools east of here? Don't step inside it on a full moon. Or do. I'm not your mother.",
            "The great oak, down past the toadstools, is older than the valley's name. Things sleep in its roots. Friendly things. Mostly.",
            "My cousin plays her flute all day by the huts. She'd swap it for a bit of fruit, I bet. She's always hungry, that one.",
            "A tune in the toadstool ring calls the Snawfus out of the trees. Antlers like little trees, moss down its back. Flowers grow where it steps!",
            "Heard there's a cave up on the mountain so dark you can't see your own feet. If I went in there I'd want something that glows.",
            "That island in the meadow lake? It breathes. Watch the bubbles past its east shore. Gran says the old ones wake for music.",
        };

        /// <summary>Every so often, until you've bonded with it, the Ventara tells you about the oak's Enfield.</summary>
        public static readonly string[] EnfieldTips =
        {
            "There's a Light-Bringer Enfield living in the hollow of the great oak. White as snow, glows like a lantern. It only comes out at night, when the woods are quiet.",
            "Want to meet the oak's Enfield? Stand by the tree after dark and don't move a muscle. Not a twitch. It peeks out when it thinks nobody's looking.",
            "Enfields are mad for fish. Golden ones, especially. Offer a Light-Bringer a golden trout and it might just decide you're worth following.",
        };
    }
}
