using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// The island in the meadow lake is no island: it's the back of an Aspidochelone,
    /// an ancient island turtle. A causeway of stones runs out to it from the south
    /// shore. Out past the island's east shore, bubbles rise where its head lies under
    /// the water. Stand on the island as near the bubbles as you can and play the
    /// flute, and it raises its head and speaks: you must find balance with the
    /// creatures of Mythica. The first time, it gives you an old spell book that
    /// throws small fireballs (see Spells).
    /// </summary>
    public class Aspidochelone : MonoBehaviour
    {
        enum State { Down, Rising, Up, Sinking }

        // The island (its shell), the causeway, and where its head is.
        public static readonly Vector2 Island = new Vector2(12f, 39.2f);
        static readonly Vector2 IslandSize = new Vector2(2.9f, 1.95f);
        public static readonly Vector2 Bubbles = Island + new Vector2(IslandSize.x + 2.4f, 0f);
        const float HearRange = 3.6f, TuneToWake = 2f, RiseTime = 1.6f, StayUp = 8f;

        public static bool OnIsland(Vector2 at, float margin)
        {
            float px = (at.x - Island.x) / (IslandSize.x + margin), py = (at.y - Island.y) / (IslandSize.y + margin);
            return px * px + py * py <= 1f;
        }

        /// <summary>The stones from the south shore out to the island: two tiles wide.</summary>
        public static bool OnCauseway(Vector2 at) => Mathf.Abs(at.x - Island.x) < 1f && at.y < Island.y;

        static Aspidochelone _instance;
        /// <summary>It has given you the spell book. (Kept in the save.)</summary>
        public static bool Gifted
        {
            get => _instance != null && _instance._gifted;
            set { if (_instance != null) _instance._gifted = value; }
        }

        bool _gifted;
        State _state = State.Down;
        float _t, _clock;
        Sprite[] _head, _bubbles;
        SpriteRenderer _headSprite, _bubbleSprite;

        static readonly string[] FirstWords =
        {
            "...Hrrrmmm. A song. It has been a long age since anyone played for me.",
            "I am the Aspidochelone. This lake was a puddle when I lay down in it, and the grass on my back has grown for a thousand summers.",
            "The creatures of Mythica are stirring again. Jackalopes, Enfields, Snawfus... and older, stranger things. They choose whom they trust.",
            "Listen well, little farmer. You must find balance with the creatures of Mythica. Not to own them. Never that. To live beside them.",
            "Take this. An old book of embers, dropped on my shell by a wizard who swam badly. Small fire, for a small farmer. Use it kindly.",
        };

        static readonly string[] LaterWords =
        {
            "...Hrrrmmm. The flute again. You have not forgotten me.",
            "Balance, little farmer. Every creature you befriend is a weight on the scale. Keep it level.",
        };

        public void Build(Transform parent)
        {
            _instance = this;
            // The shell's rim and flippers, in the water round the grassy island.
            var rim = new GameObject("Aspidochelone shell").AddComponent<SpriteRenderer>();
            rim.transform.SetParent(parent, false);
            rim.transform.position = Island;
            rim.sprite = Art.Single("aspido_rim", new Vector2(0.5f, 0.5f));
            rim.sortingOrder = FarmDemoWorld.ShadowOrder - 990;     // over the water and grass tiles, under everything standing
            _head = Art.Strip("aspido_head", 32, 48);
            _bubbles = Art.Strip("bubbles", 8, 8, new Vector2(0.5f, 0.5f));
            _headSprite = new GameObject("Aspidochelone head").AddComponent<SpriteRenderer>();
            _headSprite.transform.SetParent(parent, false);
            _headSprite.transform.position = Bubbles + new Vector2(0f, -0.35f);
            _headSprite.sortingOrder = YSort.Order(Bubbles.y - 0.35f);
            _headSprite.enabled = false;
            _bubbleSprite = new GameObject("Bubbles").AddComponent<SpriteRenderer>();
            _bubbleSprite.transform.SetParent(parent, false);
            _bubbleSprite.transform.position = Bubbles;
            _bubbleSprite.sortingOrder = FarmDemoWorld.ShadowOrder - 980;
        }

        void OnDestroy()
        {
            if (_instance == this) _instance = null;
        }

        void Update()
        {
            _clock += Time.deltaTime;
            _t += Time.deltaTime;
            var player = PlayerController.Instance;

            // Bubbles while its head is under; they come in little bursts.
            bool bubbling = _state == State.Down && _bubbles != null && Mathf.Repeat(_clock, 3f) < 2.2f;
            _bubbleSprite.enabled = bubbling;
            if (bubbling)
            {
                _bubbleSprite.sprite = _bubbles[Mathf.FloorToInt(_clock * 5f) % _bubbles.Length];
                _bubbleSprite.transform.position = Bubbles + new Vector2(Mathf.Sin(_clock * 1.3f) * 0.15f, 0f);
            }

            switch (_state)
            {
                case State.Down: Listen(player); break;
                case State.Rising: if (_t >= RiseTime) Speak(); break;
                case State.Up: StayAwake(player); break;
                case State.Sinking: if (_t >= RiseTime) { _state = State.Down; _t = 0f; } break;
            }
            Draw();
        }

        static bool Near(PlayerController player)
        {
            if (player == null) return false;
            Vector2 feet = player.transform.position;
            return OnIsland(feet, 0.4f) && Vector2.Distance(feet, Bubbles) <= HearRange;
        }

        // A tune played from the island's edge, close to where it sleeps, wakes it.
        void Listen(PlayerController player)
        {
            if (!Flute.Playing || Flute.PlayingFor < TuneToWake || !Near(player)) return;
            Flute.StopPlaying();
            _state = State.Rising;
            _t = 0f;
            Hud.Toast("The water churns...", 1.5f);
        }

        void Speak()
        {
            _state = State.Up;
            _t = 0f;
            Hud.OpenDialogue(this, "Aspidochelone", _gifted ? LaterWords : FirstWords, _gifted ? null : (System.Action)Gift);
        }

        void Gift()
        {
            _gifted = true;
            _t = 0f;
            Inventory.Add(Items.SpellBook);
            Toolbelt.Pick(Items.SpellBook);
            Hud.ShowPopup(Items.SpellBook.Icon, "You got the Spell Book!",
                "A key item, on your tool dial. Hold it and press F to throw a small fireball, up to 3 tiles ahead.");
        }

        void StayAwake(PlayerController player)
        {
            if (Hud.Speaker == (object)this)
            {
                _t = 0f;
                if (GameInput.TalkPressed() || GameInput.FishPressed()) Hud.AdvanceDialogue();
                return;
            }
            if (Hud.Busy) return;
            if (Near(player))
            {
                Hud.SetPrompt("E  Talk to the Aspidochelone");
                if (GameInput.TalkPressed()) { Speak(); return; }
            }
            if (_t >= StayUp) { _state = State.Sinking; _t = 0f; }
        }

        void Draw()
        {
            if (_head == null) return;
            int frame;
            if (_state == State.Down) { _headSprite.enabled = false; return; }
            float k = Mathf.Clamp01(_t / RiseTime);
            if (_state == State.Rising) frame = Mathf.Min(3, Mathf.FloorToInt(k * 4f));
            else if (_state == State.Sinking) frame = Mathf.Max(0, 3 - Mathf.FloorToInt(k * 4f));
            else frame = Hud.Speaker == (object)this && Mathf.FloorToInt(_clock * 6f) % 2 == 0 ? 4 : 3;     // its beak moves as it talks
            _headSprite.enabled = true;
            _headSprite.sprite = _head[Mathf.Min(frame, _head.Length - 1)];
        }
    }
}
