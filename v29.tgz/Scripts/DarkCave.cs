using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

namespace FarmDemo
{
    /// <summary>
    /// The dark cave, the third cave in the mountain cliff, between the mine and the
    /// crystal cave. A sign out front warns that it's pitch dark inside. In there you
    /// can only see a little circle of ground round your feet (see Lighting): a maze
    /// of tunnels, a couple of slimes and a few faintly glowing mushrooms. Bring the
    /// Enfield along and its glow lights up a good way round you. At the far end is
    /// an old chest (it opens once). Built off to the side of the map, like the others.
    /// </summary>
    public class DarkCave : MonoBehaviour
    {
        // Outside: the cave sprite stands with its bottom-centre here.
        public static readonly Vector2 Mouth = new Vector2(-11f, 22f);
        static readonly Vector2 SignSpot = Mouth + new Vector2(2.0f, -1.2f);
        // Inside: the map below, its bottom-left corner here.
        public static readonly Vector2 RoomOrigin = new Vector2(2000f, 2f);
        const int GemsInChest = 8, GoldInChest = 500;
        const float SightRadius = 1.4f, MushroomGlow = 1.1f;

        // # rock, . floor, m glowing mushrooms, C the chest, S a slime, X where you come in,
        // E the way out (daylight, just behind where you come in).
        static readonly string[] Map =
        {
            "################################",
            "#C..#######...m....#####...#####",
            "#...#######.######.#####.#.#####",
            "##.########.######.......#.....#",
            "##.....m###.##########.#####.#.#",
            "######.####.....S.####.#.....#.#",
            "######.#######.##.####.#.#####.#",
            "#.....m........#..#....#.#.....#",
            "#.#############..##.####.#.#####",
            "#.#....m......#.###.#....#....m#",
            "#.#.#########.#.....#.##########",
            "#...#.......#.###.###.#........#",
            "#####.#####.#...#.....#.######.#",
            "#.....#...#.###.#######.#....#.#",
            "#.#####.#.#...#.........#.##.#.#",
            "#.......#.###.#########...#....#",
            "#########...#.......S.#####.####",
            "###########.#########.......####",
            "###########.....X....###########",
            "################E###############",
        };

        static readonly Color32 CaveBackground = new Color32(0x05, 0x04, 0x08, 0xff);
        static int Width => Map[0].Length;
        static int Height => Map.Length;

        public static bool Inside { get; private set; }
        /// <summary>Has the chest at the far end been opened? (Kept in the save.)</summary>
        public static bool ChestOpened
        {
            get => _instance != null && _instance._chestOpened;
            set { if (_instance != null) { _instance._chestOpened = value; _instance.RefreshChest(); } }
        }

        static DarkCave _instance;
        bool _chestOpened;
        Vector2 _arrival, _chestSpot, _exit;
        SpriteRenderer _chest, _mouthPrompt;
        Sprite[] _chestFrames, _slimeFrames;
        readonly List<Vector2> _slimeSpots = new List<Vector2>();
        Transform _slimes;

        static Vector2 Local(int col, int row) => RoomOrigin + new Vector2(col, Height - 1 - row);

        public void Build(Transform parent)
        {
            _instance = this;
            Inside = false;
            _slimeFrames = Art.Strip("slime", 16, 16);
            _chestFrames = Art.Strip("cavechest", 16, 16);

            // Outside: the mouth in the cliff, cobwebbed and black, and the warning sign.
            var cave = new GameObject("Dark cave (outside)");
            cave.transform.SetParent(parent, false);
            cave.transform.position = Mouth;
            cave.AddComponent<SpriteRenderer>().sprite = Art.Single("cave3");
            cave.AddComponent<YSort>();
            FarmDemoWorld.Tall(cave);
            var rock = cave.AddComponent<BoxCollider2D>();
            rock.size = new Vector2(2.7f, 1.3f);
            rock.offset = new Vector2(0f, 0.65f);
            var sign = new GameObject("Warning sign");
            sign.transform.SetParent(parent, false);
            sign.transform.position = SignSpot;
            sign.AddComponent<SpriteRenderer>().sprite = Art.Single("warnsign");
            sign.AddComponent<YSort>();
            var post = sign.AddComponent<BoxCollider2D>();
            post.size = new Vector2(0.4f, 0.25f);
            post.offset = new Vector2(0f, 0.12f);
            _mouthPrompt = new GameObject("Prompt").AddComponent<SpriteRenderer>();
            _mouthPrompt.transform.SetParent(transform, false);
            _mouthPrompt.sprite = Art.Single("key_e", new Vector2(0.5f, 0f));
            _mouthPrompt.sortingOrder = 32000;
            _mouthPrompt.enabled = false;

            // Inside: rock and floor as tiles; the rock is solid.
            var tiles = Art.Strip("cave_tiles", 16, 16, new Vector2(0.5f, 0.5f));
            var grid = new GameObject("Dark cave (inside)", typeof(Grid));
            grid.transform.SetParent(parent, false);
            grid.transform.position = RoomOrigin;
            var floor = NewTilemap(grid.transform, "Floor", -30000);
            var walls = NewTilemap(grid.transform, "Rock (solid)", -29999);
            walls.gameObject.AddComponent<TilemapCollider2D>();
            Tile Make(int i, bool solid)
            {
                var t = ScriptableObject.CreateInstance<Tile>();
                t.sprite = tiles != null && i < tiles.Length ? tiles[i] : null;
                t.colliderType = solid ? Tile.ColliderType.Grid : Tile.ColliderType.None;
                return t;
            }
            Tile floorA = Make(0, false), floorB = Make(1, false), wall = Make(2, true);
            var mushroom = Art.Single("mushroom");
            var rng = new System.Random(23);

            for (int row = 0; row < Height; row++)
            for (int col = 0; col < Width; col++)
            {
                char c = Map[row][col];
                var cell = new Vector3Int(col, Height - 1 - row, 0);
                if (c == '#') { walls.SetTile(cell, wall); continue; }
                floor.SetTile(cell, rng.Next(4) == 0 ? floorB : floorA);
                Vector2 at = Local(col, row) + new Vector2(0.5f, 0.1f);
                if (c == 'm' && mushroom != null)
                {
                    var sr = Decor(grid.transform, mushroom, at, false);
                    Vector2 glowAt = at + new Vector2(0f, 0.3f);
                    Lighting.Add(sr, () => glowAt, () => Inside ? MushroomGlow : 0f);
                }
                else if (c == 'S') _slimeSpots.Add(at + new Vector2(0f, 0.1f));
                else if (c == 'X') _arrival = at + new Vector2(0f, 0.3f);
                else if (c == 'E')
                {
                    // Daylight spilling in down the steps: always lit, so you can always find the way out.
                    _exit = Local(col, row) + new Vector2(0.5f, 0.5f);
                    var steps = Decor(grid.transform, Art.Single("caveexit", new Vector2(0.5f, 0.5f)), _exit, false);
                    steps.sortingOrder = -29998;
                    Destroy(steps.GetComponent<YSort>());
                    Vector2 glowAt = _exit + new Vector2(0f, 0.2f);
                    Lighting.Add(steps, () => glowAt, () => Inside ? 2.2f : 0f);
                }
                else if (c == 'C')
                {
                    _chestSpot = at;
                    _chest = Decor(grid.transform, _chestFrames?[0], at, true);
                }
            }

            // Your own little circle of sight in there.
            Lighting.Add(this, () => PlayerController.Instance != null ? PlayerController.Instance.Center : Vector2.zero,
                () => Inside ? SightRadius : 0f);
            GameClock.NewDay += Morning;
        }

        static Tilemap NewTilemap(Transform parent, string name, int order)
        {
            var go = new GameObject(name, typeof(Tilemap), typeof(TilemapRenderer));
            go.transform.SetParent(parent, false);
            go.GetComponent<TilemapRenderer>().sortingOrder = order;
            return go.GetComponent<Tilemap>();
        }

        static SpriteRenderer Decor(Transform parent, Sprite sprite, Vector2 at, bool solid)
        {
            var go = new GameObject(sprite != null ? sprite.name : "Decor");
            go.transform.SetParent(parent, false);
            go.transform.position = at;
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            go.AddComponent<YSort>();
            if (solid)
            {
                var box = go.AddComponent<BoxCollider2D>();
                box.size = new Vector2(0.8f, 0.45f);
                box.offset = new Vector2(0f, 0.22f);
            }
            return sr;
        }

        void RefreshChest()
        {
            if (_chest != null && _chestFrames != null) _chest.sprite = _chestFrames[_chestOpened ? 1 : 0];
        }

        void OnDestroy()
        {
            GameClock.NewDay -= Morning;
            if (_instance == this) { _instance = null; Inside = false; }
        }

        // You always wake up at home.
        void Morning()
        {
            Inside = false;
            ClearSlimes();
        }

        void ClearSlimes()
        {
            if (_slimes != null) Destroy(_slimes.gameObject);
            _slimes = null;
        }

        void GoIn()
        {
            Inside = true;
            ClearSlimes();
            _slimes = new GameObject("Dark cave slimes").transform;
            _slimes.SetParent(transform, false);
            foreach (var spot in _slimeSpots)
            {
                var slime = FarmDemoWorld.SpawnSlime(_slimes, spot, _slimeFrames);
                if (slime == null) continue;
                slime.health = 3;
                slime.tint = new Color(0.55f, 0.5f, 0.7f);
            }
            RefreshChest();
            // The camera may show a little below the cave, so the way out sits clear of the hotbar.
            Home.Move(_arrival, Facing.Up, new Rect(RoomOrigin.x, RoomOrigin.y - 2.5f, Width, Height + 2.5f), CaveBackground);
            Hud.Toast(Enfield.Following ? "The Enfield's glow fills the tunnel. You can see! The way out is the daylight behind you."
                : "It's pitch black. You can barely see your own feet... The way out is the daylight just behind you.", 3.5f);
        }

        static void Leave()
        {
            Inside = false;
            if (_instance != null) _instance.ClearSlimes();
            Home.Move(Mouth + new Vector2(0f, -0.6f), Facing.Down, FarmDemoWorld.OutdoorBounds, Home.OutdoorBackground);
        }

        /// <summary>Fainted in the dark: Dot finds you and walks you out.</summary>
        public static void CarryOut()
        {
            Hud.Toast("You fainted! Dot came looking with a lantern and walked you out.", 3.5f);
            Hud.Transition(Leave);
        }

        void Update()
        {
            _mouthPrompt.enabled = false;
            var player = PlayerController.Instance;
            if (player == null || Hud.Busy || player.Locked || player.IsAttacking) return;
            Vector2 feet = player.transform.position;

            if (!Inside)
            {
                if (Home.Inside || Mine.Inside || Cavern.Inside || Town.Inside) return;
                // The sign.
                if (Vector2.Distance(feet + new Vector2(0f, 0.15f) + Art.Dir(player.Facing) * 0.5f, SignSpot + new Vector2(0f, 0.3f)) < 0.8f)
                {
                    Hud.SetPrompt("DANGER: DARK CAVE. Pitch black inside. Don't go in without a light!");
                    return;
                }
                if (Vector2.Distance(feet, Mouth + new Vector2(0f, -0.3f)) > 0.8f || player.Facing != Facing.Up) return;
                _mouthPrompt.enabled = true;
                _mouthPrompt.transform.position = Mouth + new Vector2(0f, 2.8f + (Mathf.Sin(Time.time * 5f) > 0f ? 1f / FarmDemoConfig.PixelsPerUnit : 0f));
                Hud.SetPrompt(Enfield.Following ? "E  Go into the dark cave (the Enfield will light the way)" : "E  Go into the dark cave");
                if (GameInput.TalkPressed()) Hud.Transition(GoIn);
                return;
            }

            // The way out: walk down the daylit steps behind where you came in (or press E by them).
            if (Mathf.Abs(feet.x - _exit.x) < 0.6f && feet.y < _exit.y + 0.3f) { Hud.Transition(Leave); return; }
            if (Vector2.Distance(feet, _exit) < 1.4f)
            {
                Hud.SetPrompt("E  Leave the cave (or walk down into the daylight)");
                if (GameInput.TalkPressed()) Hud.Transition(Leave);
                return;
            }

            // The chest at the far end.
            Vector2 ahead = feet + new Vector2(0f, 0.15f) + Art.Dir(player.Facing) * 0.7f;
            if (Vector2.Distance(ahead, _chestSpot + new Vector2(0f, 0.25f)) < 0.7f)
            {
                if (_chestOpened) { Hud.SetPrompt("An old chest. Empty now"); return; }
                Hud.SetPrompt("E  Open the old chest");
                if (!GameInput.TalkPressed()) return;
                if (!Inventory.HasRoomFor(Items.Gem)) { Hud.Toast("Your bag is full! Make room first.", 2.5f); return; }
                Inventory.Add(Items.Gem, GemsInChest);
                PlayerStats.Gold += GoldInChest;
                _chestOpened = true;
                RefreshChest();
                Hud.ShowPopup(Items.Gem.Icon, $"{GemsInChest} Gems and {GoldInChest} gold!", "Whoever hid this didn't want it found without a light. Lucky you.");
            }
        }
    }
}
