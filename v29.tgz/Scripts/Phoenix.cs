using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// The phoenix. Up on the mountain, south of the road, there's a nest of stones
    /// with three cold torches round it. Light all three (throw fireballs at them
    /// from the spell book) and a phoenix comes down out of the sky to the nest, and
    /// chooses you. It flies along behind you, glows in the dark, perches beside you
    /// when you stop, and swoops on any slime nearby and breathes fire at it.
    /// Lit torches burn out overnight until the phoenix is your friend; after that
    /// they stay lit.
    /// </summary>
    public class Phoenix : MonoBehaviour
    {
        enum State { Away, Arriving, Landed, Friend }

        public static readonly Vector2 Nest = new Vector2(-7.5f, 7.4f);
        static readonly Vector2[] TorchSpots = { Nest + new Vector2(0f, 1.7f), Nest + new Vector2(-1.7f, -0.7f), Nest + new Vector2(1.7f, -0.7f) };
        const float FlyHeight = 1.3f, ArriveSpeed = 4.5f, HuntRange = 5f, BreathTime = 0.75f, BreathTick = 0.25f, BreathCooldown = 1.1f;
        const float TorchGlow = 2.6f, Glow = 2.2f, BreathGlow = 3.2f;

        static Phoenix _instance;
        public static bool Friend => _instance != null && _instance._state == State.Friend;
        public static bool Following => Friend && Creatures.Follower == CreatureKind.Phoenix;
        public static Sprite Icon => _instance != null && _instance._frames != null ? _instance._frames[2] : null;
        static bool Indoors => Home.Inside || Mine.Inside || Cavern.Inside || DarkCave.Inside || Town.Inside;

        /// <summary>A torch round the nest. Fire lights it; a sword just clangs off it.</summary>
        class Torch : MonoBehaviour, IHittable
        {
            public Phoenix Owner;
            public bool Lit;
            public SpriteRenderer Sprite;
            public void Hit(Vector2 from, int damage) { if (Spells.FireHit && Owner != null) Owner.LightTorch(this); }
        }

        State _state = State.Away;
        bool _shown;
        Vector2 _pos, _target, _lastPlayer;
        float _height, _clock, _playerStill, _t, _breathT = -1f, _tick, _cooldown;
        Slime _slime;
        Sprite[] _frames, _flames, _torch;
        SpriteRenderer _sprite, _shadow, _flame;
        readonly Torch[] _torches = new Torch[3];

        public static void Restore(bool friend)
        {
            if (_instance == null) return;
            _instance._state = friend ? State.Friend : State.Away;
            for (int i = 0; i < _instance._torches.Length; i++) _instance.SetLit(_instance._torches[i], friend);
        }

        public void Build(Transform parent)
        {
            _instance = this;
            _frames = Art.Strip("phoenix", 32, 32, new Vector2(0.5f, 0.1f));
            _flames = Art.Strip("phoenixfire", 24, 12, new Vector2(0.5f, 0.5f));
            _torch = Art.Strip("torch", 16, 32, new Vector2(0.5f, 0.06f));

            var nest = new GameObject("Phoenix nest").AddComponent<SpriteRenderer>();
            nest.transform.SetParent(parent, false);
            nest.transform.position = Nest;
            nest.sprite = Art.Single("phoenixnest", new Vector2(0.5f, 0.3f));
            nest.sortingOrder = YSort.Order(Nest.y - 0.3f);
            for (int i = 0; i < TorchSpots.Length; i++)
            {
                var go = new GameObject("Torch");
                go.transform.SetParent(parent, false);
                go.transform.position = TorchSpots[i];
                var torch = go.AddComponent<Torch>();
                torch.Owner = this;
                torch.Sprite = go.AddComponent<SpriteRenderer>();
                torch.Sprite.sortingOrder = YSort.Order(TorchSpots[i].y);
                var box = go.AddComponent<BoxCollider2D>();
                box.size = new Vector2(0.45f, 0.35f);
                box.offset = new Vector2(0f, 0.18f);
                _torches[i] = torch;
                SetLit(torch, false);
                var at = TorchSpots[i];
                Lighting.Add(go, () => at + new Vector2(0f, 1.3f), () => torch.Lit ? TorchGlow + Mathf.Sin(_clock * 9f + at.x) * 0.15f : 0f);
            }

            _shadow = new GameObject("Shadow").AddComponent<SpriteRenderer>();
            _shadow.transform.SetParent(transform, false);
            _shadow.sprite = Art.Single("shadow", new Vector2(0.5f, 0.5f));
            _shadow.sortingOrder = FarmDemoWorld.ShadowOrder;
            _shadow.transform.localScale = new Vector3(1.1f, 0.8f, 1f);
            _sprite = new GameObject("Sprite").AddComponent<SpriteRenderer>();
            _sprite.transform.SetParent(transform, false);
            _flame = new GameObject("Fire breath").AddComponent<SpriteRenderer>();
            _flame.transform.SetParent(transform, false);
            _flame.enabled = false;
            _sprite.enabled = _shadow.enabled = false;
            Lighting.Add(this, () => _pos + new Vector2(0f, _height + 0.5f),
                () => !_sprite.enabled ? 0f : _breathT >= 0f ? BreathGlow : Glow);
            GameClock.NewDay += Morning;
        }

        void OnDestroy()
        {
            GameClock.NewDay -= Morning;
            if (_instance == this) _instance = null;
        }

        // Unless the phoenix has come, the torches burn out overnight.
        void Morning()
        {
            if (_state == State.Friend) return;
            if (_state != State.Away) { Befriend(); return; }      // it came, and it stays
            foreach (var torch in _torches) SetLit(torch, false);
        }

        void SetLit(Torch torch, bool lit)
        {
            if (torch == null) return;
            torch.Lit = lit;
            if (_torch != null) torch.Sprite.sprite = _torch[lit ? 1 : 0];
        }

        void LightTorch(Torch torch)
        {
            if (torch.Lit) return;
            SetLit(torch, true);
            int lit = 0;
            foreach (var t in _torches) if (t.Lit) lit++;
            if (_state != State.Away) return;
            if (lit < _torches.Length) { Hud.Toast(lit == 1 ? "The torch flares up! Two more..." : "Another torch blazes. One more...", 2f); return; }
            // All three: it comes down out of the sky to the nest.
            _state = State.Arriving;
            _pos = Nest + new Vector2(10f, 3f);
            _height = 9f;
            _t = 0f;
            Hud.Toast("A cry rings out over the mountain! Something bright is coming...", 3f);
        }

        // ------------------------------------------------------------- update

        void Update()
        {
            _clock += Time.deltaTime;
            _t += Time.deltaTime;
            _cooldown -= Time.deltaTime;
            if (_torch != null)
                foreach (var torch in _torches)
                    if (torch.Lit) torch.Sprite.sprite = _torch[1 + Mathf.FloorToInt(_clock * 6f + torch.transform.position.x) % 2];

            var player = PlayerController.Instance;
            Vector2 playerPos = player != null ? (Vector2)player.transform.position : Nest;
            _playerStill = Vector2.Distance(playerPos, _lastPlayer) < 0.01f ? _playerStill + Time.deltaTime : 0f;
            _lastPlayer = playerPos;

            if (_state == State.Away) { Torches(player, playerPos); Hide(); return; }
            bool shown = _frames != null && (_state != State.Friend || (Following && !Indoors));
            if (!shown) { Hide(); return; }
            if (_state == State.Friend && (!_shown || Vector2.Distance(_pos, playerPos) > 14f))
            {
                _pos = _target = playerPos + new Vector2(-1.4f, 0.3f);
                _height = FlyHeight;
            }
            _shown = true;
            _sprite.enabled = _shadow.enabled = true;

            if (_state == State.Arriving) Arrive();
            else if (_state == State.Landed) { _height = 0.35f; if (_t > 1.3f) Befriend(); }
            else Friendly(player, playerPos);
            Draw();
        }

        void Hide()
        {
            _shown = false;
            _sprite.enabled = _shadow.enabled = _flame.enabled = false;
            _breathT = -1f;
        }

        // The prompts round the nest before it has come.
        void Torches(PlayerController player, Vector2 playerPos)
        {
            if (player == null || Hud.Busy || Indoors) return;
            foreach (var torch in _torches)
            {
                if (torch.Lit || Vector2.Distance(playerPos, torch.transform.position) > 1.5f) continue;
                Hud.SetPrompt(Toolbelt.Has(Items.SpellBook) ? "A cold torch. Hold your spell book and throw a fireball at it (F)"
                    : "A cold torch, carved with feathers. It needs fire...");
                return;
            }
            if (Vector2.Distance(playerPos, Nest) < 1.3f)
                Hud.SetPrompt("A nest of warm stones. A red feather glows in it like an ember.");
        }

        void Arrive()
        {
            Vector2 d = Nest - _pos;
            float step = ArriveSpeed * Time.deltaTime;
            _pos = d.magnitude <= step ? Nest : _pos + d.normalized * step;
            if (Mathf.Abs(d.x) > 0.05f) _sprite.flipX = d.x > 0f;          // the art faces left
            _height = Mathf.MoveTowards(_height, 0.35f, ArriveSpeed * 0.9f * Time.deltaTime);
            if (_pos == Nest && _height <= 0.36f) { _state = State.Landed; _t = 0f; }
        }

        void Befriend()
        {
            _state = State.Friend;
            foreach (var torch in _torches) SetLit(torch, true);
            Creatures.Follow(CreatureKind.Phoenix);
            if (_frames == null) return;
            StartCoroutine(Creatures.HeartPop(transform, 1.8f));
            Hud.ShowPopup(_frames[2], "The phoenix has chosen you!",
                "It came down to the torchlight for you. It flies along behind you, glows in the dark, and breathes fire at slimes. Only one creature follows you at a time.");
        }

        // ------------------------------------------------------------- friend

        void Friendly(PlayerController player, Vector2 playerPos)
        {
            if (_breathT >= 0f) { Breathe(); return; }

            // A slime nearby? Swoop over beside it.
            if (_slime == null || _slime.health <= 0) _slime = _cooldown <= 0f ? Creatures.NearestSlime(_pos, playerPos, HuntRange) : null;
            if (_slime != null)
            {
                Vector2 at = _slime.transform.position;
                float side = _pos.x >= at.x ? 1f : -1f;
                Vector2 spot = at + new Vector2(side * 1.9f, 0.1f);
                MoveToward(spot, 6f);
                _sprite.flipX = side < 0f;
                _height = Mathf.MoveTowards(_height, 0.55f, 2.5f * Time.deltaTime);
                if (Vector2.Distance(_pos, spot) < 0.25f) { _breathT = 0f; _tick = 0f; }
                return;
            }

            // Perch beside you when you stop; otherwise fly along behind you.
            if (_playerStill > 1.5f)
            {
                if ((_target - playerPos).magnitude > 2.2f || FarmDemoWorld.IsWater(_target + new Vector2(0f, 0.15f)))
                {
                    _target = playerPos + new Vector2(_pos.x < playerPos.x ? -1.3f : 1.3f, 0.1f);
                    if (FarmDemoWorld.IsWater(_target + new Vector2(0f, 0.15f))) _target = playerPos + new Vector2(0f, -0.6f);
                }
                MoveToward(_target, 2.5f);
                if (Vector2.Distance(_pos, _target) < 0.1f) _height = Mathf.MoveTowards(_height, 0f, 1.5f * Time.deltaTime);
                return;
            }
            _height = Mathf.MoveTowards(_height, FlyHeight, 2f * Time.deltaTime);
            Vector2 behind = player != null ? playerPos - Art.Dir(player.Facing) * 1.4f + new Vector2(0f, 0.2f) : Nest;
            _target = behind;
            Vector2 next = Vector2.Lerp(_pos, behind, 1f - Mathf.Exp(-3.5f * Time.deltaTime));
            if (Mathf.Abs(next.x - _pos.x) > 0.002f) _sprite.flipX = next.x > _pos.x;
            _pos = next;
        }

        // A gout of fire at the slime: it takes a knock each tick.
        void Breathe()
        {
            _breathT += Time.deltaTime;
            if (_slime != null && _slime.health > 0 && (_tick -= Time.deltaTime) <= 0f)
            {
                _tick = BreathTick;
                _slime.Hit(_pos, 1);
            }
            if (_breathT < BreathTime) return;
            _breathT = -1f;
            _cooldown = BreathCooldown;
            if (_slime != null && _slime.health <= 0) _slime = null;
        }

        void MoveToward(Vector2 goal, float speed)
        {
            Vector2 d = goal - _pos;
            float step = speed * Time.deltaTime;
            _pos = d.magnitude <= step ? goal : _pos + d.normalized * step;
            if (Mathf.Abs(d.x) > 0.05f) _sprite.flipX = d.x > 0f;
        }

        void Draw()
        {
            transform.position = _pos;
            bool flying = _height > 0.05f && _state != State.Landed;
            float bob = flying ? Mathf.Sin(_clock * 4f) * 0.07f : 0f;
            _sprite.transform.localPosition = new Vector3(0f, _height + bob, 0f);
            int frame = _breathT >= 0f ? 3 : flying ? Mathf.FloorToInt(_clock * 8f) % 2 : 2;
            _sprite.sprite = _frames[Mathf.Min(frame, _frames.Length - 1)];
            _sprite.sortingOrder = YSort.Order(_pos.y);
            _shadow.transform.localScale = new Vector3(1.1f - _height * 0.15f, 0.8f - _height * 0.1f, 1f);

            _flame.enabled = _breathT >= 0f && _flames != null;
            if (_flame.enabled)
            {
                float dir = _sprite.flipX ? 1f : -1f;
                _flame.sprite = _flames[Mathf.FloorToInt(_clock * 12f) % _flames.Length];
                _flame.flipX = _sprite.flipX;
                _flame.transform.localPosition = new Vector3(dir * 1.05f, _height + bob + 0.45f, 0f);
                _flame.sortingOrder = _sprite.sortingOrder + 1;
            }
        }
    }
}
