using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// Friendship with the villagers: 0 to 5 hearts (100 points each). Chatting once
    /// a day and giving a gift once a day (F with the item picked on your bar) earn
    /// points; each villager has favourites and things they'd rather not get.
    /// At 5 hearts they give you something special, once.
    /// </summary>
    public static class Friendship
    {
        public const int MaxHearts = 5, PointsPerHeart = 100;
        const int Chat = 10, Loved = 80, Liked = 45, Neutral = 20, Disliked = -20;

        public class Friend
        {
            public string Name;
            public int Points;
            public bool TalkedToday, GiftedToday, RewardGiven;
            public ItemDef[] Loves, Likes, Dislikes;
            public ItemDef RewardItem;
            public int RewardCount, RewardGold;
            public string RewardLine;
            public int Hearts => Mathf.Min(MaxHearts, Points / PointsPerHeart);
        }

        static readonly List<Friend> Friends = new List<Friend>();
        public static IReadOnlyList<Friend> All => Friends;

        public static void Reset()
        {
            Friends.Clear();
            GameClock.NewDay -= Morning;
            GameClock.NewDay += Morning;
        }

        public static Friend Add(string name, ItemDef[] loves, ItemDef[] likes, ItemDef[] dislikes,
            string rewardLine, ItemDef rewardItem = null, int rewardCount = 1, int rewardGold = 0)
        {
            var f = new Friend
            {
                Name = name, Loves = loves, Likes = likes, Dislikes = dislikes,
                RewardLine = rewardLine, RewardItem = rewardItem, RewardCount = rewardCount, RewardGold = rewardGold,
            };
            Friends.Add(f);
            return f;
        }

        public static Friend Get(string name) => Friends.Find(f => f.Name == name);
        public static int Hearts(string name) => Get(name)?.Hearts ?? 0;

        static void Morning()
        {
            foreach (var f in Friends) f.TalkedToday = f.GiftedToday = false;
        }

        /// <summary>The first chat each day is worth a few points.</summary>
        public static void Talked(string name)
        {
            var f = Get(name);
            if (f == null || f.TalkedToday) return;
            f.TalkedToday = true;
            Gain(f, Chat);
        }

        /// <summary>Points from a finished quest.</summary>
        public static void Helped(string name, int points)
        {
            var f = Get(name);
            if (f != null) Gain(f, points);
        }

        /// <summary>Can this be given to them right now?</summary>
        public static bool CanGift(string name, ItemDef item) =>
            item != null && item.SellPrice > 0 && Get(name) is Friend f && !f.GiftedToday;

        /// <summary>Hand over one of the item; returns what they say about it.</summary>
        public static string Gift(string name, ItemDef item)
        {
            var f = Get(name);
            if (f == null || Inventory.Remove(item) == 0) return null;
            f.GiftedToday = true;
            string first = name.Split(' ')[0];
            if (System.Array.IndexOf(f.Loves, item) >= 0) { Gain(f, Loved); return $"A {item.Name}! Oh, I love these. You're a real friend."; }
            if (System.Array.IndexOf(f.Likes, item) >= 0) { Gain(f, Liked); return $"A {item.Name}? Thank you, that's lovely."; }
            if (System.Array.IndexOf(f.Dislikes, item) >= 0) { Gain(f, Disliked); return $"...A {item.Name}. Well. It's the thought that counts, I suppose."; }
            Gain(f, Neutral);
            return $"For me? Thanks! {first} will find a use for it.";
        }

        static void Gain(Friend f, int points)
        {
            int before = f.Hearts;
            f.Points = Mathf.Clamp(f.Points + points, 0, MaxHearts * PointsPerHeart);
            if (f.Hearts > before) Hud.Toast($"{f.Name}: {f.Hearts} heart{(f.Hearts == 1 ? "" : "s")}!", 2.5f);
        }

        /// <summary>At full hearts, their one-time thank-you (shown after the chat). Null if not due.</summary>
        public static System.Action RewardIfDue(string name)
        {
            var f = Get(name);
            if (f == null || f.RewardGiven || f.Hearts < MaxHearts) return null;
            return () =>
            {
                if (f.RewardGiven) return;
                if (f.RewardItem != null && !Inventory.Add(f.RewardItem, f.RewardCount)) { Hud.Toast("Your bag is full! Come back for your gift.", 2.5f); return; }
                f.RewardGiven = true;
                PlayerStats.Gold += f.RewardGold;
                Hud.ShowPopup(f.RewardItem != null ? f.RewardItem.Icon : null, $"A gift from {f.Name}!", f.RewardLine);
            };
        }
    }

    /// <summary>
    /// The quest board by the crossroads. Each morning without a request, a villager
    /// pins one up: bring them a few of something in season. Read it with E; if
    /// you're carrying enough, you hand them in right there for gold and friendship.
    /// </summary>
    public class QuestBoard : MonoBehaviour
    {
        public static readonly Vector2 Spot = new Vector2(62.5f, 13.4f);   // on the town square, by the road
        const int DaysToFinish = 3, FriendshipReward = 60;

        public class Quest
        {
            public string Giver;
            public ItemDef Item;
            public int Amount, Reward, DaysLeft;
            public string Text => $"{Giver.Split(' ')[0]} wants {Amount} {Plural(Item, Amount)}";
        }

        public static Quest Current { get; private set; }
        static QuestBoard _instance;
        SpriteRenderer _prompt, _paper;

        public static string Plural(ItemDef item, int n) =>
            n == 1 || item.Name.EndsWith("s") || item.Name.EndsWith("Carp") || item.Name.EndsWith("Trout") || item.Name.EndsWith("Ore") || item.Name.EndsWith("Corn") || item.Name.EndsWith("Honey") ? item.Name : item.Name.EndsWith("y") ? item.Name.Substring(0, item.Name.Length - 1) + "ies" : item.Name.EndsWith("ch") ? item.Name + "es" : item.Name + "s";

        public void Build(Transform parent)
        {
            _instance = this;
            Current = null;
            var board = new GameObject("Quest board");
            board.transform.SetParent(parent, false);
            board.transform.position = Spot;
            var sr = board.AddComponent<SpriteRenderer>();
            var frames = Art.Strip("board", 32, 32);
            sr.sprite = frames?[0];
            board.AddComponent<YSort>();
            FarmDemoWorld.Tall(board);
            var box = board.AddComponent<BoxCollider2D>();
            box.size = new Vector2(1.6f, 0.35f);
            box.offset = new Vector2(0f, 0.2f);

            // The notice pinned on it: there while a request is up.
            _paper = new GameObject("Notice").AddComponent<SpriteRenderer>();
            _paper.transform.SetParent(board.transform, false);
            _paper.sprite = frames?[1];
            _paper.sortingOrder = YSort.Order(Spot.y) + 1;   // just in front of the board

            _prompt = new GameObject("Prompt").AddComponent<SpriteRenderer>();
            _prompt.transform.SetParent(board.transform, false);
            _prompt.transform.localPosition = new Vector3(0f, 2.1f, 0f);
            _prompt.sprite = Art.Single("key_e", new Vector2(0.5f, 0f));
            _prompt.sortingOrder = 32000;
            _prompt.enabled = false;

            GameClock.NewDay += Morning;
            Pin();
        }

        void OnDestroy()
        {
            GameClock.NewDay -= Morning;
            if (_instance == this) _instance = null;
        }

        /// <summary>Put a saved request back up (or none).</summary>
        public static void Restore(Quest q)
        {
            Current = q;
            if (_instance != null) _instance._paper.enabled = q != null;
        }

        void Morning()
        {
            if (Current != null && --Current.DaysLeft <= 0)
            {
                Current = null;
                StartCoroutine(Later(4.5f, () => Hud.Toast("A request on the quest board ran out of time.", 3f)));
            }
            if (Current == null) Pin();
        }

        static System.Collections.IEnumerator Later(float seconds, System.Action action)
        {
            yield return new WaitForSeconds(seconds);
            action();
        }

        // A fresh request: something you can actually get this season.
        void Pin()
        {
            var wanted = new List<ItemDef> { Items.Bluegill, Items.Carp };
            if (Animals.HasHens) wanted.Add(Items.Egg);
            if (Mine.Deepest >= 1) wanted.Add(Items.CopperOre);
            if (Mine.Deepest >= 3) wanted.Add(Items.IronOre);
            if (Barn.Count(BeastKind.Cow) > 0) wanted.Add(Items.Milk);
            if (Barn.Count(BeastKind.Goat) > 0) wanted.Add(Items.GoatMilk);
            if (Apiary.Count > 0 && Seasons.Current != Season.Winter) wanted.Add(Items.Honey);
            foreach (var crop in CropDef.All)
                if (crop.InSeason(Seasons.Current)) wanted.Add(crop.Produce);
            var item = wanted[Random.Range(0, wanted.Count)];
            int amount = item == Items.Pumpkin ? 1 : Random.Range(2, 5);
            var givers = Friendship.All;
            Current = new Quest
            {
                Giver = givers.Count > 0 ? givers[Random.Range(0, givers.Count)].Name : "Mabel the Baker",
                Item = item,
                Amount = amount,
                Reward = Mathf.RoundToInt(item.SellPrice * amount * 2f / 10f) * 10,
                DaysLeft = DaysToFinish,
            };
            _paper.enabled = true;
        }

        void Update()
        {
            _prompt.enabled = false;
            if (ReferenceEquals(Hud.Speaker, this))
            {
                if (GameInput.TalkPressed()) Hud.AdvanceDialogue();
                return;
            }
            var player = PlayerController.Instance;
            if (player == null || Hud.Busy || player.Locked) return;
            Vector2 feet = player.transform.position;
            if (Vector2.Distance(feet, Spot + new Vector2(0f, -0.5f)) > 1.2f || player.Facing != Facing.Up) return;

            float bob = Mathf.Sin(Time.time * 5f) > 0f ? 1f / FarmDemoConfig.PixelsPerUnit : 0f;
            _prompt.enabled = true;
            _prompt.transform.localPosition = new Vector3(0f, 2.1f + bob, 0f);
            Hud.SetPrompt("E  Read the quest board");
            if (!GameInput.TalkPressed()) return;

            var q = Current;
            if (q == null)
            {
                Hud.OpenDialogue(this, "Quest Board", new[] { "No requests right now. Check back tomorrow morning." });
                return;
            }
            string ask = $"{q.Giver}: \"Could you bring me {q.Amount} {Plural(q.Item, q.Amount)}? I'll pay {q.Reward}g.\" ({q.DaysLeft} day{(q.DaysLeft == 1 ? "" : "s")} left)";
            int have = Inventory.Count(q.Item);
            if (have < q.Amount)
            {
                Hud.OpenDialogue(this, "Quest Board", new[] { ask, $"You have {have} of {q.Amount}." });
                return;
            }
            Hud.OpenDialogue(this, "Quest Board", new[] { ask, "You have them! You leave them in the basket under the board." }, () =>
            {
                if (Current != q || Inventory.Count(q.Item) < q.Amount) return;
                Inventory.Remove(q.Item, q.Amount);
                PlayerStats.Gold += q.Reward;
                Friendship.Helped(q.Giver, FriendshipReward);
                Current = null;
                _paper.enabled = false;
                Hud.Toast($"Request done! +{q.Reward}g. {q.Giver.Split(' ')[0]} is grateful.", 3f);
            });
        }
    }
}
