using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// A Light-Bringer Enfield: a white fox with dove-feather wings on its forelegs,
    /// living in the hollow of the great oak in the forest. It glows, so it only comes
    /// out at night. Stand by the oak after dark and keep still: it peeks out of the
    /// hollow, then climbs down and wanders round the clearing, now and then hopping
    /// through a little portal to another spot nearby. Walk up holding a golden trout
    /// and press F to offer it; then it's bonded to you and follows you about, lighting
    /// up the ground around it (handy in the dark cave).
    /// </summary>
    public class Enfield : MonoBehaviour
    {
        enum State { Hidden, Peek, Climb, Out }

        const float NightHour = 20f;            // 8 PM
        const float StillToPeek = 3f, PeekTime = 2.2f, ClimbTime = 0.7f, HopTime = 0.6f;
        const float WildWalk = 1.3f, FriendWalk = 4f;
        const float OutdoorGlow = 3.5f, CaveGlow = 4.5f;

        static Enfield _instance;
        public static bool Friend => _instance != null && _instance._friend;
        public static bool Following => Friend && Creatures.Follower == CreatureKind.Enfield;
        public static Sprite Icon => _instance != null && _instance._frames != null ? _instance._frames[0] : null;
        /// <summary>You're beside the wild Enfield with a golden trout in hand: F is for offering it.</summary>
        public static bool WantsTrout => _instance != null && _instance._wantsTrout;

        // The oak's hollow: the head peeks over its lip; it climbs down to the ground in front.
        static Vector2 OakBase => Forest.Oak + new Vector2(0.5f, 0.4f);
        static Vector2 PeekSpot => OakBase + new Vector2(0.125f, 0f);
        static Vector2 Doorstep => OakBase + new Vector2(0f, -1f);
        static Vector2 Clearing => OakBase + new Vector2(0f, -2.2f);

        State _state = State.Hidden;
        bool _friend, _shown, _wantsTrout, _hopHidden;
        Vector2 _pos, _target, _hopTo, _lastPlayer;
        float _stateT, _wait, _playerStill, _clock, _hopT = -1f, _height, _cooldown;
        Slime _slime;
        Sprite[] _frames, _portal;
        SpriteRenderer _sprite, _shadow, _portalSprite;

        public static void Restore(bool friend)
        {
            if (_instance == null) return;
            _instance._friend = friend;
            if (!friend) _instance.GoHome();
        }

        public void Build()
        {
            _instance = this;
            _frames = Art.Strip("enfield", 24, 24);
            _portal = Art.Strip("portal", 16, 16, new Vector2(0.5f, 0.5f));
            _shadow = new GameObject("Shadow").AddComponent<SpriteRenderer>();
            _shadow.transform.SetParent(transform, false);
            _shadow.sprite = Art.Single("shadow", new Vector2(0.5f, 0.5f));
            _shadow.sortingOrder = FarmDemoWorld.ShadowOrder;
            _shadow.transform.localScale = new Vector3(0.8f, 0.7f, 1f);
            _sprite = new GameObject("Sprite").AddComponent<SpriteRenderer>();
            _sprite.transform.SetParent(transform, false);
            _portalSprite = new GameObject("Portal").AddComponent<SpriteRenderer>();
            _portalSprite.transform.SetParent(transform.parent, false);
            _portalSprite.enabled = false;
            GoHome();
            Lighting.Add(this, () => _pos + new Vector2(0f, 0.4f + _height), Glow);
            GameClock.NewDay += Morning;
        }

        void OnDestroy()
        {
            GameClock.NewDay -= Morning;
            if (_instance == this) _instance = null;
        }

        // Daylight: a wild Enfield goes back into the oak to sleep.
        void Morning()
        {
            if (!_friend) GoHome();
        }

        void GoHome()
        {
            _state = State.Hidden;
            _pos = _target = Doorstep;
            _hopT = -1f;
            _hopHidden = false;
            _height = 0f;
            _playerStill = 0f;
        }

        /// <summary>How far its glow reaches right now.</summary>
        float Glow()
        {
            if (!_sprite.enabled || _hopHidden) return 0f;
            if (_state == State.Peek) return 1.6f;
            return DarkCave.Inside ? CaveGlow : OutdoorGlow;
        }

        void Update()
        {
            _wantsTrout = false;
            bool shown = _friend ? Following : _state != State.Hidden;
            _sprite.enabled = _shadow.enabled = shown && _frames != null;
            if (!_sprite.enabled) _portalSprite.enabled = false;

            var player = PlayerController.Instance;
            Vector2 playerPos = player != null ? (Vector2)player.transform.position : Doorstep;
            _playerStill = Vector2.Distance(playerPos, _lastPlayer) < 0.01f && !Hud.Busy ? _playerStill + Time.deltaTime : 0f;
            _lastPlayer = playerPos;
            _clock += Time.deltaTime;
            _stateT += Time.deltaTime;

            if (!_friend && _state == State.Hidden) { Lurk(player, playerPos); return; }
            if (_frames == null) return;
            if (_friend && !Following) { _shown = false; return; }
            if (_friend && (!_shown || Vector2.Distance(_pos, playerPos) > 12f)) Appear(playerPos);   // just called along, or you went far
            _shown = true;

            if (_hopT >= 0f) Hop();
            else if (_state == State.Peek) Peek();
            else if (_state == State.Climb) Climb();
            else if (_friend) Friendly(playerPos);
            else { Wander(); Befriend(player); }
            Draw();
        }

        // ------------------------------------------------------------- wild

        // In the hollow: at night, if you stand quietly nearby, it peeks out.
        void Lurk(PlayerController player, Vector2 playerPos)
        {
            if (player == null || GameClock.Hour < NightHour || Home.Inside || Town.Inside) return;
            float d = Vector2.Distance(playerPos, Doorstep);
            if (d > 4f) return;
            if (d < 2.5f && !Hud.Busy) Hud.SetPrompt(_playerStill > 1f ? "Shh... something stirs inside the hollow." : "Something glimmers inside the hollow of the oak...");
            if (_playerStill < StillToPeek) return;
            _state = State.Peek;
            _stateT = 0f;
            _pos = PeekSpot;
            _sprite.flipX = playerPos.x > _pos.x;
            _sprite.enabled = _shadow.enabled = true;
            Draw();
        }

        void Peek()
        {
            // Move and it ducks back in.
            if (_playerStill <= 0f && _stateT > 0.2f) { GoHome(); return; }
            if (_stateT < PeekTime) return;
            _state = State.Climb;
            _stateT = 0f;
        }

        void Climb()
        {
            float t = Mathf.Clamp01(_stateT / ClimbTime);
            _pos = Vector2.Lerp(PeekSpot, Doorstep, t);
            _height = Mathf.Sin(t * Mathf.PI) * 0.5f + (1f - t) * 0.2f;
            if (t < 1f) return;
            _height = 0f;
            _state = State.Out;
            _target = _pos;
            _wait = 1f;
            Hud.Toast("An Enfield! It glows softly in the dark.", 3f);
        }

        // Out for the night: pottering round the clearing, sometimes stepping through a portal.
        void Wander()
        {
            if (MoveToward(_target, WildWalk)) return;
            if ((_wait -= Time.deltaTime) > 0f) return;
            Vector2 spot = Clearing + Vector2.Scale(Random.insideUnitCircle, new Vector2(3.2f, 1.6f));
            if (Random.value < 0.35f) StartHop(Clearing + Vector2.Scale(Random.insideUnitCircle.normalized, new Vector2(3.4f, 1.7f)));
            else _target = spot;
            _wait = Random.Range(1.2f, 3f);
        }

        void Befriend(PlayerController player)
        {
            if (player == null || Hud.Busy || player.Locked || _hopT >= 0f) return;
            Vector2 feet = (Vector2)player.transform.position + new Vector2(0f, 0.15f);
            if (Vector2.Distance(feet, _pos) > 1.7f) return;
            if (Inventory.SelectedItem != Items.GoldenTrout)
            {
                Hud.SetPrompt(Inventory.Has(Items.GoldenTrout) ? "The Enfield sniffs at your bag. Pick your golden trout to offer it"
                    : "The Enfield tilts its head at you. It looks hungry for something shiny... and fishy");
                return;
            }
            _wantsTrout = true;
            _target = _pos;
            _sprite.flipX = player.transform.position.x > _pos.x;
            Hud.SetPrompt("F  Offer the Enfield a golden trout");
            if (!GameInput.FishPressed() || Inventory.Remove(Items.GoldenTrout) == 0) return;
            _friend = true;
            Creatures.Follow(CreatureKind.Enfield);
            StartCoroutine(Creatures.HeartPop(transform, 1.1f));
            Hud.ShowPopup(_frames[0], "The Enfield has bonded with you!",
                "It'll follow you about, glowing, and hop through little portals to keep up. Its light lets you see in the dark. Only one creature follows you at a time.");
        }

        // ------------------------------------------------------------- friend

        void Appear(Vector2 near)
        {
            _state = State.Out;
            _pos = _target = near + new Vector2(Random.value < 0.5f ? -1f : 1f, -0.3f);
            _hopT = -1f;
            _hopHidden = false;
            _height = 0f;
        }

        // While you're on the move it runs along behind you. Only once you stop does it
        // wander about you, and now and then pop through a portal.
        void Friendly(Vector2 playerPos)
        {
            float far = Vector2.Distance(_pos, playerPos);
            // In the dark it stays right by you, so its light is yours.
            float keep = DarkCave.Inside ? 1.1f : 1.6f;
            var player = PlayerController.Instance;

            // A slime near you? It slips through a portal to its side and swipes with its talons.
            _cooldown -= Time.deltaTime;
            if (_slime == null || _slime.health <= 0) _slime = _cooldown <= 0f ? Creatures.NearestSlime(_pos, playerPos, 4.5f) : null;
            if (_slime != null)
            {
                Vector2 at = _slime.transform.position;
                float d = Vector2.Distance(_pos, at);
                if (d > 2.5f) { StartHop(at + (_pos - at).normalized * 0.8f); return; }
                _target = at;
                MoveToward(at, FriendWalk * 1.5f);
                if (d < 0.6f)
                {
                    _slime.Hit(_pos, 1);
                    _cooldown = 0.9f;
                    _slime = null;
                    _target = _pos;
                }
                return;
            }
            if (_playerStill < 0.4f && player != null)
            {
                Vector2 behind = playerPos - Art.Dir(player.Facing) * keep;
                _target = behind;
                MoveToward(behind, Mathf.Clamp(far * 3f, FriendWalk, 12f));
                return;
            }
            if (far > 4.5f) { StartHop(playerPos + (_pos - playerPos).normalized * keep); return; }
            if (far > keep + 0.6f) { _target = playerPos + (_pos - playerPos).normalized * keep; MoveToward(_target, FriendWalk); return; }
            if (MoveToward(_target, 1.2f)) return;
            if (_playerStill > 1.2f && (_wait -= Time.deltaTime) <= 0f)
            {
                Vector2 spot = playerPos + Random.insideUnitCircle.normalized * Random.Range(0.9f, keep + 0.3f);
                if (!DarkCave.Inside && Random.value < 0.25f) StartHop(spot);
                else _target = spot;
                _wait = Random.Range(1.5f, 3f);
            }
        }

        // ------------------------------------------------------------- moving

        /// <summary>Step toward a spot. True while still on the way.</summary>
        bool MoveToward(Vector2 goal, float speed)
        {
            Vector2 d = goal - _pos;
            if (d.sqrMagnitude < 0.0004f) return false;
            float step = speed * Time.deltaTime;
            _pos = d.magnitude <= step ? goal : _pos + d.normalized * step;
            if (Mathf.Abs(d.x) > 0.02f) _sprite.flipX = d.x > 0f;     // the art faces left
            return true;
        }

        // A portal opens, it dives in, and pops out of another one a little way off.
        void StartHop(Vector2 to)
        {
            _hopTo = to;
            _hopT = 0f;
            _hopHidden = false;
            if (Mathf.Abs(to.x - _pos.x) > 0.05f) _sprite.flipX = to.x > _pos.x;
        }

        void Hop()
        {
            _hopT += Time.deltaTime / HopTime;
            float t = _hopT;
            _hopHidden = t > 0.25f && t < 0.6f;
            if (t >= 0.45f && _pos != _hopTo) { _pos = _target = _hopTo; }
            _portalSprite.enabled = _portal != null && t < 1f;
            if (_portalSprite.enabled)
            {
                // Open at the start, shut behind it; open at the far end, shut once it's through.
                float local = t < 0.45f ? t / 0.45f : (t - 0.45f) / 0.55f;
                int frame = local < 0.33f ? 0 : local < 0.66f ? 1 : 2;
                _portalSprite.sprite = _portal[frame];
                _portalSprite.transform.position = _pos + new Vector2(0f, 0.45f);
                _portalSprite.sortingOrder = YSort.Order(_pos.y) + 2;
            }
            if (t < 1f) return;
            _hopT = -1f;
            _hopHidden = false;
            _wait = Random.Range(0.8f, 2f);
        }

        void Draw()
        {
            transform.position = _pos;
            _sprite.transform.localPosition = new Vector3(0f, _height, 0f);
            _sprite.color = _hopHidden ? Color.clear : Color.white;
            _shadow.enabled = _sprite.enabled && !_hopHidden && _state != State.Peek;
            bool walking = _hopT < 0f && (_target - _pos).sqrMagnitude > 0.0004f;
            int frame = _state == State.Peek ? 4
                : _state == State.Climb || (_hopT >= 0f && (_hopT < 0.25f || _hopT > 0.6f)) ? 5
                : walking ? 1 + Mathf.FloorToInt(_clock * 8f) % 2
                : _playerStill > 2f || (_wait > 1.5f && !_friend) ? 3 : 0;
            _sprite.sprite = _frames[Mathf.Min(frame, _frames.Length - 1)];
            // In the hollow it's drawn over the oak; otherwise sorted like anything else.
            _sprite.sortingOrder = _state == State.Peek || _state == State.Climb ? YSort.Order(OakBase.y) + 5 : YSort.Order(_pos.y);
        }
    }
}
