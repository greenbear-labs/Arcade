using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>A little bush you can snip away with the shears, or a rock the pickaxe breaks.</summary>
    public class WildProp : MonoBehaviour
    {
        public enum Kind { Bush, Rock }
        public Kind Type;
        public Vector2Int Cell;
        public int Hits = 2;

        public static readonly List<WildProp> All = new List<WildProp>();
        void OnEnable() => All.Add(this);
        void OnDisable() => All.Remove(this);
    }

    /// <summary>A wild berry bush. Every couple of mornings (not in winter) it fills up with berries.</summary>
    public class BerryBush : MonoBehaviour
    {
        public const int DaysToRipen = 2;
        public int Id;
        public bool Ripe;
        public int Days;
        public Sprite[] Frames;

        public static readonly List<BerryBush> All = new List<BerryBush>();
        void OnEnable() => All.Add(this);
        void OnDisable() => All.Remove(this);

        public void Refresh()
        {
            var sr = GetComponent<SpriteRenderer>();
            if (Frames != null && sr != null) sr.sprite = Frames[Ripe ? 1 : 0];
        }
    }

    /// <summary>
    /// The wild bits outdoors: shears clear bushes, the pickaxe breaks rocks (sometimes
    /// there's copper inside), and berry bushes give wild berries. What you clear stays
    /// cleared (it's in the save).
    /// </summary>
    public class Wilds : MonoBehaviour
    {
        static Wilds _instance;
        readonly HashSet<Vector2Int> _cleared = new HashSet<Vector2Int>();
        Sprite[] _puff, _berryFrames;

        void Awake()
        {
            _instance = this;
            _puff = Art.Strip("puff", 16, 16, new Vector2(0.5f, 0.5f));
            GameClock.NewDay += Morning;
        }

        void OnDestroy()
        {
            GameClock.NewDay -= Morning;
            if (_instance == this) _instance = null;
        }

        /// <summary>Make a placed bush or rock clearable.</summary>
        public static void Register(GameObject go, WildProp.Kind kind, Vector2Int cell)
        {
            var w = go.AddComponent<WildProp>();
            w.Type = kind;
            w.Cell = cell;
        }

        /// <summary>A wild berry bush, standing with its bottom-centre here.</summary>
        public static BerryBush AddBerryBush(Transform parent, Vector2 at)
        {
            if (_instance == null) return null;
            if (_instance._berryFrames == null) _instance._berryFrames = Art.Strip("berrybush", 16, 16);
            if (_instance._berryFrames == null) return null;
            var go = new GameObject("Berry bush");
            go.transform.SetParent(parent, false);
            go.transform.position = at;
            go.AddComponent<SpriteRenderer>();
            go.AddComponent<YSort>();
            var box = go.AddComponent<BoxCollider2D>();
            box.size = new Vector2(0.8f, 0.45f);
            box.offset = new Vector2(0f, 0.22f);
            var bush = go.AddComponent<BerryBush>();
            bush.Id = BerryBush.All.Count - 1;
            bush.Frames = _instance._berryFrames;
            bush.Ripe = true;          // the first time you find one, there are berries on it
            bush.Refresh();
            return bush;
        }

        public static void Export(List<SaveGame.Cell> cleared, List<SaveGame.CellDays> berries)
        {
            if (_instance == null) return;
            foreach (var c in _instance._cleared) cleared.Add(new SaveGame.Cell { x = c.x, y = c.y });
            foreach (var b in BerryBush.All) berries.Add(new SaveGame.CellDays { x = b.Id, y = b.Ripe ? 1 : 0, days = b.Days });
        }

        public static void Import(List<SaveGame.Cell> cleared, List<SaveGame.CellDays> berries)
        {
            if (_instance == null) return;
            foreach (var c in cleared) _instance._cleared.Add(new Vector2Int(c.x, c.y));
            foreach (var w in new List<WildProp>(WildProp.All))
                if (_instance._cleared.Contains(w.Cell)) Destroy(w.gameObject);
            foreach (var s in berries)
                foreach (var b in BerryBush.All)
                    if (b.Id == s.x) { b.Ripe = s.y == 1; b.Days = s.days; b.Refresh(); }
        }

        static void Morning()
        {
            if (Seasons.Current == Season.Winter) return;
            foreach (var b in BerryBush.All)
            {
                if (b.Ripe) continue;
                if (++b.Days >= BerryBush.DaysToRipen) { b.Ripe = true; b.Days = 0; }
                b.Refresh();
            }
        }

        void Update()
        {
            var player = PlayerController.Instance;
            if (player == null || Hud.Busy || player.Locked || player.IsAttacking || Home.Inside || Mine.Inside || Cavern.Inside || Jackalope.WantsBerry) return;
            Vector2 feet = (Vector2)player.transform.position + new Vector2(0f, 0.15f);
            Vector2 ahead = feet + Art.Dir(player.Facing) * 0.7f;
            var held = Inventory.SelectedItem;

            // Berries first: any tool will do, you pick them by hand.
            BerryBush berry = null;
            float best = 0.8f;
            foreach (var b in BerryBush.All)
            {
                float d = Vector2.Distance(ahead, (Vector2)b.transform.position + new Vector2(0f, 0.25f));
                if (d < best) { best = d; berry = b; }
            }
            if (berry != null)
            {
                if (!berry.Ripe)
                {
                    Hud.SetPrompt(Seasons.Current == Season.Winter ? "A berry bush, bare for the winter" : "A berry bush. More berries soon");
                    return;
                }
                Hud.SetPrompt("F  Pick the wild berries");
                if (!GameInput.FishPressed()) return;
                int count = Random.Range(2, 4);
                if (!Inventory.Add(Items.WildBerries, count)) { Hud.Toast("Your bag is full!", 2f); return; }
                berry.Ripe = false;
                berry.Days = 0;
                berry.Refresh();
                Effect(berry.transform.position + new Vector3(0f, 0.4f));
                Hud.Toast($"+{count} Wild Berries", 1.5f);
                return;
            }

            if (held != Items.Shears && held != Items.Pickaxe) return;
            WildProp prop = null;
            best = 0.8f;
            foreach (var w in WildProp.All)
            {
                if ((w.Type == WildProp.Kind.Bush) != (held == Items.Shears)) continue;
                float d = Vector2.Distance(ahead, (Vector2)w.transform.position + new Vector2(0f, 0.25f));
                if (d < best) { best = d; prop = w; }
            }
            if (prop == null) return;

            if (prop.Type == WildProp.Kind.Bush)
            {
                Hud.SetPrompt("F  Trim away the bush");
                if (!GameInput.FishPressed()) return;
                Clear(prop);
                return;
            }

            Hud.SetPrompt("F  Break the rock");
            if (!GameInput.FishPressed()) return;
            if (Upgrades.Pickaxe >= 1) prop.Hits = 1;
            if (--prop.Hits > 0) { StartCoroutine(Shake(prop.transform)); Effect(prop.transform.position + new Vector3(0f, 0.3f)); return; }
            Vector2 at = prop.transform.position;
            Clear(prop);
            if (Random.value < 0.35f)
            {
                if (Inventory.Add(Items.CopperOre)) Hud.Toast("+1 Copper Ore", 1.5f);
            }
            else if (Random.value < 0.3f) Coin.Spawn(at + new Vector2(0f, 0.3f));
        }

        void Clear(WildProp prop)
        {
            _cleared.Add(prop.Cell);
            Effect(prop.transform.position + new Vector3(0f, 0.3f));
            Destroy(prop.gameObject);
        }

        void Effect(Vector2 at)
        {
            if (_puff != null) StartCoroutine(PlayEffect(_puff, at));
        }

        static IEnumerator PlayEffect(Sprite[] frames, Vector2 at)
        {
            var sr = new GameObject("Effect").AddComponent<SpriteRenderer>();
            sr.transform.position = at;
            sr.sortingOrder = 31200;
            foreach (var f in frames)
            {
                sr.sprite = f;
                yield return new WaitForSeconds(0.07f);
            }
            Destroy(sr.gameObject);
        }

        static IEnumerator Shake(Transform t)
        {
            Vector3 home = t.position;
            for (float k = 0f; k < 1f && t != null; k += Time.deltaTime / 0.15f)
            {
                t.position = home + new Vector3(Mathf.Sin(k * Mathf.PI * 4f) / FarmDemoConfig.PixelsPerUnit, 0f, 0f);
                yield return null;
            }
            if (t != null) t.position = home;
        }
    }
}
