using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// A jackalope that lives in the meadow behind the village. It's shy until you
    /// offer it wild berries (pick them, face it and press F); then it's your friend
    /// and hops along after you. When you stop, it hops about nearby. Get close to a
    /// slime and it charges, knocking the slime back. In the bag's Creatures tab you
    /// can tell it to follow you or stay home (for now, home means out of sight).
    /// </summary>
    public class Jackalope : MonoBehaviour
    {
        const float HopTime = 0.34f, ChargeHopTime = 0.22f;
        const float SlimeRange = 4.5f, StrikeRange = 0.7f;

        static Jackalope _instance;
        public static bool Friend => _instance != null && _instance._friend;
        public static bool Following => _instance != null && _instance._friend && _instance._follow;
        /// <summary>You're beside the wild jackalope with berries in hand: F is for feeding it.</summary>
        public static bool WantsBerry =>
            _instance != null && !_instance._friend && PlayerController.Instance != null && Inventory.SelectedItem == Items.WildBerries &&
            Vector2.Distance((Vector2)PlayerController.Instance.transform.position + new Vector2(0f, 0.15f), _instance._pos) <= 1.6f;
        public static Sprite Icon => _instance != null && _instance._frames != null ? _instance._frames[0] : null;

        bool _friend, _follow = true;
        Vector2 _home, _pos, _hopFrom, _hopTo;
        float _hopT = -1f, _hopDur = HopTime, _wait = 0.5f, _cooldown, _height;
        Vector2 _lastPlayer;
        float _playerStill;
        Slime _target;
        Sprite[] _frames;
        SpriteRenderer _sprite, _shadow;
        Transform _body;

        public static void Restore(bool friend, bool follow)
        {
            if (_instance == null) return;
            _instance._friend = friend;
            _instance._follow = follow;
            if (friend && follow && PlayerController.Instance != null) _instance.Teleport(PlayerController.Instance.transform.position);
        }

        public static void SetFollow(bool follow)
        {
            if (_instance == null || !_instance._friend) return;
            _instance._follow = follow;
            if (follow && PlayerController.Instance != null) _instance.Teleport(PlayerController.Instance.transform.position);
        }

        public void Build(Vector2 home)
        {
            _instance = this;
            _home = _pos = home;
            _frames = Art.Strip("jackalope", 16, 16);
            var shadow = new GameObject("Shadow").AddComponent<SpriteRenderer>();
            shadow.transform.SetParent(transform, false);
            shadow.sprite = Art.Single("shadow", new Vector2(0.5f, 0.5f));
            shadow.sortingOrder = FarmDemoWorld.ShadowOrder;
            shadow.transform.localScale = new Vector3(0.7f, 0.7f, 1f);
            _shadow = shadow;
            _sprite = new GameObject("Sprite").AddComponent<SpriteRenderer>();
            _sprite.transform.SetParent(transform, false);
            _sprite.gameObject.AddComponent<YSort>().isStatic = false;
            _body = _sprite.transform;
            transform.position = _pos;
        }

        void OnDestroy()
        {
            if (_instance == this) _instance = null;
        }

        void Teleport(Vector2 near)
        {
            _pos = near + new Vector2(Random.value < 0.5f ? -0.9f : 0.9f, -0.3f);
            _hopT = -1f;
            _wait = 0.3f;
            _target = null;
        }

        void Update()
        {
            bool shown = !_friend || _follow;
            _sprite.enabled = _shadow.enabled = shown && _frames != null;
            if (!shown || _frames == null) return;

            var player = PlayerController.Instance;
            Vector2 playerPos = player != null ? (Vector2)player.transform.position : _home;
            _playerStill = Vector2.Distance(playerPos, _lastPlayer) < 0.01f ? _playerStill + Time.deltaTime : 0f;
            _lastPlayer = playerPos;
            _cooldown -= Time.deltaTime;

            if (_friend && Vector2.Distance(_pos, playerPos) > 10f) Teleport(playerPos);   // you went indoors, or far away
            if (!_friend) Befriend(player);

            if (_hopT >= 0f) Hop();
            else if ((_wait -= Time.deltaTime) <= 0f) Decide(playerPos);

            // Draw: the body rides an arc over its shadow.
            transform.position = _pos;
            _body.localPosition = new Vector3(0f, _height, 0f);
            int frame = _hopT >= 0f ? (_hopT < 0.15f || _hopT > 0.85f ? 1 : 2) : (_target != null || (!_friend && Vector2.Distance(_pos, playerPos) < 3f) ? 3 : 0);
            _sprite.sprite = _frames[Mathf.Min(frame, _frames.Length - 1)];
        }

        void Hop()
        {
            _hopT += Time.deltaTime / _hopDur;
            float t = Mathf.Clamp01(_hopT);
            _pos = Vector2.Lerp(_hopFrom, _hopTo, t);
            _height = Mathf.Sin(t * Mathf.PI) * 0.35f;
            if (t < 1f) return;
            _hopT = -1f;
            _height = 0f;
            if (_target != null && Vector2.Distance(_pos, (Vector2)_target.transform.position + new Vector2(0f, 0.2f)) < StrikeRange && _cooldown <= 0f)
            {
                _target.Hit(_pos, 1);
                _cooldown = 1f;
                _wait = 0.35f;
                _target = null;
            }
        }

        void HopTo(Vector2 to, float time)
        {
            _hopFrom = _pos;
            _hopTo = to;
            _hopDur = time;
            _hopT = 0f;
            if (Mathf.Abs(to.x - _pos.x) > 0.05f) _sprite.flipX = to.x > _pos.x;   // the art faces left
        }

        void Decide(Vector2 playerPos)
        {
            if (!_friend)
            {
                // Wild: shy of you unless you're holding berries, otherwise pottering about its meadow.
                bool berries = Inventory.SelectedItem == Items.WildBerries;
                Vector2 away = _pos - playerPos;
                if (!berries && away.magnitude < 2.5f)
                    HopTo(Clamp(_pos + away.normalized * 1.4f + Random.insideUnitCircle * 0.3f, _home, 3.5f), HopTime);
                else if (berries && away.magnitude < 4f) { _wait = 0.4f; _sprite.flipX = playerPos.x > _pos.x; return; }
                else HopTo(Clamp(_pos + Random.insideUnitCircle * 1.2f, _home, 3f), HopTime);
                _wait = Random.Range(0.6f, 2f);
                return;
            }

            // A slime near you or near it? Charge it.
            if (_target == null || _target.health <= 0) _target = NearestSlime(playerPos);
            if (_target != null)
            {
                Vector2 at = (Vector2)_target.transform.position + new Vector2(0f, 0.2f);
                Vector2 d = at - _pos;
                HopTo(_pos + Vector2.ClampMagnitude(d, 1.6f), ChargeHopTime);
                _wait = 0.05f;
                return;
            }

            // Keep up with you; when you stand still, hop about close by.
            Vector2 toPlayer = playerPos - _pos;
            if (toPlayer.magnitude > 2f)
            {
                float far = toPlayer.magnitude;
                HopTo(_pos + Vector2.ClampMagnitude(toPlayer - toPlayer.normalized * 1.2f, far > 5f ? 2.4f : 1.5f), far > 5f ? 0.26f : HopTime);
                _wait = 0.02f;
            }
            else if (_playerStill > 0.5f)
            {
                HopTo(playerPos + Random.insideUnitCircle.normalized * Random.Range(0.8f, 1.6f) + new Vector2(0f, -0.2f), HopTime);
                _wait = Random.Range(0.6f, 1.6f);
            }
            else _wait = 0.1f;
        }

        Slime NearestSlime(Vector2 playerPos)
        {
            Slime best = null;
            float bestD = SlimeRange;
            foreach (var col in Physics2D.OverlapCircleAll(_pos, SlimeRange))
            {
                var slime = col.GetComponent<Slime>();
                if (slime == null || slime.health <= 0) continue;
                float d = Vector2.Distance(_pos, slime.transform.position);
                if (d < bestD && Vector2.Distance(playerPos, slime.transform.position) < SlimeRange + 1f) { bestD = d; best = slime; }
            }
            return best;
        }

        static Vector2 Clamp(Vector2 p, Vector2 home, float radius) => home + Vector2.ClampMagnitude(p - home, radius);

        void Befriend(PlayerController player)
        {
            if (player == null || Hud.Busy || player.Locked) return;
            Vector2 feet = (Vector2)player.transform.position + new Vector2(0f, 0.15f);
            if (Vector2.Distance(feet, _pos) > 1.6f) return;
            if (Inventory.SelectedItem != Items.WildBerries)
            {
                Hud.SetPrompt(Inventory.Has(Items.WildBerries) ? "A jackalope! Pick your wild berries to offer it some"
                    : "A jackalope! It keeps sniffing at the berry bushes");
                return;
            }
            Hud.SetPrompt("F  Offer the jackalope a wild berry");
            if (!GameInput.FishPressed() || Inventory.Remove(Items.WildBerries) == 0) return;
            _friend = true;
            _follow = true;
            _hopT = -1f;
            _height = 0f;
            Hud.ShowPopup(_frames[0], "The jackalope is your friend!",
                "It'll hop along with you and chase off slimes. Open your bag (Creatures) to tell it to follow you or stay home.");
        }
    }
}
