using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// Bee houses. Buy one from Mabel or make one at the workbench, pick it on
    /// the item bar and press F to set it down on any open grass. Bees buzz
    /// around it by day and fill it with honey every other morning, or every
    /// morning when your field is close by. No honey in winter. Face a full
    /// one and press F to collect; the hoe picks a bee house back up.
    /// </summary>
    public class Apiary : MonoBehaviour
    {
        /// <summary>How close (in tiles) a field has to be for the bees to make honey daily.</summary>
        const int FlowerRange = 3;
        const int MaxHives = 12;

        class Hive
        {
            public Vector2Int Cell;
            public GameObject Go;
            public SpriteRenderer Sr;
            public Transform[] Bees;
            public float[] Phase;
            public int Days;
            public bool Ready;
        }

        static Apiary _instance;
        readonly Dictionary<Vector2Int, Hive> _hives = new Dictionary<Vector2Int, Hive>();
        Sprite[] _frames, _beeFrames;

        public static int Count => _instance != null ? _instance._hives.Count : 0;

        public static void Export(List<SaveGame.HiveState> list)
        {
            if (_instance == null) return;
            foreach (var h in _instance._hives.Values)
                list.Add(new SaveGame.HiveState { x = h.Cell.x, y = h.Cell.y, days = h.Days, ready = h.Ready });
        }

        public static void Import(List<SaveGame.HiveState> list)
        {
            if (_instance == null) return;
            foreach (var s in list)
            {
                var h = _instance.Place(new Vector2Int(s.x, s.y));
                if (h == null) continue;
                h.Days = s.days;
                h.Ready = s.ready;
                _instance.Refresh(h);
            }
        }

        public void Build()
        {
            _instance = this;
            _frames = Art.Strip("beehouse", 16, 24, new Vector2(0.5f, 0f));
            _beeFrames = Art.Strip("bee", 5, 5);
            GameClock.NewDay += Morning;
        }

        void OnDestroy()
        {
            GameClock.NewDay -= Morning;
            if (_instance == this) _instance = null;
        }

        Hive Place(Vector2Int cell)
        {
            if (_hives.ContainsKey(cell) || _hives.Count >= MaxHives) return null;
            var go = new GameObject("Bee house");
            go.transform.SetParent(transform, false);
            go.transform.position = new Vector3(cell.x + 0.5f, cell.y + 0.1f, 0f);
            var sr = go.AddComponent<SpriteRenderer>();
            go.AddComponent<YSort>();
            var box = go.AddComponent<BoxCollider2D>();
            box.size = new Vector2(0.8f, 0.4f);
            box.offset = new Vector2(0f, 0.2f);

            var h = new Hive { Cell = cell, Go = go, Sr = sr, Bees = new Transform[3], Phase = new float[3] };
            for (int i = 0; i < h.Bees.Length; i++)
            {
                var bee = new GameObject("Bee").AddComponent<SpriteRenderer>();
                bee.transform.SetParent(go.transform, false);
                bee.sortingOrder = 31000;
                h.Bees[i] = bee.transform;
                h.Phase[i] = Random.Range(0f, 10f);
            }
            _hives[cell] = h;
            Refresh(h);
            return h;
        }

        void Refresh(Hive h)
        {
            if (_frames != null) h.Sr.sprite = _frames[h.Ready ? 1 : 0];
        }

        static bool NearField(Vector2Int cell)
        {
            for (int dx = -FlowerRange; dx <= FlowerRange; dx++)
            for (int dy = -FlowerRange; dy <= FlowerRange; dy++)
                if (FarmDemoWorld.IsSoil(cell + new Vector2Int(dx, dy))) return true;
            return false;
        }

        void Morning()
        {
            if (Seasons.Current == Season.Winter) return;
            foreach (var h in _hives.Values)
            {
                if (h.Ready) continue;
                h.Days++;
                if (h.Days >= (NearField(h.Cell) ? 1 : 2)) { h.Ready = true; h.Days = 0; }
                Refresh(h);
            }
        }

        void Update()
        {
            // Bees buzz about by day, outside winter.
            bool buzzing = Seasons.Current != Season.Winter && GameClock.Hour < 19f;
            foreach (var h in _hives.Values)
                for (int i = 0; i < h.Bees.Length; i++)
                {
                    var sr = h.Bees[i].GetComponent<SpriteRenderer>();
                    sr.enabled = buzzing && _beeFrames != null;
                    if (!sr.enabled) continue;
                    float t = Time.time * (1.3f + i * 0.4f) + h.Phase[i];
                    h.Bees[i].localPosition = new Vector3(Mathf.Sin(t) * 0.7f, 1.3f + Mathf.Sin(t * 2.3f) * 0.35f, 0f);
                    sr.sprite = _beeFrames[(int)(Time.time * 12f + i) % 2];
                    sr.flipX = Mathf.Cos(t) > 0f;
                }

            var player = PlayerController.Instance;
            if (player == null || Hud.Busy || player.Locked || player.IsAttacking || Home.Inside || Mine.Inside) return;
            Vector2 feet = (Vector2)player.transform.position + new Vector2(0f, 0.15f);
            Vector2 ahead = feet + Art.Dir(player.Facing) * 0.75f;
            var cell = new Vector2Int(Mathf.FloorToInt(ahead.x), Mathf.FloorToInt(ahead.y));
            var held = Inventory.SelectedItem;

            if (_hives.TryGetValue(cell, out var hive))
            {
                if (held == Items.Hoe)
                {
                    Hud.SetPrompt(hive.Ready ? "Collect the honey before you move it" : "F  Pick up the bee house");
                    if (hive.Ready || !GameInput.FishPressed()) return;
                    if (!Inventory.Add(Items.BeeHouse)) { Hud.Toast("Your bag is full!", 2f); return; }
                    Destroy(hive.Go);
                    _hives.Remove(cell);
                    return;
                }
                if (!hive.Ready)
                {
                    Hud.SetPrompt(Seasons.Current == Season.Winter ? "The bees are sleeping until spring"
                        : NearField(cell) ? "The bees are busy. Honey tomorrow" : "The bees are busy. Put it near your field for honey every day");
                    return;
                }
                Hud.SetPrompt("F  Collect the honey");
                if (!GameInput.FishPressed()) return;
                if (!Inventory.Add(Items.Honey)) { Hud.Toast("Your bag is full! Sell something to Mabel first.", 2.5f); return; }
                hive.Ready = false;
                Refresh(hive);
                Hud.Toast("+1 Honey! Sweet.", 1.5f);
                return;
            }

            if (held != Items.BeeHouse || !FarmDemoWorld.CanTill(cell)) return;
            if (_hives.Count >= MaxHives) { Hud.SetPrompt($"{MaxHives} bee houses is plenty!"); return; }
            Hud.SetPrompt("F  Set down the bee house");
            if (GameInput.FishPressed() && Inventory.Remove(Items.BeeHouse) > 0)
            {
                Place(cell);
                Hud.Toast("Bzzz. The bees are moving in.", 2f);
            }
        }
    }
}
