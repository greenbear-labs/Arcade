using System.Collections.Generic;
using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;
#endif

namespace FarmDemo
{
    /// <summary>
    /// On-screen controls for phones and tablets: drag anywhere on the left side
    /// for a joystick (push it all the way to run), and buttons on the right for
    /// Use, Hit, Talk, Bag and Sleep. Tapping the item bar picks a slot.
    /// They appear on a phone, or as soon as anything touches the screen.
    /// GameInput reads them alongside the keyboard; Hud draws them.
    /// </summary>
    [DefaultExecutionOrder(-1000)]   // read touches before anything asks GameInput
    public class TouchControls : MonoBehaviour
    {
        public enum Button { Use, Attack, Talk, Bag, Sleep }

        /// <summary>True once the game is being played by touch.</summary>
        public static bool Active { get; private set; }
        public static Vector2 Move { get; private set; }
        public static bool Run { get; private set; }

        static readonly bool[] Pressed = new bool[5];
        static readonly bool[] Held = new bool[5];
        public static bool WasPressed(Button b) => Pressed[(int)b];
        public static bool IsHeld(Button b) => Held[(int)b];

        // Joystick, in GUI coordinates (origin top left), for drawing.
        public static bool StickShown => _stickId >= 0;
        public static Vector2 StickBase { get; private set; }
        public static Vector2 StickKnob { get; private set; }
        public static float StickRadius => 26f * Scale;

        /// <summary>Same pixel scale as the HUD.</summary>
        public static float Scale => Mathf.Max(2, Mathf.RoundToInt(Screen.height / 270f));

        static int _stickId = -1;
        static readonly Dictionary<int, int> TouchOnButton = new Dictionary<int, int>();
        static readonly List<Vector2> Taps = new List<Vector2>();   // GUI coordinates, cleared each frame

        void Awake()
        {
            Active = Application.isMobilePlatform;
            Reset();
        }

        static void Reset()
        {
            _stickId = -1;
            TouchOnButton.Clear();
            Taps.Clear();
            Move = Vector2.zero;
            Run = false;
        }

        /// <summary>Where each button sits, in GUI coordinates (centre and radius).</summary>
        public static void Layout(Button b, out Vector2 centre, out float radius)
        {
            float s = Scale, w = Screen.width, h = Screen.height;
            switch (b)
            {
                case Button.Use: centre = new Vector2(w - 36 * s, h - 40 * s); radius = 21 * s; break;
                case Button.Attack: centre = new Vector2(w - 84 * s, h - 26 * s); radius = 17 * s; break;
                case Button.Talk: centre = new Vector2(w - 78 * s, h - 72 * s); radius = 16 * s; break;
                case Button.Bag: centre = new Vector2(w - 30 * s, h - 92 * s); radius = 13 * s; break;
                default: centre = new Vector2(w - 18 * s, 40 * s); radius = 12 * s; break;   // Sleep, under the clock
            }
        }

        public static string Label(Button b) =>
            b == Button.Use ? "USE" : b == Button.Attack ? "HIT" : b == Button.Talk ? "TALK" : b == Button.Bag ? "BAG" : "Zz";

        /// <summary>
        /// Did a touch start inside this rectangle this frame? Each tap answers once.
        /// Call from OnGUI; only the repaint pass counts, so a tap isn't used twice.
        /// </summary>
        public static bool Tapped(Rect r)
        {
            if (Event.current == null || Event.current.type != EventType.Repaint) return false;
            for (int i = 0; i < Taps.Count; i++)
            {
                if (!r.Contains(Taps[i])) continue;
                Taps.RemoveAt(i);
                return true;
            }
            return false;
        }

        void Update()
        {
            for (int i = 0; i < Pressed.Length; i++) { Pressed[i] = false; Held[i] = false; }
            Taps.Clear();

            var seen = new HashSet<int>();
            foreach (var t in ReadTouches())
            {
                Active = true;
                seen.Add(t.id);
                Vector2 gui = new Vector2(t.position.x, Screen.height - t.position.y);
                if (t.began) Begin(t.id, gui);
                if (t.id == _stickId) Drag(gui);
                if (TouchOnButton.TryGetValue(t.id, out int b)) Held[b] = true;
            }

            // Let go of whatever lifted.
            if (_stickId >= 0 && !seen.Contains(_stickId)) { _stickId = -1; Move = Vector2.zero; Run = false; }
            var lifted = new List<int>();
            foreach (var id in TouchOnButton.Keys) if (!seen.Contains(id)) lifted.Add(id);
            foreach (var id in lifted) TouchOnButton.Remove(id);
        }

        static void Begin(int id, Vector2 gui)
        {
            // Buttons first (hidden while the shop or bag is open, so taps reach the window).
            for (int b = 0; b < Pressed.Length && !Hud.MenuOpen && !GameClock.Sleeping; b++)
            {
                Layout((Button)b, out var c, out var r);
                if (Vector2.Distance(gui, c) > r * 1.15f) continue;
                Pressed[b] = Held[b] = true;
                TouchOnButton[id] = b;
                return;
            }
            // Anything else is a tap the HUD may want (item bar, shop buttons)...
            Taps.Add(gui);
            // ...and on the left side, outside any open window, it also starts the joystick.
            if (_stickId < 0 && gui.x < Screen.width * 0.45f && !Hud.WindowOpen && !Hud.OverItemBar(gui))
            {
                _stickId = id;
                StickBase = StickKnob = gui;
                Move = Vector2.zero;
            }
        }

        static void Drag(Vector2 gui)
        {
            Vector2 d = gui - StickBase;
            float r = StickRadius;
            if (d.magnitude > r) d = d.normalized * r;
            StickKnob = StickBase + d;
            Vector2 v = new Vector2(d.x, -d.y) / r;      // GUI y points down, the world's points up
            Move = v.magnitude < 0.15f ? Vector2.zero : v;
            Run = v.magnitude > 0.92f;
        }

        struct TouchPoint { public int id; public Vector2 position; public bool began; }

        static List<TouchPoint> ReadTouches()
        {
            var list = new List<TouchPoint>();
#if ENABLE_INPUT_SYSTEM
            var screen = Touchscreen.current;
            if (screen == null) return list;
            foreach (TouchControl t in screen.touches)
            {
                if (!t.press.isPressed && !t.press.wasPressedThisFrame) continue;
                list.Add(new TouchPoint { id = t.touchId.ReadValue(), position = t.position.ReadValue(), began = t.press.wasPressedThisFrame });
            }
#else
            for (int i = 0; i < Input.touchCount; i++)
            {
                var t = Input.GetTouch(i);
                if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) continue;
                list.Add(new TouchPoint { id = t.fingerId, position = t.position, began = t.phase == TouchPhase.Began });
            }
#endif
            return list;
        }
    }
}
