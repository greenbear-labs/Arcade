using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// Your farmhouse. Press E at the front door to go in; inside there's a bed
    /// (E to sleep) and a door mat to walk back out. You always wake up at home.
    /// The inside is a room built off to the side of the map; going through the
    /// door just moves you and the camera there.
    /// </summary>
    public class Home : MonoBehaviour
    {
        // Outside: the house sprite stands with its bottom-centre here; the door is in the middle.
        public static readonly Vector2 DoorOutside = new Vector2(20f, 19f);
        // Inside: an 8x6 tile room whose bottom-left corner is here.
        public static readonly Vector2 RoomOrigin = new Vector2(60f, 2f);
        const float RoomWidth = 8f, RoomHeight = 6f;

        static Vector2 RoomDoor => RoomOrigin + new Vector2(RoomWidth / 2f, 0.35f);
        static Vector2 BedSpot => RoomOrigin + new Vector2(1f, 2f);
        static Vector2 WakeSpot => RoomOrigin + new Vector2(2.3f, 2.6f);

        public static bool Inside { get; private set; }

        public static readonly Color32 OutdoorBackground = new Color32(0x2f, 0x7d, 0x3a, 0xff);
        static readonly Color32 IndoorBackground = new Color32(0x1a, 0x12, 0x10, 0xff);

        Sprite _prompt;
        SpriteRenderer _doorPrompt, _bedPrompt;

        public void Build(Transform parent)
        {
            _prompt = Art.Single("key_e", new Vector2(0.5f, 0f));

            // Outside.
            var house = new GameObject("Farmhouse (outside)");
            house.transform.SetParent(parent, false);
            house.transform.position = DoorOutside;
            house.AddComponent<SpriteRenderer>().sprite = Art.Single("house");
            house.AddComponent<YSort>();
            var walls = house.AddComponent<BoxCollider2D>();
            walls.size = new Vector2(3.5f, 1.9f);
            walls.offset = new Vector2(0f, 0.95f);
            _doorPrompt = MakePrompt(DoorOutside + new Vector2(0f, 2.3f));

            // Inside.
            var room = new GameObject("Farmhouse (inside)");
            room.transform.SetParent(parent, false);
            room.transform.position = RoomOrigin;
            var floor = room.AddComponent<SpriteRenderer>();
            floor.sprite = Art.Single("house_inside", Vector2.zero);
            floor.sortingOrder = -30000;
            Wall(room.transform, new Vector2(-0.1f, RoomHeight / 2f), new Vector2(0.4f, RoomHeight));             // left
            Wall(room.transform, new Vector2(RoomWidth + 0.1f, RoomHeight / 2f), new Vector2(0.4f, RoomHeight)); // right
            Wall(room.transform, new Vector2(RoomWidth / 2f, RoomHeight - 0.9f), new Vector2(RoomWidth, 1.8f));  // back wall
            Wall(room.transform, new Vector2(RoomWidth / 2f, -0.25f), new Vector2(RoomWidth, 0.5f));             // front

            var bed = new GameObject("Bed");
            bed.transform.SetParent(room.transform, false);
            bed.transform.position = BedSpot;
            bed.AddComponent<SpriteRenderer>().sprite = Art.Single("bed");
            bed.AddComponent<YSort>();
            var frame = bed.AddComponent<BoxCollider2D>();
            frame.size = new Vector2(0.85f, 1.7f);
            frame.offset = new Vector2(0f, 0.95f);
            _bedPrompt = MakePrompt(BedSpot + new Vector2(0f, 2.1f));

            GameClock.NewDay += WakeUp;
        }

        SpriteRenderer MakePrompt(Vector2 at)
        {
            var sr = new GameObject("Prompt").AddComponent<SpriteRenderer>();
            sr.transform.SetParent(transform, false);
            sr.transform.position = at;
            sr.sprite = _prompt;
            sr.sortingOrder = 32000;
            sr.enabled = false;
            return sr;
        }

        static void Wall(Transform parent, Vector2 localCenter, Vector2 size)
        {
            var go = new GameObject("Wall");
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localCenter;
            go.AddComponent<BoxCollider2D>().size = size;
        }

        void OnDestroy()
        {
            GameClock.NewDay -= WakeUp;
            Inside = false;
        }

        void Update()
        {
            _doorPrompt.enabled = _bedPrompt.enabled = false;
            var player = PlayerController.Instance;
            if (player == null || Hud.Busy || player.Locked) return;
            Vector2 feet = player.transform.position;
            float bob = Mathf.Sin(Time.time * 5f) > 0f ? 1f / FarmDemoConfig.PixelsPerUnit : 0f;

            if (!Inside)
            {
                bool atDoor = Vector2.Distance(feet, DoorOutside + new Vector2(0f, -0.3f)) < 0.8f && player.Facing == Facing.Up;
                if (!atDoor) return;
                ShowPrompt(_doorPrompt, DoorOutside + new Vector2(0f, 2.3f), bob);
                Hud.SetPrompt("E  Go inside");
                if (GameInput.TalkPressed()) Hud.Transition(() => GoInside(RoomDoor + new Vector2(0f, 0.6f), Facing.Up));
                return;
            }

            // Step on the door mat to leave.
            if (feet.y < RoomOrigin.y + 0.45f && Mathf.Abs(feet.x - RoomDoor.x) < 0.7f)
            {
                Hud.Transition(GoOutside);
                return;
            }

            if (Vector2.Distance(feet, BedSpot + new Vector2(0.3f, 0.9f)) < 1.3f)
            {
                ShowPrompt(_bedPrompt, BedSpot + new Vector2(0f, 2.1f), bob);
                Hud.SetPrompt("E  Go to bed");
                if (GameInput.TalkPressed()) GameClock.Sleep();
            }
        }

        static void ShowPrompt(SpriteRenderer sr, Vector2 at, float bob)
        {
            sr.enabled = true;
            sr.transform.position = at + new Vector2(0f, bob);
        }

        // Called every morning, while the screen is black.
        void WakeUp() => GoInside(WakeSpot, Facing.Down);

        static void GoInside(Vector2 spot, Facing facing)
        {
            Inside = true;
            Move(spot, facing, new Rect(RoomOrigin.x, RoomOrigin.y, RoomWidth, RoomHeight), IndoorBackground);
        }

        static void GoOutside()
        {
            Inside = false;
            Move(DoorOutside + new Vector2(0f, -0.6f), Facing.Down,
                new Rect(0f, 0f, FarmDemoConfig.MapWidth, FarmDemoConfig.MapHeight), OutdoorBackground);
        }

        /// <summary>Put the player somewhere and point the camera at that area (also used by the mine).</summary>
        public static void Move(Vector2 spot, Facing facing, Rect cameraBounds, Color background)
        {
            var player = PlayerController.Instance;
            if (player != null) player.Teleport(spot, facing);
            var cam = Camera.main;
            if (cam == null) return;
            cam.backgroundColor = background;
            var follow = cam.GetComponent<CameraFollow>();
            if (follow == null) return;
            follow.bounds = cameraBounds;
            follow.Snap();
        }
    }
}
