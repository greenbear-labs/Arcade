using UnityEngine;

namespace FarmDemo
{
    /// <summary>What food does when you eat it, and the boost a meal can give until bedtime.</summary>
    public static class Food
    {
        /// <summary>Fish Stew: you run faster until you sleep.</summary>
        public static bool Quick;

        /// <summary>Hearts this gives back when eaten. 0 means it isn't food.</summary>
        public static int Healing(ItemDef item)
        {
            if (item == Items.PumpkinPie) return PlayerStats.MaxHealth;
            if (item == Items.FishStew) return 4;
            if (item == Items.TurnipSoup || item == Items.Pumpkin || item == Items.Melon || item == Items.HoneyCake) return 3;
            if (item == Items.FriedEgg || item == Items.LargeEgg || item == Items.Cheese || item == Items.GoatCheese) return 2;
            if (item == Items.Turnip || item == Items.Strawberry || item == Items.Tomato || item == Items.Egg || item == Items.StrawberryJam ||
                item == Items.Milk || item == Items.GoatMilk ||
                item == Items.Carrot || item == Items.Corn || item == Items.Eggplant || item == Items.Honey) return 1;
            return 0;
        }

        /// <summary>Eat one: heal, and get the meal's boost. Returns what to tell the player.</summary>
        public static string Eat(ItemDef item)
        {
            int heal = Healing(item);
            if (heal <= 0 || Inventory.Remove(item) == 0) return null;
            PlayerStats.Health = Mathf.Min(PlayerStats.MaxHealth, PlayerStats.Health + heal);
            if (item == Items.FishStew) { Quick = true; return "Delicious! You feel quick on your feet until bedtime."; }
            return item == Items.PumpkinPie ? "The best pie in the valley. You feel brand new!" : "Crunch. You feel better.";
        }

        /// <summary>"F  Eat the fried egg (+2 hearts)"</summary>
        public static string Prompt(ItemDef item)
        {
            int heal = Mathf.Min(Healing(item), PlayerStats.MaxHealth - PlayerStats.Health);
            return $"F  Eat the {item.Name.ToLower()} (+{heal} heart{(heal == 1 ? "" : "s")})";
        }
    }

    /// <summary>Meals you can cook at the stove in your house. They heal more than raw food, sell for more, and make great gifts.</summary>
    public static class Cooking
    {
        public static readonly Recipe[] All =
        {
            new Recipe
            {
                Name = "Fried Egg", Icon = Items.FriedEgg, Makes = Items.FriedEgg,
                Text = "Heals 2 hearts. Mabel pays 80g.",
                Needs = new[] { (Items.Egg, 1) },
            },
            new Recipe
            {
                Name = "Turnip Soup", Icon = Items.TurnipSoup, Makes = Items.TurnipSoup,
                Text = "Heals 3 hearts. Grandpa's favourite.",
                Needs = new[] { (Items.Turnip, 2) },
            },
            new Recipe
            {
                Name = "Strawberry Jam", Icon = Items.StrawberryJam, Makes = Items.StrawberryJam,
                Text = "Sells for 300g. Mabel can't get enough.",
                Needs = new[] { (Items.Strawberry, 3) },
            },
            new Recipe
            {
                Name = "Fish Stew", Icon = Items.FishStew, Makes = Items.FishStew,
                Text = "Heals 4 hearts and you run faster until bedtime.",
                Needs = new[] { (Items.Bluegill, 1), (Items.Tomato, 1) },
            },
            new Recipe
            {
                Name = "Pumpkin Pie", Icon = Items.PumpkinPie, Makes = Items.PumpkinPie,
                Text = "Heals you fully. Sells for 420g.",
                Needs = new[] { (Items.Pumpkin, 1), (Items.Egg, 1) },
            },
            new Recipe
            {
                Name = "Honey Cake", Icon = Items.HoneyCake, Makes = Items.HoneyCake,
                Text = "Heals 3 hearts. Sells for 340g.",
                Needs = new[] { (Items.Honey, 1), (Items.Egg, 1) },
            },
        };
    }

    /// <summary>
    /// The stove in the farmhouse kitchen (E to cook), and eating: with food
    /// picked on the item bar, press F to eat it when you're hurt.
    /// </summary>
    public class Kitchen : MonoBehaviour
    {
        static Vector2 StoveSpot => Home.RoomOrigin + new Vector2(6.5f, 4.15f);
        SpriteRenderer _prompt;
        PlayerController _player;

        public void Build(Transform parent)
        {
            var stove = new GameObject("Stove");
            stove.transform.SetParent(parent, false);
            stove.transform.position = StoveSpot;
            stove.AddComponent<SpriteRenderer>().sprite = Art.Single("stove");
            stove.AddComponent<YSort>();
            var box = stove.AddComponent<BoxCollider2D>();
            box.size = new Vector2(0.9f, 0.4f);
            box.offset = new Vector2(0f, 0.2f);

            _prompt = new GameObject("Prompt").AddComponent<SpriteRenderer>();
            _prompt.transform.SetParent(stove.transform, false);
            _prompt.sprite = Art.Single("key_e", new Vector2(0.5f, 0f));
            _prompt.sortingOrder = 32000;
            _prompt.enabled = false;

            Food.Quick = false;
            GameClock.NewDay += Morning;
        }

        void OnDestroy() => GameClock.NewDay -= Morning;

        static void Morning() => Food.Quick = false;

        void Update()
        {
            _prompt.enabled = false;
            var player = PlayerController.Instance;
            if (player == null || Hud.Busy || player.Locked || player.IsAttacking) return;
            Vector2 feet = player.transform.position;

            if (Home.Inside && Vector2.Distance(feet, StoveSpot + new Vector2(0f, -0.5f)) < 1f && player.Facing == Facing.Up)
            {
                float bob = Mathf.Sin(Time.time * 5f) > 0f ? 1f / FarmDemoConfig.PixelsPerUnit : 0f;
                _prompt.enabled = true;
                _prompt.transform.localPosition = new Vector3(0f, 2.2f + bob, 0f);
                Hud.SetPrompt("E  Cook something");
                if (GameInput.TalkPressed()) Hud.OpenCooking();
                return;
            }

            // Eating, anywhere but the mine (which has its own) and not while facing your field or a villager,
            // where F already means harvest or give a gift.
            var held = Inventory.SelectedItem;
            if (Mine.Inside || Food.Healing(held) <= 0 || PlayerStats.Health >= PlayerStats.MaxHealth) return;
            Vector2 ahead = feet + new Vector2(0f, 0.15f) + Art.Dir(player.Facing) * 0.75f;
            if (FarmDemoWorld.IsSoil(new Vector2Int(Mathf.FloorToInt(ahead.x), Mathf.FloorToInt(ahead.y))) || Npc.AnyNear(feet)) return;
            var here = new Vector2Int(Mathf.FloorToInt(feet.x), Mathf.FloorToInt(feet.y));
            if (Animals.Covers(here) || Barn.Covers(here)) return;   // F there picks up eggs and milks
            Hud.SetPrompt(Food.Prompt(held));
            if (GameInput.FishPressed())
            {
                string said = Food.Eat(held);
                if (said != null) Hud.Toast(said, 2f);
            }
        }
    }
}
