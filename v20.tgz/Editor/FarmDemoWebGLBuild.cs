using System.IO;
using UnityEditor;
using UnityEngine;

namespace FarmDemo.EditorTools
{
    /// <summary>
    /// Tools > Farm Demo > Build WebGL (for the Arcade): builds the game for the web into
    /// Builds/WebGL. Copy the four files in Builds/WebGL/Build into the Arcade repo's
    /// games/mythica-farmer/Build folder to update the game there.
    /// </summary>
    public static class FarmDemoWebGLBuild
    {
        const string ScenePath = "Assets/Scenes/SampleScene.unity";
        const string BuildPath = "Builds/WebGL";

        [MenuItem("Tools/Farm Demo/Build WebGL (for the Arcade)")]
        public static void Build()
        {
            if (!File.Exists(ScenePath))
            {
                Debug.LogError("[Farm Demo] " + ScenePath + " is missing. The demo builds itself in an empty scene; save one there first.");
                return;
            }
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };

            PlayerSettings.productName = "Mythica Farmer";
            PlayerSettings.companyName = "Green Bear Labs";
            PlayerSettings.runInBackground = false;   // pause when the tab or app is in the background
            // Gzip with a decompression fallback runs on any web host, even one that can't set
            // Content-Encoding headers. Same settings as the other Arcade games.
            PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Gzip;
            PlayerSettings.WebGL.decompressionFallback = true;
            PlayerSettings.WebGL.nameFilesAsHashes = false;

            var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions
            {
                scenes = new[] { ScenePath },
                locationPathName = BuildPath,
                target = BuildTarget.WebGL,
                options = BuildOptions.None,
            });

            string result = $"{report.summary.result} ({report.summary.totalSize / (1024 * 1024)} MB, {report.summary.totalErrors} errors) at {BuildPath}";
            Debug.Log("[Farm Demo] WebGL build: " + result);
            Directory.CreateDirectory("Builds");
            File.WriteAllText("Builds/last-build.txt", result + "\n");
        }
    }
}
