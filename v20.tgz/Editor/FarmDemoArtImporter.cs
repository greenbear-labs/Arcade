using UnityEditor;
using UnityEngine;

namespace FarmDemo.EditorTools
{
    /// <summary>
    /// Pixel-art import settings for every image under a "FarmDemo" folder:
    /// Sprite, 16 pixels per unit, Point filtering, no compression, no mipmaps.
    /// Drop more art into Assets/FarmDemo/Resources/FarmDemo/ and it gets the same.
    /// </summary>
    class FarmDemoArtImporter : AssetPostprocessor
    {
        const string Folder = "Assets";

        // Any image in a Resources/FarmDemo folder, wherever the demo was unpacked.
        static bool IsDemoArt(string path) => path.Replace('\\', '/').Contains("/Resources/FarmDemo/");

        void OnPreprocessTexture()
        {
            if (!IsDemoArt(assetPath)) return;
            var importer = (TextureImporter)assetImporter;
            importer.textureType = TextureImporterType.Sprite;
            importer.spriteImportMode = SpriteImportMode.Single;
            importer.spritePixelsPerUnit = FarmDemoConfig.PixelsPerUnit;
            importer.filterMode = FilterMode.Point;
            importer.textureCompression = TextureImporterCompression.Uncompressed;
            importer.mipmapEnabled = false;
            importer.alphaIsTransparency = true;
            importer.npotScale = TextureImporterNPOTScale.None;
            importer.wrapMode = TextureWrapMode.Clamp;
            // Read on the CPU at runtime: the tileset to give each tile a padded border (see Art.PaddedSheet),
            // and the tileset, trees and bushes to repaint them for each season (see Seasons.Recolor).
            importer.isReadable = assetPath.EndsWith("/tiles.png") || assetPath.EndsWith("/tree.png") || assetPath.EndsWith("/bush.png");
        }

        // Bump this when the settings above change, so Unity re-imports the art with them.
        public override uint GetVersion() => 3;

        [MenuItem("Tools/Farm Demo/Fix Art Import Settings")]
        static void Reimport()
        {
            foreach (string guid in AssetDatabase.FindAssets("t:Texture2D", new[] { Folder }))
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                if (IsDemoArt(path)) AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);
            }
            Debug.Log("[Farm Demo] Art re-imported with pixel-art settings.");
        }
    }
}
