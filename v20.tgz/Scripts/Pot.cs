using System.Collections;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>A clay pot. Hit it and it breaks, spilling 1 to 3 coins.</summary>
    public class Pot : MonoBehaviour, IHittable
    {
        public Sprite brokenSprite;
        public int minCoins = 1, maxCoins = 3;
        bool _broken;

        public void Hit(Vector2 from, int damage)
        {
            if (_broken) return;
            _broken = true;

            var sprite = GetComponent<SpriteRenderer>();
            if (brokenSprite != null) sprite.sprite = brokenSprite;
            foreach (var col in GetComponents<Collider2D>()) col.enabled = false;

            int coins = Random.Range(minCoins, maxCoins + 1);
            for (int i = 0; i < coins; i++) Coin.Spawn(transform.position + new Vector3(0f, 0.3f));
            StartCoroutine(FadeAway(sprite));
        }

        IEnumerator FadeAway(SpriteRenderer sprite)
        {
            yield return new WaitForSeconds(0.8f);
            for (float t = 0f; t < 1f; t += Time.deltaTime / 0.4f)
            {
                sprite.color = new Color(1f, 1f, 1f, 1f - t);
                yield return null;
            }
            Destroy(gameObject);
        }
    }
}
