using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace FarmDemo
{
    /// <summary>
    /// All controls in one place. Works with either Unity input system.
    /// Keyboard: WASD/arrows move, Shift runs, Space/J/left-click attacks, E talks, F fishes/plants/harvests,
    /// I/Tab bag, 1-8 pick an item-bar slot, mouse wheel or Q / R turn the toolbelt, N sleeps, Esc closes windows.
    /// Touch: see TouchControls (joystick on the left, buttons on the right).
    /// Gamepad: left stick moves, B runs, X attacks, Y talks, A uses, Select bag, shoulders pick a slot, Start sleeps.
    /// </summary>
    public static class GameInput
    {
        public static Vector2 Move()
        {
            Vector2 v = Vector2.zero;
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            if (k != null)
            {
                if (k.aKey.isPressed || k.leftArrowKey.isPressed) v.x -= 1;
                if (k.dKey.isPressed || k.rightArrowKey.isPressed) v.x += 1;
                if (k.sKey.isPressed || k.downArrowKey.isPressed) v.y -= 1;
                if (k.wKey.isPressed || k.upArrowKey.isPressed) v.y += 1;
            }
            var pad = Gamepad.current;
            if (pad != null)
            {
                Vector2 stick = pad.leftStick.ReadValue();
                v += stick.sqrMagnitude > 0.04f ? stick : pad.dpad.ReadValue();
            }
#else
            v = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
#endif
            v += TouchControls.Move;
            return Vector2.ClampMagnitude(v, 1f);
        }

        public static bool Run()
        {
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            var pad = Gamepad.current;
            return TouchControls.Run || (k != null && (k.leftShiftKey.isPressed || k.rightShiftKey.isPressed))
                || (pad != null && pad.buttonEast.isPressed);
#else
            return TouchControls.Run || Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
#endif
        }

        public static bool AttackPressed()
        {
            if (BlimpBee.Riding) return false;     // nothing to swing at up there
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            var m = Mouse.current;
            var pad = Gamepad.current;
            // Once you're playing by touch, clicks are ignored: phones fake a click for every tap.
            return TouchControls.WasPressed(TouchControls.Button.Attack)
                || (k != null && (k.spaceKey.wasPressedThisFrame || k.jKey.wasPressedThisFrame))
                || (m != null && !TouchControls.Active && m.leftButton.wasPressedThisFrame)
                || (pad != null && pad.buttonWest.wasPressedThisFrame);
#else
            return TouchControls.WasPressed(TouchControls.Button.Attack)
                || Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.J)
                || (!TouchControls.Active && Input.GetMouseButtonDown(0));
#endif
        }

        public static bool FishPressed()
        {
            if (BlimpBee.Riding) return false;     // hands full of bee
            if (TouchControls.WasPressed(TouchControls.Button.Use)) return true;
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            var pad = Gamepad.current;
            return (k != null && k.fKey.wasPressedThisFrame) || (pad != null && pad.buttonSouth.wasPressedThisFrame);
#else
            return Input.GetKeyDown(KeyCode.F);
#endif
        }

        public static bool BagPressed()
        {
            if (TouchControls.WasPressed(TouchControls.Button.Bag)) return true;
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            var pad = Gamepad.current;
            return (k != null && (k.iKey.wasPressedThisFrame || k.tabKey.wasPressedThisFrame))
                || (pad != null && pad.selectButton.wasPressedThisFrame);
#else
            return Input.GetKeyDown(KeyCode.I) || Input.GetKeyDown(KeyCode.Tab);
#endif
        }

        public static bool TalkPressed() => !BlimpBee.Riding && TalkKey();

        /// <summary>E, even while riding the blimp bee (it means "land").</summary>
        public static bool TalkKey()
        {
            if (TouchControls.WasPressed(TouchControls.Button.Talk)) return true;
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            var pad = Gamepad.current;
            return (k != null && k.eKey.wasPressedThisFrame) || (pad != null && pad.buttonNorth.wasPressedThisFrame);
#else
            return Input.GetKeyDown(KeyCode.E);
#endif
        }

        /// <summary>A number key 1-8 pressed this frame, as a slot index 0-7, or -1.</summary>
        public static int SlotPressed()
        {
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            if (k == null) return -1;
            var keys = new[] { k.digit1Key, k.digit2Key, k.digit3Key, k.digit4Key, k.digit5Key, k.digit6Key, k.digit7Key, k.digit8Key };
            for (int i = 0; i < keys.Length; i++) if (keys[i].wasPressedThisFrame) return i;
#else
            for (int i = 0; i < 8; i++) if (Input.GetKeyDown(KeyCode.Alpha1 + i)) return i;
#endif
            return -1;
        }

        /// <summary>Mouse wheel, Q / R or shoulder buttons turn the toolbelt: -1 back, +1 forward, 0 for none.</summary>
        public static int CycleSlot()
        {
#if ENABLE_INPUT_SYSTEM
            var m = Mouse.current;
            var k = Keyboard.current;
            var pad = Gamepad.current;
            float wheel = m != null ? m.scroll.ReadValue().y : 0f;
            if (wheel < -0.01f || (k != null && k.rKey.wasPressedThisFrame) || (pad != null && pad.rightShoulder.wasPressedThisFrame)) return 1;
            if (wheel > 0.01f || (k != null && k.qKey.wasPressedThisFrame) || (pad != null && pad.leftShoulder.wasPressedThisFrame)) return -1;
#else
            float wheel = Input.mouseScrollDelta.y;
            if (wheel < -0.01f || Input.GetKeyDown(KeyCode.R)) return 1;
            if (wheel > 0.01f || Input.GetKeyDown(KeyCode.Q)) return -1;
#endif
            return 0;
        }

        public static bool SleepPressed()
        {
            if (TouchControls.WasPressed(TouchControls.Button.Sleep)) return true;
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            var pad = Gamepad.current;
            return (k != null && k.nKey.wasPressedThisFrame) || (pad != null && pad.startButton.wasPressedThisFrame);
#else
            return Input.GetKeyDown(KeyCode.N);
#endif
        }

        public static bool CancelPressed()
        {
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            var pad = Gamepad.current;
            return (k != null && k.escapeKey.wasPressedThisFrame) || (pad != null && pad.buttonEast.wasPressedThisFrame);
#else
            return Input.GetKeyDown(KeyCode.Escape);
#endif
        }
    }

    public static class Physics2DCompat
    {
        public static void SetVelocity(this Rigidbody2D body, Vector2 v)
        {
#if UNITY_6000_0_OR_NEWER
            body.linearVelocity = v;
#else
            body.velocity = v;
#endif
        }
    }
}
