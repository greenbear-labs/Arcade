using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// The farmer: walking, running, swinging a sword, and taking hits.
    /// Controls live in GameInput.cs.
    /// </summary>
    [RequireComponent(typeof(Rigidbody2D))]
    public class PlayerController : MonoBehaviour
    {
        public static PlayerController Instance { get; private set; }

        public float walkSpeed = FarmDemoConfig.WalkSpeed;
        public float runMultiplier = FarmDemoConfig.RunMultiplier;

        [Header("Attack")]
        public float attackFrameTime = 0.07f;   // 3 frames, so a swing lasts ~0.2s
        public float attackReach = 0.7f;        // how far in front the hit circle sits
        public float attackRadius = 0.6f;
        public int attackDamage = 1;

        [Header("Getting hurt")]
        public float invulnerableTime = 1f;
        public float knockbackSpeed = 7f;
        public float knockbackTime = 0.15f;

        Rigidbody2D _body;
        SpriteSheetAnimator _animator;
        SpriteRenderer _sprite;
        Sprite[][] _attackFrames;               // [Facing][frame]
        Vector2 _spawn;

        Vector2 _move;
        bool _running;
        Facing _facing = Facing.Down;
        float _attackClock = -1f;               // < 0 when not attacking
        bool _attackLanded;
        float _invulnerable;
        float _knockback;
        Vector2 _knockDir;

        /// <summary>Set by other systems (fishing) to freeze movement and attacks.</summary>
        public bool Locked { get; set; }
        public Facing Facing => _facing;
        public bool IsAttacking => _attackClock >= 0f;
        public event System.Action Hurt;

        /// <summary>Show a special pose (e.g. holding the rod). Null goes back to walking.</summary>
        public void ShowPose(Sprite pose)
        {
            if (_animator != null) _animator.Override(pose);
        }

        /// <summary>Jump straight to a spot (going through a door, waking up in bed).</summary>
        public void Teleport(Vector2 position, Facing facing)
        {
            if (IsAttacking) EndAttack();
            _knockback = 0f;
            _body.position = position;
            transform.position = position;
            _body.SetVelocity(Vector2.zero);
            _facing = facing;
        }

        /// <summary>Roughly the middle of the body, for pickups and enemies.</summary>
        public Vector2 Center => (Vector2)transform.position + new Vector2(0f, 0.4f);

        public void Init(Sprite[][] attackFrames)
        {
            _attackFrames = attackFrames;
        }

        void Awake()
        {
            Instance = this;
            _body = GetComponent<Rigidbody2D>();
            _animator = GetComponentInChildren<SpriteSheetAnimator>();
            _sprite = _animator != null ? _animator.GetComponent<SpriteRenderer>() : null;
            _spawn = transform.position;
        }

        void Update()
        {
            _move = Vector2.zero;
            _running = false;

            if (Locked)
            {
                // Whoever locked us (fishing) is in charge of the pose.
            }
            else if (Hud.Busy)
            {
                if (IsAttacking) EndAttack();
            }
            else if (_attackClock >= 0f)
            {
                UpdateAttack();
            }
            else
            {
                _move = GameInput.Move();
                _running = GameInput.Run();
                if ((GameInput.AttackPressed() || (Inventory.SelectedItem == Items.Sword && GameInput.FishPressed())) && _attackFrames != null) StartAttack();
            }

            bool moving = _move.sqrMagnitude > 0.01f;
            if (moving) _facing = FacingFor(_move, _facing);
            if (_animator != null) _animator.SetState(_facing, moving, _running ? runMultiplier : 1f);

            // Blink while invulnerable after a hit.
            if (_invulnerable > 0f) _invulnerable -= Time.deltaTime;
            if (_sprite != null) _sprite.enabled = _invulnerable <= 0f || Mathf.FloorToInt(Time.time * 16f) % 2 == 0;
        }

        void FixedUpdate()
        {
            if (_knockback > 0f)
            {
                _knockback -= Time.fixedDeltaTime;
                _body.SetVelocity(_knockDir * knockbackSpeed);
                return;
            }
            _body.SetVelocity(_move * walkSpeed * (_running ? runMultiplier : 1f) * (Food.Quick ? 1.3f : 1f) * (BlimpBee.Riding ? 1.5f : 1f));
        }

        // ------------------------------------------------------------- attack

        void StartAttack()
        {
            _attackClock = 0f;
            _attackLanded = false;
            UpdateAttack();
        }

        void UpdateAttack()
        {
            int frame = Mathf.FloorToInt(_attackClock / attackFrameTime);
            var frames = _attackFrames[(int)_facing];
            if (frame >= frames.Length) { EndAttack(); return; }

            _animator.Override(frames[frame]);
            if (frame >= 1 && !_attackLanded) { _attackLanded = true; LandHit(); }
            _attackClock += Time.deltaTime;
        }

        void EndAttack()
        {
            _attackClock = -1f;
            if (_animator != null) _animator.Override(null);
        }

        readonly HashSet<IHittable> _hitThisSwing = new HashSet<IHittable>();

        void LandHit()
        {
            Vector2 center = Center + Art.Dir(_facing) * attackReach;
            _hitThisSwing.Clear();
            foreach (var col in Physics2D.OverlapCircleAll(center, attackRadius))
            {
                if (col.attachedRigidbody == _body) continue;
                var target = col.GetComponentInParent<IHittable>();
                if (target != null && _hitThisSwing.Add(target)) target.Hit(Center, attackDamage * (Upgrades.Sword >= 1 ? 2 : 1));
            }
        }

        // ------------------------------------------------------------- damage

        public bool IsVulnerable => _invulnerable <= 0f && PlayerStats.Health > 0 && !BlimpBee.Riding;

        public void TakeDamage(int damage, Vector2 from)
        {
            if (!IsVulnerable) return;
            PlayerStats.Health = Mathf.Max(0, PlayerStats.Health - damage);
            _invulnerable = invulnerableTime;
            _knockback = knockbackTime;
            _knockDir = Center - from;
            _knockDir = _knockDir.sqrMagnitude > 0.0001f ? _knockDir.normalized : -Art.Dir(_facing);
            Hurt?.Invoke();
            if (PlayerStats.Health == 0) Faint();
        }

        void Faint()
        {
            _knockback = 0f;
            PlayerStats.Health = PlayerStats.MaxHealth;
            _invulnerable = invulnerableTime * 2f;
            if (Mine.Inside) { Mine.CarryOut(); return; }
            if (Cavern.Inside) { Cavern.CarryOut(); return; }

            Hud.Toast("You fainted! A passing goose carried you back to the crossroads.");
            _body.position = _spawn;
            transform.position = _spawn;
            _body.SetVelocity(Vector2.zero);
        }

        // ------------------------------------------------------------- helpers

        // Pick the facing from the stronger axis. On an exact diagonal keep the
        // current facing if it's one of the two, so the sprite doesn't flicker.
        static Facing FacingFor(Vector2 v, Facing current)
        {
            float ax = Mathf.Abs(v.x), ay = Mathf.Abs(v.y);
            Facing horizontal = v.x < 0 ? Facing.Left : Facing.Right;
            Facing vertical = v.y < 0 ? Facing.Down : Facing.Up;
            if (Mathf.Abs(ax - ay) < 0.01f && (current == horizontal || current == vertical)) return current;
            return ax > ay ? horizontal : vertical;
        }

        void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(Center + Art.Dir(_facing) * attackReach, attackRadius);
        }
    }
}
