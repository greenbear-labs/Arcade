namespace FarmDemo
{
    /// <summary>Gold and hit points. The HUD reads these every frame.</summary>
    public static class PlayerStats
    {
        public const int MaxHealth = 5;
        public static int Gold;
        public static int Health = MaxHealth;

        public static void Reset()
        {
            Gold = 0;
            Health = MaxHealth;
        }
    }

    /// <summary>Anything the player's swing can hit: pots, slimes.</summary>
    public interface IHittable
    {
        void Hit(UnityEngine.Vector2 from, int damage);
    }
}
