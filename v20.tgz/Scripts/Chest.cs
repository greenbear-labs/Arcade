using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>What's inside one chest: 16 slots, stacking like the bag.</summary>
    public class ChestBox
    {
        public const int Size = 16;
        public readonly Inventory.Stack[] Slots = new Inventory.Stack[Size];
        public Vector2Int Cell;
        public GameObject Go;

        public bool IsEmpty => System.Array.TrueForAll(Slots, st => st == null);

        public bool HasRoomFor(ItemDef item)
        {
            foreach (var st in Slots) if (st == null || (item.Stackable && st.Item == item)) return true;
            return false;
        }

        /// <summary>Put a whole stack in: on top of the same thing if it stacks, else in the first empty slot.</summary>
        public void Put(Inventory.Stack stack)
        {
            if (stack == null) return;
            if (stack.Item.Stackable)
                foreach (var st in Slots)
                    if (st != null && st.Item == stack.Item) { st.Count += stack.Count; return; }
            for (int i = 0; i < Size; i++)
                if (Slots[i] == null) { Slots[i] = stack; return; }
        }
    }

    /// <summary>
    /// Chests you make at the workbench (from wood) and set down on grass with F.
    /// Face one and press E to open it; the hoe picks up an empty one.
    /// </summary>
    public class Chests : MonoBehaviour
    {
        const int MaxChests = 20;
        static Chests _instance;
        readonly Dictionary<Vector2Int, ChestBox> _chests = new Dictionary<Vector2Int, ChestBox>();
        Sprite _sprite;

        public static void Export(List<SaveGame.ChestState> list)
        {
            if (_instance == null) return;
            foreach (var c in _instance._chests.Values)
            {
                var state = new SaveGame.ChestState { x = c.Cell.x, y = c.Cell.y };
                foreach (var st in c.Slots) state.slots.Add(st == null ? new SaveGame.Slot() : new SaveGame.Slot { item = st.Item.Name, count = st.Count });
                list.Add(state);
            }
        }

        public static void Import(List<SaveGame.ChestState> list)
        {
            if (_instance == null) return;
            foreach (var state in list)
            {
                var c = _instance.Place(new Vector2Int(state.x, state.y));
                if (c == null) continue;
                for (int i = 0; i < ChestBox.Size && i < state.slots.Count; i++)
                {
                    var item = Items.ByName(state.slots[i].item);
                    if (item != null && state.slots[i].count > 0 && !Toolbelt.IsTool(item))
                        c.Slots[i] = new Inventory.Stack { Item = item, Count = state.slots[i].count };
                }
            }
        }

        public void Build()
        {
            _instance = this;
            _sprite = Art.Single("chest");
        }

        void OnDestroy()
        {
            if (_instance == this) _instance = null;
        }

        ChestBox Place(Vector2Int cell)
        {
            if (_chests.ContainsKey(cell)) return null;
            var go = new GameObject("Chest");
            go.transform.SetParent(transform, false);
            go.transform.position = new Vector3(cell.x + 0.5f, cell.y + 0.15f, 0f);
            go.AddComponent<SpriteRenderer>().sprite = _sprite;
            go.AddComponent<YSort>();
            var box = go.AddComponent<BoxCollider2D>();
            box.size = new Vector2(0.85f, 0.45f);
            box.offset = new Vector2(0f, 0.22f);
            var c = new ChestBox { Cell = cell, Go = go };
            _chests[cell] = c;
            return c;
        }

        void Update()
        {
            var player = PlayerController.Instance;
            if (player == null || Hud.Busy || player.Locked || player.IsAttacking || Home.Inside || Mine.Inside || Cavern.Inside) return;
            Vector2 feet = (Vector2)player.transform.position + new Vector2(0f, 0.15f);
            Vector2 ahead = feet + Art.Dir(player.Facing) * 0.75f;
            var cell = new Vector2Int(Mathf.FloorToInt(ahead.x), Mathf.FloorToInt(ahead.y));
            var held = Inventory.SelectedItem;

            if (_chests.TryGetValue(cell, out var chest))
            {
                if (held == Items.Hoe && chest.IsEmpty)
                {
                    Hud.SetPrompt("F  Pick up the chest     E  Open");
                    if (GameInput.FishPressed())
                    {
                        Inventory.Add(Items.Chest);
                        Destroy(chest.Go);
                        _chests.Remove(cell);
                        return;
                    }
                }
                else Hud.SetPrompt("E  Open the chest");
                if (GameInput.TalkPressed()) Hud.OpenChest(chest);
                return;
            }

            if (held != Items.Chest || !FarmDemoWorld.CanTill(cell)) return;
            if (_chests.Count >= MaxChests) { Hud.SetPrompt($"{MaxChests} chests is plenty!"); return; }
            Hud.SetPrompt("F  Set down the chest");
            if (GameInput.FishPressed() && Inventory.Remove(Items.Chest) > 0)
            {
                Place(cell);
                Hud.Toast("Press E at the chest to put things in it.", 2.5f);
            }
        }
    }
}
