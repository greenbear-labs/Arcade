using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// Lower on screen draws in front, so the player can walk behind trees.
    /// Static objects sort once; moving ones every frame.
    /// </summary>
    public class YSort : MonoBehaviour
    {
        public bool isStatic = true;
        SpriteRenderer _renderer;

        void Start()
        {
            _renderer = GetComponent<SpriteRenderer>();
            Apply();
        }

        void LateUpdate()
        {
            if (!isStatic) Apply();
        }

        void Apply()
        {
            if (_renderer != null) _renderer.sortingOrder = Order(transform.position.y);
        }

        public static int Order(float y) => -Mathf.RoundToInt(y * 100f);
    }
}
