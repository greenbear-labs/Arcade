using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// A spinning gold coin. It hops out of whatever dropped it, then drifts
    /// toward the player when they get close and is collected on touch.
    /// </summary>
    public class Coin : MonoBehaviour
    {
        public int value = 1;
        public float hopTime = 0.45f;
        public float hopHeight = 0.6f;
        public float magnetRange = 1.6f;
        public float magnetSpeed = 7f;
        public float pickupRange = 0.45f;

        Sprite[] _frames;
        SpriteRenderer _sprite;
        Transform _visual;
        Vector2 _from, _to;
        float _age;

        public static Coin Spawn(Vector2 origin, int value = 1)
        {
            var frames = Art.Strip("coin", 8, 8, new Vector2(0.5f, 0f));
            if (frames == null) return null;

            var root = new GameObject("Coin");
            root.transform.position = origin;

            var shadow = new GameObject("Shadow").AddComponent<SpriteRenderer>();
            shadow.transform.SetParent(root.transform, false);
            shadow.transform.localScale = new Vector3(0.6f, 0.6f, 1f);
            shadow.sprite = Art.Single("shadow", new Vector2(0.5f, 0.5f));
            shadow.sortingOrder = FarmDemoWorld.ShadowOrder;

            var visual = new GameObject("Sprite").AddComponent<SpriteRenderer>();
            visual.transform.SetParent(root.transform, false);

            var coin = root.AddComponent<Coin>();
            coin.value = value;
            coin._frames = frames;
            coin._sprite = visual;
            coin._visual = visual.transform;
            coin._from = origin;
            Vector2 to = origin + Random.insideUnitCircle * 1.1f;
            var map = FarmDemoWorld.OutdoorBounds;
            if (map.Contains(origin))    // outdoors, keep coins off the edge; in the mine they land where they fall
            {
                to.x = Mathf.Clamp(to.x, map.xMin + 2.5f, map.xMax - 2.5f);
                to.y = Mathf.Clamp(to.y, map.yMin + 2.5f, map.yMax - 2.5f);
            }
            coin._to = to;
            return coin;
        }

        void Update()
        {
            _age += Time.deltaTime;

            float height;
            if (_age < hopTime)
            {
                float t = _age / hopTime;
                transform.position = Vector2.Lerp(_from, _to, t);
                height = 4f * hopHeight * t * (1f - t);       // a simple arc
            }
            else
            {
                height = 0.08f + Mathf.Sin(_age * 4f) * 0.04f; // gentle hover once landed
                var player = PlayerController.Instance;
                if (player != null)
                {
                    Vector2 toPlayer = player.Center - (Vector2)transform.position;
                    float d = toPlayer.magnitude;
                    if (d < pickupRange) { Collect(); return; }
                    if (d < magnetRange)
                        transform.position += (Vector3)(toPlayer / d * magnetSpeed * Time.deltaTime);
                }
            }

            _visual.localPosition = new Vector3(0f, height, 0f);
            _sprite.sprite = _frames[Mathf.FloorToInt(_age * 10f) % _frames.Length];
            _sprite.sortingOrder = YSort.Order(transform.position.y);
        }

        void Collect()
        {
            PlayerStats.Gold += value;
            Destroy(gameObject);
        }
    }
}
