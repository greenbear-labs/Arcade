using UnityEngine;

namespace FarmDemo
{
    public enum Facing { Down, Up, Left, Right }

    /// <summary>
    /// Plays a 4-direction walk cycle from a sliced sheet. Frame 0 of each
    /// direction is the idle pose. No Animator Controller needed.
    /// </summary>
    [RequireComponent(typeof(SpriteRenderer))]
    public class SpriteSheetAnimator : MonoBehaviour
    {
        public float framesPerSecond = FarmDemoConfig.WalkFps;

        Sprite[][] _frames;   // [facing][frame]
        SpriteRenderer _renderer;
        Facing _facing = Facing.Down;
        bool _moving;
        float _speedScale = 1f;
        float _clock;
        Sprite _override;

        public Facing Facing => _facing;

        public void Init(Sprite[][] framesByFacing)
        {
            _frames = framesByFacing;
            _renderer = GetComponent<SpriteRenderer>();
            Refresh();
        }

        public void SetState(Facing facing, bool moving, float speedScale = 1f)
        {
            if (moving && !_moving) _clock = 1f / framesPerSecond; // start on a step frame, feels snappier
            _facing = facing;
            _moving = moving;
            _speedScale = speedScale;
        }

        /// <summary>Show this sprite instead of the walk cycle (e.g. an attack frame). Pass null to go back.</summary>
        public void Override(Sprite sprite)
        {
            _override = sprite;
            if (_renderer != null) Refresh();
        }

        void Update()
        {
            if (_frames == null) return;
            _clock = _moving ? _clock + Time.deltaTime * _speedScale : 0f;
            Refresh();
        }

        void Refresh()
        {
            if (_override != null) { _renderer.sprite = _override; return; }
            var set = _frames[(int)_facing];
            int frame = _moving ? Mathf.FloorToInt(_clock * framesPerSecond) % set.Length : 0;
            _renderer.sprite = set[frame];
        }
    }
}
