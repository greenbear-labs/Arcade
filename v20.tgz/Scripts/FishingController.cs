using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// Fishing. With the rod picked on the item bar, face the pond and press F to cast.
    /// Wait a random time, then when the "!" appears press F again quickly.
    /// Too early, or too slow, and the fish gets away.
    /// </summary>
    [RequireComponent(typeof(PlayerController))]
    public class FishingController : MonoBehaviour
    {
        public float castTime = 0.35f;
        public float minWait = 1.5f, maxWait = 5f;
        [Tooltip("How long you have to press F after the ! appears.")]
        public float biteWindow = 0.75f;

        enum State { Idle, Casting, Waiting, Bite }

        // Rod tip in the "line out" pose, in pixels from the feet, per Facing (Down, Up, Left, Right).
        static readonly Vector2[] RodTip = { new Vector2(8, -3), new Vector2(-4, 22), new Vector2(-13, 13), new Vector2(13, 13) };

        PlayerController _player;
        Sprite[][] _poses;              // [Facing][0 = cast, 1 = line out]
        SpriteRenderer _bobber, _alert;
        LineRenderer _line;
        State _state;
        float _timer, _waitFor;
        Vector2 _spot;

        public bool IsFishing => _state != State.Idle;

        public void Init(Sprite[][] poses)
        {
            _poses = poses;
        }

        void Awake()
        {
            _player = GetComponent<PlayerController>();
            _player.Hurt += () => { if (IsFishing) Stop("Ouch! You dropped your line."); };

            _bobber = new GameObject("Bobber").AddComponent<SpriteRenderer>();
            _bobber.sprite = Art.Single("bobber", new Vector2(0.5f, 0.3f));
            _bobber.sortingOrder = FarmDemoWorld.ShadowOrder + 10;   // on the water, under everything else
            _bobber.enabled = false;

            _alert = new GameObject("Bite alert").AddComponent<SpriteRenderer>();
            _alert.transform.SetParent(transform, false);
            _alert.transform.localPosition = new Vector3(0f, 1.85f, 0f);
            _alert.sprite = Art.Single("exclaim");
            _alert.sortingOrder = 32000;
            _alert.enabled = false;

            // In a build, Shader.Find only finds shaders that were included, so fall back to
            // the material the player's own sprite already uses.
            var shader = Shader.Find("Sprites/Default");
            var spriteMaterial = GetComponentInChildren<SpriteRenderer>() != null ? GetComponentInChildren<SpriteRenderer>().sharedMaterial : null;
            if (shader != null || spriteMaterial != null)
            {
                _line = new GameObject("Fishing line").AddComponent<LineRenderer>();
                _line.material = shader != null ? new Material(shader) : spriteMaterial;
                _line.startColor = _line.endColor = new Color(0.95f, 0.95f, 0.95f, 0.85f);
                _line.startWidth = _line.endWidth = 1f / FarmDemoConfig.PixelsPerUnit;
                _line.positionCount = 2;
                _line.enabled = false;
            }
        }

        void OnDestroy()
        {
            if (_bobber != null) Destroy(_bobber.gameObject);
            if (_line != null) Destroy(_line.gameObject);
        }

        void Update()
        {
            switch (_state)
            {
                case State.Idle: UpdateIdle(); break;
                case State.Casting: UpdateCasting(); break;
                case State.Waiting: UpdateWaiting(); break;
                case State.Bite: UpdateBite(); break;
            }
            if (_state != State.Idle) DrawLine();
        }

        void UpdateIdle()
        {
            if (_poses == null || Inventory.SelectedItem != Items.FishingRod || Hud.Busy || _player.IsAttacking) return;
            if (!FindWater(out _spot)) return;

            Hud.SetPrompt("F  Cast your line");
            if (!GameInput.FishPressed()) return;

            _state = State.Casting;
            _timer = 0f;
            _player.Locked = true;
            _player.ShowPose(_poses[(int)_player.Facing][0]);
        }

        void UpdateCasting()
        {
            _timer += Time.deltaTime;
            if (_timer < castTime) return;

            _player.ShowPose(_poses[(int)_player.Facing][1]);
            _bobber.transform.position = _spot;
            _bobber.enabled = true;
            _state = State.Waiting;
            _timer = 0f;
            _waitFor = Random.Range(minWait, maxWait);
        }

        void UpdateWaiting()
        {
            if (WantsToLeave()) { Stop(null); return; }
            if (GameInput.FishPressed()) { Stop("Too soon! Nothing was biting yet."); return; }

            _timer += Time.deltaTime;
            Bob(Mathf.Sin(_timer * 3f) > 0f ? 1 : 0);   // a lazy one-pixel bob
            if (_timer < _waitFor) return;

            _state = State.Bite;
            _timer = 0f;
            _alert.enabled = true;
        }

        void UpdateBite()
        {
            if (WantsToLeave()) { Stop(null); return; }
            if (GameInput.FishPressed()) { Catch(); return; }

            _timer += Time.deltaTime;
            Bob(Mathf.FloorToInt(_timer * 14f) % 2 == 0 ? -2 : -1);       // tugged under
            _alert.enabled = Mathf.FloorToInt(_timer * 10f) % 2 == 0;      // flashing "!"
            if (_timer > biteWindow) Stop("It got away...");
        }

        void Catch()
        {
            // 40% bluegill, 35% carp, 15% golden trout, 10% boot.
            float roll = Random.value;
            ItemDef caught = roll < 0.40f ? Items.Bluegill : roll < 0.75f ? Items.Carp : roll < 0.90f ? Items.GoldenTrout : Items.OldBoot;

            Stop(null);
            if (!Inventory.Add(caught))
            {
                Hud.Toast("Your bag is full! You let it go.");
                return;
            }

            if (caught == Items.OldBoot)
                Hud.ShowPopup(caught.Icon, "You caught... an Old Boot.", "Gil would be so proud.");
            else
                Hud.ShowPopup(caught.Icon, $"You caught a {caught.Name}!", $"It's {Random.Range(12, caught == Items.GoldenTrout ? 61 : 41)} cm long. Into the bag it goes.");
        }

        void Stop(string message)
        {
            _state = State.Idle;
            _bobber.enabled = false;
            _alert.enabled = false;
            if (_line != null) _line.enabled = false;
            _player.ShowPose(null);
            _player.Locked = false;
            if (message != null) Hud.Toast(message, 2f);
        }

        bool WantsToLeave() => GameInput.Move().sqrMagnitude > 0.25f;

        void Bob(int pixels)
        {
            _bobber.transform.position = _spot + new Vector2(0f, pixels / (float)FarmDemoConfig.PixelsPerUnit);
        }

        void DrawLine()
        {
            if (_line == null) return;
            bool show = _state != State.Casting;
            _line.enabled = show;
            if (!show) return;
            Vector2 tip = (Vector2)transform.position + RodTip[(int)_player.Facing] / FarmDemoConfig.PixelsPerUnit;
            _line.SetPosition(0, tip);
            _line.SetPosition(1, _bobber.transform.position);
            _line.sortingOrder = YSort.Order(transform.position.y) + 1;
        }

        /// <summary>Is there water just in front of the player? If so, where the bobber lands.</summary>
        bool FindWater(out Vector2 spot)
        {
            Vector2 feet = transform.position;
            Vector2 dir = Art.Dir(_player.Facing);
            for (float d = 0.3f; d <= 1.3f; d += 0.1f)
            {
                Vector2 p = feet + dir * d;
                if (!FarmDemoWorld.IsWater(p)) continue;
                Vector2 further = p + dir * 1.2f;
                spot = FarmDemoWorld.IsWater(further) ? further : p + dir * 0.5f;
                return true;
            }
            spot = default;
            return false;
        }
    }
}
