using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>A kind of crop: which seeds plant it, what it grows into, how fast, and in which seasons.</summary>
    public class CropDef
    {
        public readonly string Name;
        public readonly ItemDef Seeds, Produce;
        public readonly int SheetRow;        // row in crops.png: seed, sprout, growing, ripe
        public readonly int DaysToRipe;
        public readonly int MinYield, MaxYield;
        /// <summary>What Mabel charges for a packet of the seeds.</summary>
        public readonly int SeedPrice;
        readonly Season[] _seasons;

        public CropDef(string name, ItemDef seeds, ItemDef produce, int sheetRow, int daysToRipe, int seedPrice, Season[] seasons,
            int minYield = 1, int maxYield = 1)
        {
            SeedPrice = seedPrice;
            _seasons = seasons;
            Name = name;
            Seeds = seeds;
            Produce = produce;
            SheetRow = sheetRow;
            DaysToRipe = daysToRipe;
            MinYield = minYield;
            MaxYield = maxYield;
        }

        public bool InSeason(Season s) => System.Array.IndexOf(_seasons, s) >= 0;

        public static readonly CropDef Turnip = new CropDef("Turnip", Items.TurnipSeeds, Items.Turnip, 0, 2, 20,
            new[] { Season.Spring, Season.Fall });
        public static readonly CropDef Strawberry = new CropDef("Strawberry", Items.StrawberrySeeds, Items.Strawberry, 1, 3, 50,
            new[] { Season.Spring }, 2, 3);
        public static readonly CropDef Tomato = new CropDef("Tomato", Items.TomatoSeeds, Items.Tomato, 2, 3, 35,
            new[] { Season.Summer }, 2, 3);
        public static readonly CropDef Pumpkin = new CropDef("Pumpkin", Items.PumpkinSeeds, Items.Pumpkin, 3, 4, 80,
            new[] { Season.Fall });
        public static readonly CropDef Carrot = new CropDef("Carrot", Items.CarrotSeeds, Items.Carrot, 5, 2, 15,
            new[] { Season.Spring }, 1, 2);
        public static readonly CropDef Corn = new CropDef("Corn", Items.CornSeeds, Items.Corn, 6, 3, 40,
            new[] { Season.Summer, Season.Fall }, 2, 3);
        public static readonly CropDef Melon = new CropDef("Melon", Items.MelonSeeds, Items.Melon, 7, 4, 90,
            new[] { Season.Summer });
        public static readonly CropDef Eggplant = new CropDef("Eggplant", Items.EggplantSeeds, Items.Eggplant, 8, 3, 30,
            new[] { Season.Fall }, 2, 3);
        // Flowers: pretty, and worth something to Mabel. A certain fuzzy someone loves lavender.
        public static readonly CropDef Tulip = new CropDef("Tulip", Items.TulipBulbs, Items.Tulip, 9, 2, 20,
            new[] { Season.Spring }, 1, 2);
        public static readonly CropDef Sunflower = new CropDef("Sunflower", Items.SunflowerSeeds, Items.Sunflower, 10, 3, 40,
            new[] { Season.Summer, Season.Fall });
        public static readonly CropDef Lavender = new CropDef("Lavender", Items.LavenderSeeds, Items.Lavender, 11, 2, 30,
            new[] { Season.Spring, Season.Summer }, 1, 2);
        public static readonly CropDef[] All = { Turnip, Strawberry, Carrot, Tomato, Corn, Melon, Pumpkin, Eggplant, Tulip, Sunflower, Lavender };

        /// <summary>Row in crops.png whose first frame is a wilted plant.</summary>
        public const int WiltedRow = 4;

        public static CropDef ForSeeds(ItemDef seeds)
        {
            foreach (var c in All) if (c.Seeds == seeds) return c;
            return null;
        }
    }

    /// <summary>
    /// Everything you do to the ground. Face a tile and press F with the right
    /// item picked on the hotbar: the hoe turns grass into soil, seeds plant,
    /// the watering can waters (and refills at the pond), and any ripe crop gets
    /// picked. Crops grow one step each morning, but only if they were watered,
    /// and a crop wilts when its season ends (clear it away with F).
    /// </summary>
    [RequireComponent(typeof(PlayerController))]
    public class FarmingController : MonoBehaviour
    {
        class Crop
        {
            public CropDef Def;
            public int Days;
            public bool Wilted;
            public SpriteRenderer Renderer;
            public bool Ripe => !Wilted && Days >= Def.DaysToRipe;
        }

        const int WetOrder = FarmDemoWorld.ShadowOrder - 500;   // above the ground, under shadows

        static readonly Dictionary<Vector2Int, Crop> Crops = new Dictionary<Vector2Int, Crop>();
        static readonly Dictionary<Vector2Int, SpriteRenderer> Wet = new Dictionary<Vector2Int, SpriteRenderer>();

        static FarmingController _instance;
        PlayerController _player;
        SpriteRenderer _cursor;
        Sprite[][] _stages;     // [crop row][stage]
        Sprite _wetSprite;
        Sprite[] _splash, _puff;
        Transform _field;

        void Awake()
        {
            _player = GetComponent<PlayerController>();
            _stages = Art.Sheet("crops", 16, 16);
            _wetSprite = Art.Single("soil_wet", new Vector2(0.5f, 0.5f));
            _splash = Art.Strip("splash", 16, 16, new Vector2(0.5f, 0.5f));
            _puff = Art.Strip("puff", 16, 16, new Vector2(0.5f, 0.5f));
            _field = new GameObject("Crops").transform;

            _cursor = new GameObject("Tile cursor").AddComponent<SpriteRenderer>();
            _cursor.sprite = Art.Single("tile_cursor", new Vector2(0.5f, 0.5f));
            _cursor.sortingOrder = 31000;
            _cursor.enabled = false;

            Crops.Clear();
            Wet.Clear();
            _instance = this;
            GameClock.NewDay += Grow;
        }

        /// <summary>Put a saved sprinkler back in the field.</summary>
        public static void PlaceSprinkler(Vector2Int cell)
        {
            if (_instance != null && FarmDemoWorld.IsSoil(cell)) Sprinklers.Place(cell, _instance._field);
        }

        /// <summary>Everything planted, for the save.</summary>
        public static void Export(List<SaveGame.CropState> into)
        {
            foreach (var pair in Crops)
                into.Add(new SaveGame.CropState { x = pair.Key.x, y = pair.Key.y, crop = pair.Value.Def.Name, days = pair.Value.Days, wilted = pair.Value.Wilted });
        }

        /// <summary>Replant a saved field.</summary>
        public static void Import(List<SaveGame.CropState> crops)
        {
            if (_instance == null || _instance._stages == null) return;
            foreach (var c in crops)
            {
                var def = System.Array.Find(CropDef.All, d => d.Name == c.crop);
                var cell = new Vector2Int(c.x, c.y);
                if (def == null || !FarmDemoWorld.IsSoil(cell) || Crops.ContainsKey(cell)) continue;
                var crop = _instance.NewCrop(cell, def);
                crop.Days = Mathf.Clamp(c.days, 0, def.DaysToRipe);
                crop.Wilted = c.wilted;
                _instance.Refresh(crop);
            }
        }

        void OnDestroy()
        {
            if (_instance == this) _instance = null;
            GameClock.NewDay -= Grow;
            if (_cursor != null) Destroy(_cursor.gameObject);
            if (_field != null) Destroy(_field.gameObject);
        }

        void Update()
        {
            _cursor.enabled = false;
            if (_stages == null || Hud.Busy || _player.Locked || _player.IsAttacking) return;

            // The tile just in front of your feet.
            Vector2 feet = (Vector2)transform.position + new Vector2(0f, 0.15f);
            Vector2 ahead = feet + Art.Dir(_player.Facing) * 0.75f;
            var cell = new Vector2Int(Mathf.FloorToInt(ahead.x), Mathf.FloorToInt(ahead.y));
            var held = Inventory.SelectedItem;
            bool use = GameInput.FishPressed();

            // Refill the can at the pond.
            if (held == Items.WateringCan && FishingWater(feet))
            {
                if (Inventory.Water >= Inventory.WaterMax) { Hud.SetPrompt("Your watering can is full"); return; }
                Hud.SetPrompt("F  Fill the watering can");
                if (use)
                {
                    Inventory.Water = Inventory.WaterMax;
                    Effect(_splash, feet + Art.Dir(_player.Facing) * 1.1f);
                    Hud.Toast("Glug glug. The can is full.", 1.5f);
                }
                return;
            }

            if (!FarmDemoWorld.IsSoil(cell))
            {
                if (held != Items.Hoe || !FarmDemoWorld.CanTill(cell)) return;
                ShowCursor(cell);
                Hud.SetPrompt("F  Dig up the grass");
                if (use)
                {
                    foreach (var c in ToolCells(cell, Upgrades.Hoe >= 1))
                    {
                        if (!FarmDemoWorld.CanTill(c)) continue;
                        FarmDemoWorld.Till(c);
                        Effect(_puff, CellCenter(c));
                    }
                }
                return;
            }

            ShowCursor(cell);
            Crops.TryGetValue(cell, out var crop);
            bool wet = Wet.ContainsKey(cell);

            // Sprinklers: place one on bare soil, or pick it back up with the hoe.
            if (Sprinklers.Has(cell))
            {
                if (held != Items.Hoe) { Hud.SetPrompt("A sprinkler. It waters the tiles around it each morning."); return; }
                Hud.SetPrompt("F  Pick up the sprinkler");
                if (use && Inventory.Add(Items.Sprinkler)) Sprinklers.Remove(cell);
                return;
            }
            if (held == Items.Sprinkler && crop == null)
            {
                Hud.SetPrompt("F  Place the sprinkler");
                if (use && Inventory.Remove(Items.Sprinkler) > 0)
                {
                    Sprinklers.Place(cell, _field);
                    StartCoroutine(Squash(_field.GetChild(_field.childCount - 1)));
                }
                return;
            }

            if (crop != null && crop.Wilted)
            {
                Hud.SetPrompt($"F  Clear the wilted {crop.Def.Name.ToLower()}");
                if (use)
                {
                    Crops.Remove(cell);
                    Destroy(crop.Renderer.gameObject);
                    Effect(_puff, CellCenter(cell));
                }
                return;
            }

            if (crop != null && crop.Ripe)
            {
                Hud.SetPrompt($"F  Harvest {crop.Def.Name}");
                if (use) Harvest(cell, crop);
                return;
            }

            // The shovel fills a tile back in. Grass grows over it again in a few days.
            if (held == Items.Shovel)
            {
                if (crop != null) { Hud.SetPrompt($"{crop.Def.Name} is growing here. Harvest it first"); return; }
                Hud.SetPrompt("F  Fill in the soil");
                if (use)
                {
                    FarmDemoWorld.Untill(cell);
                    if (Wet.TryGetValue(cell, out var w))
                    {
                        if (w != null) Destroy(w.gameObject);
                        Wet.Remove(cell);
                    }
                    Effect(_puff, CellCenter(cell));
                }
                return;
            }

            if (held == Items.WateringCan)
            {
                if (wet) Hud.SetPrompt(crop != null ? $"{crop.Def.Name}: watered for today" : "Already watered");
                else if (Inventory.Water <= 0) Hud.SetPrompt("The can is empty. Fill it at the pond.");
                else
                {
                    Hud.SetPrompt("F  Water");
                    if (use)
                        foreach (var c in ToolCells(cell, Upgrades.Can >= 1))
                            if (Inventory.Water > 0 && FarmDemoWorld.IsSoil(c) && !Wet.ContainsKey(c) && !Sprinklers.Has(c)) Water(c);
                }
                return;
            }

            if (crop != null)
            {
                int left = crop.Def.DaysToRipe - crop.Days;
                Hud.SetPrompt($"{crop.Def.Name}: ripe in {left} day{(left == 1 ? "" : "s")}" + (wet ? "" : ". Needs water!"));
                return;
            }

            var def = held != null ? CropDef.ForSeeds(held) : null;
            var season = Seasons.Current;
            if (def != null && !def.InSeason(season))
            {
                Hud.SetPrompt(season == Season.Winter ? "Nothing grows in winter. Plant again in spring."
                    : $"{def.Name}s don't grow in {season.ToString().ToLower()}");
            }
            else if (def != null)
            {
                Hud.SetPrompt($"F  Plant {held.Name}");
                if (use) Plant(cell, def);
            }
            else if (System.Array.Exists(CropDef.All, c => Inventory.Has(c.Seeds)))
            {
                Hud.SetPrompt("Pick your seeds on the item bar (tap them, or press 1-8)");
            }
        }

        bool FishingWater(Vector2 feet)
        {
            Vector2 dir = Art.Dir(_player.Facing);
            for (float d = 0.3f; d <= 1.3f; d += 0.2f)
                if (FarmDemoWorld.IsWater(feet + dir * d)) return true;
            return false;
        }

        void ShowCursor(Vector2Int cell)
        {
            _cursor.enabled = true;
            _cursor.transform.position = CellCenter(cell);
            _cursor.color = new Color(1f, 1f, 1f, 0.6f + 0.4f * Mathf.Abs(Mathf.Sin(Time.time * 4f)));
        }

        static Vector3 CellCenter(Vector2Int cell) => new Vector3(cell.x + 0.5f, cell.y + 0.5f, 0f);

        // The tile you face, plus (with an upgraded tool) the two beside it.
        IEnumerable<Vector2Int> ToolCells(Vector2Int cell, bool wide)
        {
            yield return cell;
            if (!wide) yield break;
            var f = _player.Facing;
            var side = f == Facing.Up || f == Facing.Down ? Vector2Int.right : Vector2Int.up;
            yield return cell + side;
            yield return cell - side;
        }

        void MakeWet(Vector2Int cell)
        {
            var sr = new GameObject("Wet soil").AddComponent<SpriteRenderer>();
            sr.transform.SetParent(_field, false);
            sr.transform.position = CellCenter(cell);
            sr.sprite = _wetSprite;
            sr.sortingOrder = WetOrder;
            Wet[cell] = sr;
        }

        void Water(Vector2Int cell)
        {
            Inventory.Water--;
            MakeWet(cell);
            Effect(_splash, CellCenter(cell));
        }

        void Plant(Vector2Int cell, CropDef def)
        {
            if (Inventory.Remove(def.Seeds) == 0) return;
            var crop = NewCrop(cell, def);
            Refresh(crop);
            StartCoroutine(Squash(crop.Renderer.transform));
        }

        Crop NewCrop(Vector2Int cell, CropDef def)
        {
            var go = new GameObject(def.Name);
            go.transform.SetParent(_field, false);
            go.transform.position = new Vector3(cell.x + 0.5f, cell.y + 1f / FarmDemoConfig.PixelsPerUnit, 0f);
            var sr = go.AddComponent<SpriteRenderer>();
            go.AddComponent<YSort>();
            var crop = new Crop { Def = def, Days = 0, Renderer = sr };
            Crops[cell] = crop;
            return crop;
        }

        void Harvest(Vector2Int cell, Crop crop)
        {
            int amount = Random.Range(crop.Def.MinYield, crop.Def.MaxYield + 1);
            if (!Inventory.Add(crop.Def.Produce, amount))
            {
                Hud.Toast("Your bag is full! Sell something to Mabel first.", 2.5f);
                return;
            }
            Crops.Remove(cell);
            Destroy(crop.Renderer.gameObject);
            StartCoroutine(PopUp(crop.Def.Produce.Icon, new Vector2(cell.x + 0.5f, cell.y + 0.5f)));
            Hud.Toast(amount > 1 ? $"+{amount} {crop.Def.Produce.Name}s!" : $"+1 {crop.Def.Produce.Name}!", 1.5f);
        }

        // Each morning: crops out of season wilt, watered crops grow a step, then the soil dries out.
        void Grow()
        {
            var season = Seasons.Current;
            foreach (var pair in Crops)
            {
                var crop = pair.Value;
                if (!crop.Def.InSeason(season)) crop.Wilted = true;
                if (!crop.Wilted && !crop.Ripe && Wet.ContainsKey(pair.Key)) crop.Days++;
                Refresh(crop);
            }
            foreach (var sr in Wet.Values) if (sr != null) Destroy(sr.gameObject);
            Wet.Clear();

            // Then the sprinklers come on, so today's crops are watered.
            foreach (var s in Sprinklers.Cells)
                for (int dx = -1; dx <= 1; dx++)
                for (int dy = -1; dy <= 1; dy++)
                {
                    var c = s + new Vector2Int(dx, dy);
                    if (c != s && FarmDemoWorld.IsSoil(c) && !Wet.ContainsKey(c) && !Sprinklers.Has(c)) MakeWet(c);
                }
        }

        void Refresh(Crop crop)
        {
            // Seed on day 0, sprout on day 1, growing in between, ripe on the last day.
            if (crop.Wilted) { crop.Renderer.sprite = _stages[CropDef.WiltedRow][0]; return; }
            int d = crop.Days, total = crop.Def.DaysToRipe;
            int stage = d >= total ? 3 : d == 0 ? 0 : Mathf.Min(2, 1 + (d - 1) / Mathf.Max(1, total - 2));
            crop.Renderer.sprite = _stages[crop.Def.SheetRow][stage];
        }

        // A little squash when something goes in the ground.
        static IEnumerator Squash(Transform t)
        {
            for (float k = 0f; k < 1f; k += Time.deltaTime / 0.2f)
            {
                if (t == null) yield break;
                float s = 1f + 0.3f * Mathf.Sin(k * Mathf.PI);
                t.localScale = new Vector3(s, 2f - s, 1f);
                yield return null;
            }
            if (t != null) t.localScale = Vector3.one;
        }

        // A short sprite animation that plays once and cleans itself up.
        void Effect(Sprite[] frames, Vector2 at)
        {
            if (frames != null) StartCoroutine(PlayEffect(frames, at));
        }

        static IEnumerator PlayEffect(Sprite[] frames, Vector2 at)
        {
            var sr = new GameObject("Effect").AddComponent<SpriteRenderer>();
            sr.transform.position = at;
            sr.sortingOrder = 31200;
            foreach (var f in frames)
            {
                sr.sprite = f;
                yield return new WaitForSeconds(0.07f);
            }
            Destroy(sr.gameObject);
        }

        // The picked crop hops up and fades out.
        static IEnumerator PopUp(Sprite icon, Vector2 from)
        {
            var sr = new GameObject("Picked").AddComponent<SpriteRenderer>();
            sr.sprite = icon;
            sr.sortingOrder = 31500;
            for (float k = 0f; k < 1f; k += Time.deltaTime / 0.6f)
            {
                sr.transform.position = from + new Vector2(0f, 0.3f + Mathf.Sin(k * Mathf.PI * 0.5f) * 0.9f);
                sr.color = new Color(1f, 1f, 1f, k < 0.6f ? 1f : 1f - (k - 0.6f) / 0.4f);
                yield return null;
            }
            Destroy(sr.gameObject);
        }
    }
}
