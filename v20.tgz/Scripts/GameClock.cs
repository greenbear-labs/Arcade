using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// The time of day. A day runs 6 AM to 2 AM; at 2 AM (or when you press N to
    /// sleep) the screen fades out and a new morning starts. Crops grow, hens lay
    /// and pots come back overnight; every few days the season changes (see Seasons). Day length is FarmDemoConfig.DayLengthSeconds (doubled with "Relaxed days" in the settings).
    /// </summary>
    public class GameClock : MonoBehaviour
    {
        public const float StartHour = 6f, EndHour = 26f;   // 26 = 2 AM the next night

        public static int Day { get; private set; } = 1;
        /// <summary>Hours since midnight, 6 to 26.</summary>
        public static float Hour { get; private set; } = StartHour;
        /// <summary>Fires each morning, after the fade to black.</summary>
        public static event System.Action NewDay;

        /// <summary>0 in daylight, up to 1 in the dead of night.</summary>
        public static float Darkness
        {
            get
            {
                if (Hour < 17.5f) return 0f;
                return Mathf.Clamp01((Hour - 17.5f) / 4f);
            }
        }

        /// <summary>Black over the screen while a night is skipped: 0 none, 1 full.</summary>
        public static float Fade { get; private set; }

        public static string TimeText
        {
            get
            {
                int h = Mathf.FloorToInt(Hour) % 24;
                int m = Mathf.FloorToInt((Hour - Mathf.Floor(Hour)) * 6f) * 10;   // steps of 10 minutes
                return $"{(h % 12 == 0 ? 12 : h % 12)}:{m:00} {(h < 12 ? "AM" : "PM")}";
            }
        }

        static GameClock _instance;
        float _sleepClock = -1f;        // >= 0 while fading out / in
        bool _passedOut;
        bool _warned;

        /// <summary>Jump to the morning of a given day (loading a save).</summary>
        public static void SetDay(int day)
        {
            Day = Mathf.Max(1, day);
            Hour = StartHour;
        }

        public static void ResetClock()
        {
            Day = 1;
            Hour = StartHour;
            Fade = 0f;
        }

        /// <summary>Go to bed now and wake up tomorrow.</summary>
        public static void Sleep(bool passedOut = false)
        {
            if (_instance == null || _instance._sleepClock >= 0f) return;
            _instance._sleepClock = 0f;
            _instance._passedOut = passedOut;
        }

        public static bool Sleeping => _instance != null && _instance._sleepClock >= 0f;

        void Awake() => _instance = this;

        void Update()
        {
            if (_sleepClock >= 0f) { UpdateSleep(); return; }

            // The clock stops while you're reading something, like in Stardew.
            if (!Hud.Busy) Hour += Time.deltaTime * (EndHour - StartHour) / Settings.DayLength;

            if (!_warned && Hour >= 24f) { _warned = true; Hud.Toast("It's midnight. You're getting sleepy... (press N to sleep)"); }
            if (Hour >= EndHour) Sleep(passedOut: true);
            if (GameInput.SleepPressed() && !Hud.Busy) Sleep();
        }

        void UpdateSleep()
        {
            const float fadeOut = 1f, hold = 0.6f, fadeIn = 1f;
            float before = _sleepClock;
            _sleepClock += Time.deltaTime;

            if (before < fadeOut + hold && _sleepClock >= fadeOut + hold) StartNewDay();

            if (_sleepClock < fadeOut) Fade = _sleepClock / fadeOut;
            else if (_sleepClock < fadeOut + hold) Fade = 1f;
            else Fade = 1f - (_sleepClock - fadeOut - hold) / fadeIn;

            if (_sleepClock >= fadeOut + hold + fadeIn) { Fade = 0f; _sleepClock = -1f; }
        }

        void StartNewDay()
        {
            Day++;
            Hour = StartHour;
            _warned = false;
            PlayerStats.Health = PlayerStats.MaxHealth;
            NewDay?.Invoke();
            if (Seasons.FirstDay) Hud.Toast(Seasons.Arrival(Seasons.Current), 5f);
            else Hud.Toast(_passedOut
                ? $"{Seasons.DateText}. You passed out in a field. Your crops didn't mind."
                : $"{Seasons.DateText}. Good morning! Your farm is saved.", 4f);
        }

        void OnDestroy()
        {
            if (_instance == this) { _instance = null; NewDay = null; }
        }
    }
}
