using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// Follows the player smoothly and stays inside the map. The game is scaled
    /// up by a whole number so pixels stay square and crisp.
    /// </summary>
    [RequireComponent(typeof(Camera))]
    public class CameraFollow : MonoBehaviour
    {
        public Transform target;
        public Rect bounds;               // world-space area the camera may show
        [Tooltip("Higher = snappier. Around 6-10 feels good.")]
        public float followSharpness = 8f;

        Camera _camera;

        void Awake()
        {
            _camera = GetComponent<Camera>();
            _camera.orthographic = true;
        }

        bool _snap;

        /// <summary>Jump to the target next frame instead of gliding (after a teleport).</summary>
        public void Snap() => _snap = true;

        void LateUpdate()
        {
            int ppu = FarmDemoConfig.PixelsPerUnit;
            int zoom = Mathf.Max(1, Mathf.FloorToInt(Screen.height / (float)FarmDemoConfig.TargetVerticalPixels));
            _camera.orthographicSize = Screen.height / (2f * ppu * zoom);
            if (target == null) return;

            // Exponential smoothing: the same feel at any frame rate, no overshoot.
            // (The old version snapped the camera to whole pixels, which made it step
            // while the player moved smoothly. That was the choppiness.)
            Vector3 goal = target.position + new Vector3(0f, 0.75f, 0f);
            float t = _snap ? 1f : 1f - Mathf.Exp(-followSharpness * Time.deltaTime);
            _snap = false;
            Vector3 pos = Vector3.Lerp(transform.position, goal, t);

            float halfH = _camera.orthographicSize;
            float halfW = halfH * _camera.aspect;
            pos.x = ClampAxis(pos.x, bounds.xMin + halfW, bounds.xMax - halfW);
            pos.y = ClampAxis(pos.y, bounds.yMin + halfH, bounds.yMax - halfH);
            pos.z = -10f;
            transform.position = pos;
        }

        // If the map is smaller than the screen on an axis, centre it instead.
        static float ClampAxis(float v, float min, float max) =>
            min > max ? (min + max) * 0.5f : Mathf.Clamp(v, min, max);
    }
}
