using System.Collections;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// A bouncy slime. Wanders near home, chases the player when close, hurts on
    /// touch. Three hits and it pops, dropping a couple of coins.
    /// </summary>
    [RequireComponent(typeof(Rigidbody2D))]
    public class Slime : MonoBehaviour, IHittable
    {
        public int health = 3;
        public int contactDamage = 1;
        public float wanderSpeed = 0.8f;
        public float chaseSpeed = 1.7f;
        public float chaseRange = 4.5f;
        public float contactRange = 0.75f;
        public int coinsOnDeath = 2;
        public Color tint = Color.white;        // deeper mine slimes come in other colours

        Sprite[] _frames;
        SpriteRenderer _sprite;
        Rigidbody2D _body;
        Vector2 _home, _wanderTarget;
        float _wanderWait;
        float _stun;
        Vector2 _knock;
        float _flash;
        float _clock;
        bool _chasing, _dead;

        public void Init(Sprite[] frames)
        {
            _frames = frames;
        }

        void Awake()
        {
            _body = GetComponent<Rigidbody2D>();
            _sprite = GetComponentInChildren<SpriteRenderer>();
            _home = transform.position;
            _wanderTarget = _home;
            _clock = Random.value; // so slimes don't bounce in sync
        }

        void Update()
        {
            if (_dead) return;

            _clock += Time.deltaTime * (_chasing ? 1.8f : 1f);
            if (_frames != null) _sprite.sprite = _frames[Mathf.FloorToInt(_clock * 6f) % _frames.Length];

            _flash -= Time.deltaTime;
            _sprite.color = _flash > 0f ? new Color(1f, 0.45f, 0.45f) : tint;

            var player = PlayerController.Instance;
            if (player != null && _stun <= 0f &&
                Vector2.Distance(player.transform.position, transform.position) < contactRange)
                player.TakeDamage(contactDamage, (Vector2)transform.position + new Vector2(0f, 0.3f));
        }

        void FixedUpdate()
        {
            if (_dead) { _body.SetVelocity(Vector2.zero); return; }
            if (_stun > 0f)
            {
                _stun -= Time.fixedDeltaTime;
                _body.SetVelocity(_knock);
                _knock *= 0.85f;
                return;
            }

            var player = PlayerController.Instance;
            Vector2 pos = _body.position;
            _chasing = player != null && player.IsVulnerable &&
                       Vector2.Distance(player.transform.position, pos) < chaseRange &&
                       Vector2.Distance(pos, _home) < chaseRange * 2f; // don't follow you across the map

            if (_chasing)
            {
                _body.SetVelocity(((Vector2)player.transform.position - pos).normalized * chaseSpeed);
                return;
            }

            // Wander: walk to a random spot near home, wait a bit, repeat.
            if (Vector2.Distance(pos, _wanderTarget) < 0.15f)
            {
                _body.SetVelocity(Vector2.zero);
                _wanderWait -= Time.fixedDeltaTime;
                if (_wanderWait <= 0f)
                {
                    _wanderTarget = _home + Random.insideUnitCircle * 2.5f;
                    _wanderWait = Random.Range(0.8f, 2.2f);
                }
                return;
            }
            _body.SetVelocity((_wanderTarget - pos).normalized * wanderSpeed);
        }

        void OnCollisionStay2D(Collision2D _)
        {
            // Bumped into a tree or the pond: give up on this wander spot.
            if (!_chasing) _wanderTarget = _body.position;
        }

        public void Hit(Vector2 from, int damage)
        {
            if (_dead) return;
            health -= damage;
            _flash = 0.15f;
            _stun = 0.3f;
            _knock = ((Vector2)transform.position - from).normalized * 6f;
            if (health <= 0) StartCoroutine(Pop());
        }

        IEnumerator Pop()
        {
            _dead = true;
            foreach (var col in GetComponents<Collider2D>()) col.enabled = false;
            for (int i = 0; i < coinsOnDeath; i++) Coin.Spawn(transform.position + new Vector3(0f, 0.3f));

            Vector3 start = transform.localScale;
            for (float t = 0f; t < 1f; t += Time.deltaTime / 0.25f)
            {
                transform.localScale = new Vector3(start.x * (1f + t * 0.6f), start.y * (1f - t), 1f);
                yield return null;
            }
            Destroy(gameObject);
        }
    }
}
