using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// Loads images from Resources/FarmDemo/ and cuts them into sprites.
    /// Sprites are cached, so asking twice is free.
    /// </summary>
    public static class Art
    {
        static readonly Dictionary<string, Sprite[][]> Sheets = new Dictionary<string, Sprite[][]>();

        public static Texture2D Texture(string name)
        {
            var tex = Resources.Load<Texture2D>("FarmDemo/" + name);
            if (tex == null)
            {
                Debug.LogError($"[Farm Demo] Missing image Resources/FarmDemo/{name}.png. Is the FarmDemo folder inside Assets?");
                return null;
            }
            tex.filterMode = FilterMode.Point;
            tex.wrapMode = TextureWrapMode.Clamp;
            return tex;
        }

        /// <summary>
        /// Cuts a sheet into [row][column] frames of w x h pixels. Rows count from
        /// the top of the image. Pivot (0.5, 0) = bottom centre, i.e. the feet.
        /// </summary>
        public static Sprite[][] Sheet(string name, int w, int h, Vector2? pivot = null)
        {
            Vector2 p = pivot ?? new Vector2(0.5f, 0f);
            string key = $"{name}/{w}x{h}/{p}";
            // (Sprites made at runtime are destroyed when Play stops, so re-check before reusing.)
            if (Sheets.TryGetValue(key, out var cached) && cached[0][0] != null) return cached;

            var tex = Texture(name);
            if (tex == null) return null;
            if (tex.width % w != 0 || tex.height % h != 0)
            {
                // Unity rescales non-power-of-two images unless they import as Sprites. The
                // editor script in FarmDemo/Editor handles that; this catches it if it didn't run.
                Debug.LogError($"[Farm Demo] {name}.png is {tex.width}x{tex.height}, which doesn't divide into {w}x{h} frames. " +
                               "Run Tools > Farm Demo > Fix Art Import Settings, then press Play again.");
                return null;
            }

            int cols = tex.width / w, rows = tex.height / h;
            var sheet = new Sprite[rows][];
            for (int r = 0; r < rows; r++)
            {
                sheet[r] = new Sprite[cols];
                for (int c = 0; c < cols; c++)
                    sheet[r][c] = Sprite.Create(tex, new Rect(c * w, tex.height - (r + 1) * h, w, h), p,
                        FarmDemoConfig.PixelsPerUnit, 0, SpriteMeshType.FullRect);
            }
            Sheets[key] = sheet;
            return sheet;
        }

        /// <summary>
        /// Like Sheet, but every frame gets a 1-pixel border copied from its own edge.
        /// Use it for tiles: when the camera sits between whole pixels, the GPU can
        /// sample a hair past a tile's edge, and without the border that shows up as
        /// thin lines of the neighbouring tile across the map.
        /// </summary>
        /// <remarks>Pass a variant name and a recolor to get a repainted copy (the seasons use this).</remarks>
        public static Sprite[][] PaddedSheet(string name, int w, int h, Vector2? pivot = null,
            string variant = null, System.Func<Color32, Color32> recolor = null)
        {
            Vector2 p = pivot ?? new Vector2(0.5f, 0f);
            string key = $"{name}/{w}x{h}/{p}/padded/{variant}";
            if (Sheets.TryGetValue(key, out var cached) && cached[0][0] != null) return cached;

            var src = Texture(name);
            if (src == null || src.width % w != 0 || src.height % h != 0 || !src.isReadable) return Sheet(name, w, h, pivot);

            // Copy every frame into a bigger texture with a 1-pixel gap around it, and fill the gap
            // by repeating the frame's own edge pixels. (Done on the CPU so it works on every platform.)
            int cols = src.width / w, rows = src.height / h, pw = w + 2, ph = h + 2;
            Color32[] from = src.GetPixels32();
            if (recolor != null) for (int i = 0; i < from.Length; i++) if (from[i].a > 0) from[i] = recolor(from[i]);
            int dw = cols * pw, dh = rows * ph;
            var to = new Color32[dw * dh];
            for (int y = 0; y < dh; y++)
            for (int x = 0; x < dw; x++)
            {
                int c = x / pw, r = y / ph;                                  // r counts from the bottom here
                int fx = Mathf.Clamp(x % pw - 1, 0, w - 1), fy = Mathf.Clamp(y % ph - 1, 0, h - 1);
                to[y * dw + x] = from[(r * h + fy) * src.width + c * w + fx];
            }
            var dst = new Texture2D(dw, dh, TextureFormat.RGBA32, false)
            {
                name = name + " (padded)", filterMode = FilterMode.Point, wrapMode = TextureWrapMode.Clamp,
            };
            dst.SetPixels32(to);
            dst.Apply(false, true);

            var sheet = new Sprite[rows][];
            for (int r = 0; r < rows; r++)
            {
                sheet[r] = new Sprite[cols];
                int dy = (rows - 1 - r) * ph + 1;   // rows count from the top
                for (int c = 0; c < cols; c++)
                    sheet[r][c] = Sprite.Create(dst, new Rect(c * pw + 1, dy, w, h), p, FarmDemoConfig.PixelsPerUnit, 0, SpriteMeshType.FullRect);
            }
            Sheets[key] = sheet;
            return sheet;
        }

        static readonly Dictionary<string, Sprite> Recolored = new Dictionary<string, Sprite>();

        /// <summary>
        /// A whole image as one sprite, every pixel passed through recolor. Needs the image
        /// imported readable (see FarmDemoArtImporter); otherwise you get it as drawn.
        /// </summary>
        public static Sprite RecoloredSingle(string name, string variant, System.Func<Color32, Color32> recolor, Vector2? pivot = null)
        {
            Vector2 p = pivot ?? new Vector2(0.5f, 0f);
            string key = $"{name}/{variant}/{p}";
            if (Recolored.TryGetValue(key, out var cached) && cached != null) return cached;
            var src = Texture(name);
            if (src == null || !src.isReadable) return Single(name, pivot);

            Color32[] px = src.GetPixels32();
            for (int i = 0; i < px.Length; i++) if (px[i].a > 0) px[i] = recolor(px[i]);
            var dst = new Texture2D(src.width, src.height, TextureFormat.RGBA32, false)
            {
                name = $"{name} ({variant})", filterMode = FilterMode.Point, wrapMode = TextureWrapMode.Clamp,
            };
            dst.SetPixels32(px);
            dst.Apply(false, true);
            var sprite = Sprite.Create(dst, new Rect(0, 0, src.width, src.height), p, FarmDemoConfig.PixelsPerUnit, 0, SpriteMeshType.FullRect);
            Recolored[key] = sprite;
            return sprite;
        }

        /// <summary>A whole image as one sprite.</summary>
        public static Sprite Single(string name, Vector2? pivot = null)
        {
            var tex = Texture(name);
            return tex == null ? null : Sheet(name, tex.width, tex.height, pivot)?[0][0];
        }

        /// <summary>A one-row strip of frames (coins, slimes).</summary>
        public static Sprite[] Strip(string name, int w, int h, Vector2? pivot = null) => Sheet(name, w, h, pivot)?[0];

        /// <summary>A 4-direction sheet reordered to [Facing][frame].</summary>
        public static Sprite[][] Directional(string name, int w, int h)
        {
            var sheet = Sheet(name, w, h);
            if (sheet == null) return null;
            var byFacing = new Sprite[4][];
            byFacing[(int)Facing.Down] = sheet[FarmDemoConfig.RowDown];
            byFacing[(int)Facing.Up] = sheet[FarmDemoConfig.RowUp];
            byFacing[(int)Facing.Left] = sheet[FarmDemoConfig.RowLeft];
            byFacing[(int)Facing.Right] = sheet[FarmDemoConfig.RowRight];
            return byFacing;
        }

        /// <summary>Unit vector for a facing.</summary>
        public static Vector2 Dir(Facing f) =>
            f == Facing.Up ? Vector2.up : f == Facing.Down ? Vector2.down : f == Facing.Left ? Vector2.left : Vector2.right;

        public static Facing FacingToward(Vector2 v) =>
            Mathf.Abs(v.x) > Mathf.Abs(v.y) ? (v.x < 0 ? Facing.Left : Facing.Right) : (v.y < 0 ? Facing.Down : Facing.Up);
    }
}
