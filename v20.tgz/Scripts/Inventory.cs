using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>One kind of item. Icon is its index in Resources/FarmDemo/items.png (16x16 each).</summary>
    public class ItemDef
    {
        public readonly string Name;
        public readonly int IconIndex;
        public readonly bool Stackable;
        /// <summary>What Mabel pays for one. 0 means she won't buy it.</summary>
        public readonly int SellPrice;

        public ItemDef(string name, int iconIndex, int sellPrice = 0, bool stackable = true)
        {
            Name = name;
            IconIndex = iconIndex;
            SellPrice = sellPrice;
            Stackable = stackable;
        }

        public Sprite Icon => Art.Strip("items", 16, 16, new Vector2(0.5f, 0.5f))?[IconIndex];
    }

    /// <summary>Every item in the demo. Add new ones here (and draw an icon in items.png).</summary>
    public static class Items
    {
        public static readonly ItemDef FishingRod = new ItemDef("Fishing Rod", 0, stackable: false);
        public static readonly ItemDef Bluegill = new ItemDef("Bluegill", 1, 30);
        public static readonly ItemDef Carp = new ItemDef("Carp", 2, 45);
        public static readonly ItemDef GoldenTrout = new ItemDef("Golden Trout", 3, 150);
        public static readonly ItemDef OldBoot = new ItemDef("Old Boot", 4, 1);
        public static readonly ItemDef TurnipSeeds = new ItemDef("Turnip Seeds", 5, 10);
        public static readonly ItemDef StrawberrySeeds = new ItemDef("Strawberry Seeds", 6, 25);
        public static readonly ItemDef Turnip = new ItemDef("Turnip", 7, 60);
        public static readonly ItemDef Strawberry = new ItemDef("Strawberry", 8, 80);
        public static readonly ItemDef Hoe = new ItemDef("Hoe", 9, stackable: false);
        public static readonly ItemDef WateringCan = new ItemDef("Watering Can", 10, stackable: false);
        public static readonly ItemDef Egg = new ItemDef("Egg", 11, 50);
        public static readonly ItemDef LargeEgg = new ItemDef("Large Egg", 12, 95);
        public static readonly ItemDef ChickenFeed = new ItemDef("Chicken Feed", 13);
        public static readonly ItemDef Chicken = new ItemDef("Chicken", 14, stackable: false);   // only sold, never carried
        public static readonly ItemDef TomatoSeeds = new ItemDef("Tomato Seeds", 15, 15);
        public static readonly ItemDef Tomato = new ItemDef("Tomato", 16, 55);
        public static readonly ItemDef PumpkinSeeds = new ItemDef("Pumpkin Seeds", 17, 40);
        public static readonly ItemDef Pumpkin = new ItemDef("Pumpkin", 18, 220);
        public static readonly ItemDef Pickaxe = new ItemDef("Pickaxe", 19, stackable: false);
        public static readonly ItemDef CopperOre = new ItemDef("Copper Ore", 20, 20);
        public static readonly ItemDef IronOre = new ItemDef("Iron Ore", 21, 45);
        public static readonly ItemDef Gem = new ItemDef("Gem", 22, 150);
        public static readonly ItemDef Sprinkler = new ItemDef("Sprinkler", 23);
        public static readonly ItemDef GemSword = new ItemDef("Gem Sword", 24, stackable: false);   // only an icon for the upgrade

        public static readonly ItemDef FriedEgg = new ItemDef("Fried Egg", 25, 80);
        public static readonly ItemDef TurnipSoup = new ItemDef("Turnip Soup", 26, 160);
        public static readonly ItemDef StrawberryJam = new ItemDef("Strawberry Jam", 27, 300);
        public static readonly ItemDef FishStew = new ItemDef("Fish Stew", 28, 180);
        public static readonly ItemDef PumpkinPie = new ItemDef("Pumpkin Pie", 29, 420);
        public static readonly ItemDef Milk = new ItemDef("Milk", 30, 90);
        public static readonly ItemDef GoatMilk = new ItemDef("Goat Milk", 31, 150);
        public static readonly ItemDef Cheese = new ItemDef("Cheese", 32, 180);
        public static readonly ItemDef GoatCheese = new ItemDef("Goat Cheese", 33, 280);
        public static readonly ItemDef Hay = new ItemDef("Hay", 34);
        public static readonly ItemDef Cow = new ItemDef("Cow", 35, stackable: false);     // only sold, never carried
        public static readonly ItemDef Goat = new ItemDef("Goat", 36, stackable: false);   // only sold, never carried
        public static readonly ItemDef CarrotSeeds = new ItemDef("Carrot Seeds", 37, 7);
        public static readonly ItemDef Carrot = new ItemDef("Carrot", 38, 40);
        public static readonly ItemDef CornSeeds = new ItemDef("Corn Seeds", 39, 20);
        public static readonly ItemDef Corn = new ItemDef("Corn", 40, 50);
        public static readonly ItemDef MelonSeeds = new ItemDef("Melon Seeds", 41, 45);
        public static readonly ItemDef Melon = new ItemDef("Melon", 42, 260);
        public static readonly ItemDef EggplantSeeds = new ItemDef("Eggplant Seeds", 43, 15);
        public static readonly ItemDef Eggplant = new ItemDef("Eggplant", 44, 45);
        public static readonly ItemDef Truffle = new ItemDef("Truffle", 45, 300);
        public static readonly ItemDef Pig = new ItemDef("Pig", 46, stackable: false);     // only sold, never carried
        public static readonly ItemDef BeeHouse = new ItemDef("Bee House", 47);
        public static readonly ItemDef Honey = new ItemDef("Honey", 48, 150);
        public static readonly ItemDef HoneyCake = new ItemDef("Honey Cake", 49, 340);
        public static readonly ItemDef Axe = new ItemDef("Axe", 50, stackable: false);
        public static readonly ItemDef Shovel = new ItemDef("Shovel", 51, stackable: false);
        public static readonly ItemDef Wood = new ItemDef("Wood", 52, 4);
        public static readonly ItemDef Sword = new ItemDef("Sword", 53, stackable: false);
        public static readonly ItemDef Chest = new ItemDef("Chest", 54);
        public static readonly ItemDef Shears = new ItemDef("Shears", 55, stackable: false);
        public static readonly ItemDef WildBerries = new ItemDef("Wild Berries", 56, 12);
        public static readonly ItemDef TulipBulbs = new ItemDef("Tulip Bulbs", 57, 10);
        public static readonly ItemDef Tulip = new ItemDef("Tulip", 58, 45);
        public static readonly ItemDef SunflowerSeeds = new ItemDef("Sunflower Seeds", 59, 20);
        public static readonly ItemDef Sunflower = new ItemDef("Sunflower", 60, 90);
        public static readonly ItemDef LavenderSeeds = new ItemDef("Lavender Seeds", 61, 15);
        public static readonly ItemDef Lavender = new ItemDef("Lavender", 62, 55);

        public static readonly ItemDef[] All =
        {
            FishingRod, Bluegill, Carp, GoldenTrout, OldBoot, TurnipSeeds, StrawberrySeeds, Turnip, Strawberry, Hoe, WateringCan,
            Egg, LargeEgg, ChickenFeed, Chicken, TomatoSeeds, Tomato, PumpkinSeeds, Pumpkin, Pickaxe, CopperOre, IronOre, Gem, Sprinkler, GemSword,
            FriedEgg, TurnipSoup, StrawberryJam, FishStew, PumpkinPie, Milk, GoatMilk, Cheese, GoatCheese, Hay, Cow, Goat,
            CarrotSeeds, Carrot, CornSeeds, Corn, MelonSeeds, Melon, EggplantSeeds, Eggplant, Truffle, Pig,
            BeeHouse, Honey, HoneyCake, Axe, Shovel, Wood, Sword, Chest, Shears, WildBerries,
            TulipBulbs, Tulip, SunflowerSeeds, Sunflower, LavenderSeeds, Lavender,
        };

        /// <summary>The item with this name, or null (used when loading a save).</summary>
        public static ItemDef ByName(string name)
        {
            foreach (var item in All) if (item.Name == name) return item;
            return null;
        }
    }

    /// <summary>
    /// Key tools live on the toolbelt, not in the bag: an upright dial in the top left you
    /// slide up and down (or turn with the mouse wheel, Q / R, or a tap) to pick one. Whichever you
    /// touched last, the toolbelt or the item bar, is what you're holding.
    /// </summary>
    public static class Toolbelt
    {
        /// <summary>Every key tool, in the order they sit around the dial.</summary>
        public static readonly ItemDef[] Order =
            { Items.Sword, Items.Hoe, Items.WateringCan, Items.Shovel, Items.Axe, Items.Shears, Items.Pickaxe, Items.FishingRod };

        static readonly HashSet<ItemDef> Owned = new HashSet<ItemDef>();
        static int _index;

        /// <summary>True when the tool on the dial is in your hands (false: the picked item-bar slot is).</summary>
        public static bool Active { get; private set; }
        public static float TurnedTime = -10f;
        /// <summary>The direction of the last turn, for the dial's spin.</summary>
        public static int LastStep;

        public static bool IsTool(ItemDef item) => System.Array.IndexOf(Order, item) >= 0;
        public static bool Has(ItemDef tool) => Owned.Contains(tool);

        /// <summary>The tools you own, in dial order.</summary>
        public static List<ItemDef> Tools
        {
            get
            {
                var list = new List<ItemDef>();
                foreach (var t in Order) if (Owned.Contains(t)) list.Add(t);
                return list;
            }
        }

        public static int Index => _index;

        public static ItemDef Current
        {
            get
            {
                var tools = Tools;
                return tools.Count == 0 ? null : tools[((_index % tools.Count) + tools.Count) % tools.Count];
            }
        }

        /// <summary>The picture for a tool: the sword shows its gem once it's upgraded.</summary>
        public static Sprite Icon(ItemDef tool) => tool == Items.Sword && Upgrades.Sword >= 1 ? Items.GemSword.Icon : tool.Icon;

        public static void Reset()
        {
            Owned.Clear();
            _index = 0;
            Active = false;
        }

        public static void Give(ItemDef tool)
        {
            if (!IsTool(tool) || Owned.Contains(tool)) return;
            var current = Current;      // keep holding the same tool as the dial grows
            Owned.Add(tool);
            if (current != null) _index = Tools.IndexOf(current);
        }

        /// <summary>Turn the dial one step and take that tool in hand.</summary>
        public static void Turn(int step)
        {
            var tools = Tools;
            if (tools.Count == 0) return;
            if (Active) _index = ((_index + step) % tools.Count + tools.Count) % tools.Count;
            else _index = ((_index % tools.Count) + tools.Count) % tools.Count;   // the first turn just takes up the dial
            Active = true;
            LastStep = step;
            TurnedTime = Time.time;
        }

        /// <summary>Take this tool in hand.</summary>
        public static void Pick(ItemDef tool)
        {
            int i = Tools.IndexOf(tool);
            if (i < 0) return;
            _index = i;
            Active = true;
            LastStep = 0;
            TurnedTime = Time.time;
        }

        /// <summary>Put the tool down and hold the picked item-bar slot instead.</summary>
        public static void Release() => Active = false;

        /// <summary>For the save: restore which tool was picked.</summary>
        public static void Restore(int index, bool active)
        {
            _index = Mathf.Max(0, index);
            Active = active && Owned.Count > 0;
        }
    }

    /// <summary>
    /// The player's bag: 16 fixed slots, the first 8 of which are the item bar.
    /// Items of the same kind stack. Slots don't shuffle when one empties, so the item bar stays put.
    /// Key tools go on the toolbelt instead.
    /// </summary>
    public static class Inventory
    {
        public const int SlotCount = 16, HotbarCount = 8;

        public class Stack
        {
            public ItemDef Item;
            public int Count;
        }

        static readonly Stack[] Slots = new Stack[SlotCount];

        /// <summary>All slots in order. Empty slots are null.</summary>
        public static IReadOnlyList<Stack> All => Slots;

        /// <summary>The item-bar slot the player has picked (1-8 keys or a tap).</summary>
        public static int Selected;
        public static float SelectedTime = -10f;
        /// <summary>What's in your hands: the toolbelt's tool if you turned to it last, else the picked slot's item.</summary>
        public static ItemDef SelectedItem => Toolbelt.Active ? Toolbelt.Current : Slots[Selected]?.Item;

        /// <summary>Slot that changed last and when, so the HUD can make it flash.</summary>
        public static int LastChangedSlot = -1;
        public static float LastChangedTime = -10f;

        /// <summary>How full the watering can is. Each watered tile uses one; fill it at the pond.</summary>
        public static int WaterMax => Upgrades.Can >= 1 ? 60 : 30;
        public static int Water = WaterMax;

        public static void Reset()
        {
            for (int i = 0; i < SlotCount; i++) Slots[i] = null;
            LastChangedSlot = -1;
            Selected = 0;
            Water = WaterMax;
        }

        /// <summary>Put exactly this in a slot (loading a save). A null item or a count below 1 empties it.</summary>
        public static void SetSlot(int slot, ItemDef item, int count)
        {
            if (item != null && Toolbelt.IsTool(item)) { Toolbelt.Give(item); item = null; }   // saves from before the toolbelt
            Slots[slot] = item == null || count < 1 ? null : new Stack { Item = item, Count = count };
        }

        public static void Select(int slot)
        {
            Selected = ((slot % HotbarCount) + HotbarCount) % HotbarCount;
            SelectedTime = Time.time;
            Toolbelt.Release();
        }

        /// <summary>Swap two slots (moving things around in the bag).</summary>
        public static void Swap(int a, int b)
        {
            if (a == b || a < 0 || b < 0 || a >= SlotCount || b >= SlotCount) return;
            if (Slots[a] != null && Slots[b] != null && Slots[a].Item == Slots[b].Item && Slots[a].Item.Stackable)
            {
                Slots[b].Count += Slots[a].Count;   // same thing: stack them together
                Slots[a] = null;
            }
            else (Slots[a], Slots[b]) = (Slots[b], Slots[a]);
            Changed(b);
        }

        /// <summary>Take a whole stack out of a slot (moving it to a chest).</summary>
        public static Stack Take(int slot)
        {
            var s = Slots[slot];
            Slots[slot] = null;
            if (s != null) Changed(slot);
            return s;
        }

        /// <summary>Which slot holds this item, or -1.</summary>
        public static int SlotOf(ItemDef item)
        {
            for (int i = 0; i < SlotCount; i++) if (Slots[i] != null && Slots[i].Item == item) return i;
            return -1;
        }

        public static bool IsEmpty => System.Array.TrueForAll(Slots, s => s == null);

        public static bool Has(ItemDef item) => Count(item) > 0;

        public static int Count(ItemDef item)
        {
            if (Toolbelt.IsTool(item)) return Toolbelt.Has(item) ? 1 : 0;
            int n = 0;
            foreach (var s in Slots) if (s != null && s.Item == item) n += s.Count;
            return n;
        }

        /// <summary>Would Add succeed right now?</summary>
        public static bool HasRoomFor(ItemDef item)
        {
            if (Toolbelt.IsTool(item)) return true;
            for (int i = 0; i < SlotCount; i++)
                if (Slots[i] == null || (item.Stackable && Slots[i].Item == item)) return true;
            return false;
        }

        /// <summary>Adds the item. Returns false (and adds nothing) if the bag is full.</summary>
        public static bool Add(ItemDef item, int count = 1)
        {
            if (Toolbelt.IsTool(item)) { Toolbelt.Give(item); return true; }
            if (item.Stackable)
            {
                for (int i = 0; i < SlotCount; i++)
                {
                    if (Slots[i] == null || Slots[i].Item != item) continue;
                    Slots[i].Count += count;
                    Changed(i);
                    return true;
                }
            }
            for (int i = 0; i < SlotCount; i++)
            {
                if (Slots[i] != null) continue;
                Slots[i] = new Stack { Item = item, Count = count };
                Changed(i);
                return true;
            }
            return false;
        }

        /// <summary>Takes up to count of the item out of the bag. Returns how many were taken.</summary>
        public static int Remove(ItemDef item, int count = 1)
        {
            int taken = 0;
            for (int i = 0; i < SlotCount && taken < count; i++)
            {
                if (Slots[i] == null || Slots[i].Item != item) continue;
                int n = Mathf.Min(count - taken, Slots[i].Count);
                Slots[i].Count -= n;
                taken += n;
                if (Slots[i].Count <= 0) Slots[i] = null;
                Changed(i);
            }
            return taken;
        }

        static void Changed(int slot)
        {
            LastChangedSlot = slot;
            LastChangedTime = Time.time;
        }
    }
}
