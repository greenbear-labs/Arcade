using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>A kind of fruit tree: its sapling, its fruit, and the season it fruits in.</summary>
    public class FruitKind
    {
        public readonly string Name;
        public readonly ItemDef Sapling, Fruit;
        public readonly Season Season;
        public readonly int Row, Price;

        FruitKind(string name, ItemDef sapling, ItemDef fruit, Season season, int row, int price)
        {
            Name = name; Sapling = sapling; Fruit = fruit; Season = season; Row = row; Price = price;
        }

        public static readonly FruitKind Cherry = new FruitKind("Cherry", Items.CherrySapling, Items.Cherries, Season.Spring, 0, 300);
        public static readonly FruitKind Peach = new FruitKind("Peach", Items.PeachSapling, Items.Peach, Season.Summer, 1, 350);
        public static readonly FruitKind Orange = new FruitKind("Orange", Items.OrangeSapling, Items.Orange, Season.Summer, 2, 350);
        public static readonly FruitKind Apple = new FruitKind("Apple", Items.AppleSapling, Items.Apple, Season.Fall, 3, 300);
        public static readonly FruitKind[] All = { Cherry, Peach, Orange, Apple };

        public static FruitKind ForSapling(ItemDef item) => System.Array.Find(All, k => k.Sapling == item);
        public static FruitKind ForFruit(ItemDef item) => System.Array.Find(All, k => k.Fruit == item);
    }

    /// <summary>
    /// Fruit trees. Buy a sapling from Hazel, pick it on the item bar and press F on
    /// open grass (with a tile of room all round) to plant it. It grows every
    /// morning outside winter: a young tree after a few days, fully grown after a
    /// week. Then in its season it fruits every other morning: face it and press F
    /// to pick. Saplings can be dug back up with the shovel. Kept in the save.
    /// </summary>
    public class FruitTrees : MonoBehaviour
    {
        const int YoungAt = 3, GrownAt = 7, FruitEvery = 2, FruitPerPick = 3, MaxTrees = 20;

        class Tree
        {
            public Vector2Int Cell;
            public FruitKind Kind;
            public int Age, Days;
            public bool Ready;
            public GameObject Go;
            public SpriteRenderer Sr;
            public BoxCollider2D Box;
            public int Stage => Age >= GrownAt ? 2 : Age >= YoungAt ? 1 : 0;
        }

        static FruitTrees _instance;
        readonly Dictionary<Vector2Int, Tree> _trees = new Dictionary<Vector2Int, Tree>();
        Sprite[][] _frames;

        /// <summary>Is there a fruit tree on this tile? (F there means pick or plant, not eat.)</summary>
        public static bool At(Vector2Int cell) => _instance != null && _instance._trees.ContainsKey(cell);

        public static void Export(List<SaveGame.FruitTreeState> list)
        {
            if (_instance == null) return;
            foreach (var t in _instance._trees.Values)
                list.Add(new SaveGame.FruitTreeState { x = t.Cell.x, y = t.Cell.y, kind = t.Kind.Name, age = t.Age, days = t.Days, ready = t.Ready });
        }

        public static void Import(List<SaveGame.FruitTreeState> list)
        {
            if (_instance == null) return;
            foreach (var s in list)
            {
                var kind = System.Array.Find(FruitKind.All, k => k.Name == s.kind);
                if (kind == null) continue;
                var t = _instance.Plant(new Vector2Int(s.x, s.y), kind);
                if (t == null) continue;
                t.Age = s.age;
                t.Days = s.days;
                t.Ready = s.ready;
                _instance.Refresh(t);
            }
        }

        public void Build()
        {
            _instance = this;
            _frames = Art.Sheet("fruittree", 32, 32);
            GameClock.NewDay += Morning;
        }

        void OnDestroy()
        {
            GameClock.NewDay -= Morning;
            if (_instance == this) _instance = null;
        }

        Tree Plant(Vector2Int cell, FruitKind kind)
        {
            if (_trees.ContainsKey(cell)) return null;
            var go = new GameObject(kind.Name + " tree");
            go.transform.SetParent(transform, false);
            go.transform.position = new Vector3(cell.x + 0.5f, cell.y + 0.1f, 0f);
            var sr = go.AddComponent<SpriteRenderer>();
            go.AddComponent<YSort>();
            var box = go.AddComponent<BoxCollider2D>();
            var t = new Tree { Cell = cell, Kind = kind, Go = go, Sr = sr, Box = box };
            _trees[cell] = t;
            Refresh(t);
            return t;
        }

        void Refresh(Tree t)
        {
            if (_frames != null) t.Sr.sprite = _frames[t.Kind.Row][t.Ready && t.Stage == 2 ? 3 : t.Stage];
            // A sapling is a twig you could step round; a grown tree is as solid (and as tall) as any other.
            t.Box.size = t.Stage == 0 ? new Vector2(0.3f, 0.25f) : new Vector2(0.5f, 0.3f);
            t.Box.offset = new Vector2(0f, t.Box.size.y * 0.5f);
            if (t.Stage == 2) FarmDemoWorld.Tall(t.Go);
        }

        static bool InSeason(FruitKind kind) => Seasons.Current == kind.Season;

        void Morning()
        {
            bool winter = Seasons.Current == Season.Winter;
            foreach (var t in _trees.Values)
            {
                if (!winter && t.Age < GrownAt) t.Age++;
                if (t.Stage == 2 && InSeason(t.Kind))
                {
                    if (!t.Ready && ++t.Days >= FruitEvery) { t.Ready = true; t.Days = 0; }
                }
                else { t.Ready = false; t.Days = 0; }     // out of season, the fruit drops
                Refresh(t);
            }
        }

        // Open grass on the farm, and no other fruit tree right next to it.
        bool CanPlant(Vector2Int cell)
        {
            if (!FarmDemoWorld.CanTill(cell)) return false;
            for (int dx = -1; dx <= 1; dx++)
            for (int dy = -1; dy <= 1; dy++)
                if (_trees.ContainsKey(cell + new Vector2Int(dx, dy))) return false;
            return true;
        }

        void Update()
        {
            var player = PlayerController.Instance;
            if (player == null || Hud.Busy || player.Locked || player.IsAttacking || Home.Inside || Mine.Inside || Cavern.Inside || Town.Inside) return;
            Vector2 feet = (Vector2)player.transform.position + new Vector2(0f, 0.15f);
            Vector2 ahead = feet + Art.Dir(player.Facing) * 0.75f;
            var cell = new Vector2Int(Mathf.FloorToInt(ahead.x), Mathf.FloorToInt(ahead.y));
            var held = Inventory.SelectedItem;

            if (_trees.TryGetValue(cell, out var tree))
            {
                string name = tree.Kind.Name.ToLower();
                if (held == Items.Shovel && tree.Stage == 0)
                {
                    Hud.SetPrompt($"F  Dig up the {name} sapling");
                    if (!GameInput.FishPressed()) return;
                    if (!Inventory.Add(tree.Kind.Sapling)) { Hud.Toast("Your bag is full!", 2f); return; }
                    Destroy(tree.Go);
                    _trees.Remove(cell);
                    return;
                }
                if (tree.Ready)
                {
                    Hud.SetPrompt($"F  Pick the {QuestBoard.Plural(tree.Kind.Fruit, FruitPerPick).ToLower()}");
                    if (!GameInput.FishPressed()) return;
                    if (!Inventory.Add(tree.Kind.Fruit, FruitPerPick)) { Hud.Toast("Your bag is full!", 2f); return; }
                    tree.Ready = false;
                    tree.Days = 0;
                    Refresh(tree);
                    Hud.Toast($"+{FruitPerPick} {tree.Kind.Fruit.Name}!", 1.5f);
                    return;
                }
                int left = GrownAt - tree.Age;
                if (tree.Stage < 2)
                    Hud.SetPrompt(Seasons.Current == Season.Winter ? $"A young {name} tree, resting till spring"
                        : $"A young {name} tree. Fully grown in {left} day{(left == 1 ? "" : "s")}");
                else
                    Hud.SetPrompt(InSeason(tree.Kind) ? $"The {name} tree will have fruit tomorrow"
                        : $"{tree.Kind.Name} trees fruit in {tree.Kind.Season.ToString().ToLower()}");
                return;
            }

            var kind = FruitKind.ForSapling(held);
            if (kind == null || !CanPlant(cell)) return;
            if (_trees.Count >= MaxTrees) { Hud.SetPrompt($"{MaxTrees} fruit trees is a whole orchard!"); return; }
            Hud.SetPrompt($"F  Plant the {kind.Name.ToLower()} sapling");
            if (GameInput.FishPressed() && Inventory.Remove(kind.Sapling) > 0)
            {
                Plant(cell, kind);
                Hud.Toast($"You planted a {kind.Name.ToLower()} tree. It'll be grown in a week.", 2.5f);
            }
        }
    }
}
