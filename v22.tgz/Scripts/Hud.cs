using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// Everything drawn on top of the game: hearts and gold at the top, the item
    /// bar and dialogue box at the bottom, item popups, the bag, Mabel's shop, the
    /// date and clock, night-time darkness, the season's weather, and short messages.
    /// Uses Unity's built-in immediate-mode GUI, so it needs no Canvas or packages.
    /// </summary>
    public class Hud : MonoBehaviour
    {
        static Hud _instance;

        // dialogue
        object _speaker;
        string _speakerName;
        string[] _lines;
        int _lineIndex;
        System.Action _onDialogueDone;

        // item popup ("You got a Fishing Rod!")
        Sprite _popupIcon;
        string _popupTitle, _popupBody;
        float _popupOpened = -1f;

        // context prompt ("F  Cast your line") and the bag
        string _prompt;
        int _promptFrame = -10;
        bool _bagOpen;
        int _bagPick = -1;          // bag slot picked up to move, or -1
        bool _creatureTab;          // the bag shows your creature friends instead of your things
        ChestBox _chest;            // the chest whose window is open, or null
        float _dialPos;             // the toolbelt dial's drawn position (in tools), easing toward the picked one
        float _dialDrag;            // finger travel on the dial not yet turned into a step
        bool _settingsOpen;
        float _resetAsked = -10f;   // when "Reset progress" was pressed once; a second press within 3 s confirms
        bool _shopOpen;
        bool _crafting;     // the shop window is showing recipes (workbench, stove, forge) instead of a shop's goods
        string _benchTitle = "Workbench";
        Recipe[] _benchRecipes;
        float _shopOpened;
        int _closedFrame = -10;     // a window closed this frame: swallow the key that closed it
        float _transition = -1f;    // >= 0 while fading through a door
        System.Action _transitionMiddle;
        float _lineStarted;
        const float CharsPerSecond = 45f;

        // toast + gold flash
        string _toast;
        float _toastUntil;
        int _shownGold;
        float _goldFlash;

        Sprite _heartFull, _heartEmpty, _coin;
        Texture2D _white;
        GUIStyle _text;

        public static bool DialogueOpen => _instance != null && _instance._lines != null;
        public static bool PopupOpen => _instance != null && _instance._popupTitle != null;
        /// <summary>True while any window is up; the player can't move or act.</summary>
        public static bool ShopOpen => _instance != null && _instance._shopOpen;
        /// <summary>A window you click or tap in (shop or bag) is open.</summary>
        public static bool MenuOpen => _instance != null && (_instance._shopOpen || _instance._bagOpen || _instance._settingsOpen || _instance._chest != null);
        /// <summary>Any window at all is open, including dialogue and popups.</summary>
        public static bool WindowOpen => DialogueOpen || PopupOpen || MenuOpen;

        /// <summary>Is this point (GUI coordinates) on the item bar?</summary>
        public static bool OverItemBar(Vector2 gui)
        {
            var bar = HotbarRect(Mathf.Max(2, Mathf.RoundToInt(Screen.height / 270f)));
            return new Rect(bar.x - 6, bar.y - 6, bar.width + 12, bar.height + 12).Contains(gui);
        }

        /// <summary>Is this point (GUI coordinates) on the toolbelt dial?</summary>
        public static bool OverToolbelt(Vector2 gui)
        {
            int s = Mathf.Max(2, Mathf.RoundToInt(Screen.height / 270f));
            var r = DialRect(s);
            return new Rect(r.x - 4 * s, r.y - 4 * s, r.width + 8 * s, r.height + 8 * s).Contains(gui);
        }

        // The dial stands upright in the top left third, far enough in that a phone's camera cut-out doesn't hide it.
        static Rect DialRect(int s)
        {
            float w = 24 * s, h = 74 * s, cx = Mathf.Max(Screen.width * 0.12f, 34 * s);
            return new Rect(cx - w / 2f, 36 * s, w, h);
        }
        /// <summary>Finger travel (GUI pixels) for one tool on the dial.</summary>
        public static float DialStep(int s) => 22 * s;

        public static void OpenChest(ChestBox chest)
        {
            if (_instance == null) return;
            _instance._chest = chest;
            _instance._shopOpened = Time.time;
        }

        static void CloseChest()
        {
            if (_instance == null || _instance._chest == null) return;
            _instance._chest = null;
            _instance._closedFrame = Time.frameCount;
        }

        static Rect HotbarRect(int s)
        {
            float slot = 20 * s, gap = 2 * s;
            float w = Inventory.HotbarCount * slot + (Inventory.HotbarCount - 1) * gap;
            return new Rect((Screen.width - w) / 2f, Screen.height - slot - 6 * s, w, slot);
        }

        public static bool InTransition => _instance != null && _instance._transition >= 0f;
        public static bool Busy => DialogueOpen || PopupOpen || ShopOpen || GameClock.Sleeping || InTransition ||
            (_instance != null && (_instance._bagOpen || _instance._settingsOpen || _instance._chest != null || _instance._closedFrame == Time.frameCount));

        ShopDef _shopDef;

        /// <summary>Quick fade to black, run middle (e.g. move the player), fade back in.</summary>
        public static void Transition(System.Action middle)
        {
            if (_instance == null) { middle?.Invoke(); return; }
            if (_instance._transition >= 0f) return;
            _instance._transition = 0f;
            _instance._transitionMiddle = middle;
        }

        const float TransitionHalf = 0.25f;

        float TransitionAlpha => _transition < 0f ? 0f
            : _transition < TransitionHalf ? _transition / TransitionHalf
            : 1f - (_transition - TransitionHalf) / TransitionHalf;

        /// <summary>A shop window: what this shopkeeper sells, and what they'll buy from you.</summary>
        public static void OpenShop(ShopDef shop)
        {
            if (_instance == null || shop == null) return;
            _instance._shopDef = shop;
            _instance._shopOpen = true;
            _instance._crafting = false;
            _instance._shopOpened = Time.time;
        }

        /// <summary>The workbench: make sprinklers and upgrade your tools.</summary>
        public static void OpenCrafting() => OpenBench("Workbench", Crafting.All);

        /// <summary>The stove in the farmhouse: cook meals.</summary>
        public static void OpenCooking() => OpenBench("Kitchen", Cooking.All);

        /// <summary>A window of recipes to make: the workbench, the stove or the cheese press.</summary>
        public static void OpenBench(string title, Recipe[] recipes)
        {
            if (_instance == null) return;
            _instance._shopOpen = true;
            _instance._crafting = true;
            _instance._benchTitle = title;
            _instance._benchRecipes = recipes;
            _instance._shopOpened = Time.time;
        }

        static void CloseShop()
        {
            if (_instance == null || !_instance._shopOpen) return;
            _instance._shopOpen = false;
            _instance._closedFrame = Time.frameCount;
        }

        public static void ShowPopup(Sprite icon, string title, string body)
        {
            if (_instance == null) return;
            _instance._popupIcon = icon;
            _instance._popupTitle = title;
            _instance._popupBody = body;
            _instance._popupOpened = Time.time;
        }

        /// <summary>Show a hint above the item bar this frame (call every frame you want it).</summary>
        public static void SetPrompt(string text)
        {
            if (_instance == null || BlimpBee.Riding) return;     // up on the bee, only the bee has something to say
            ForcePrompt(text);
        }

        public static void ForcePrompt(string text)
        {
            if (_instance == null) return;
            _instance._prompt = text;
            _instance._promptFrame = Time.frameCount;
        }
        public static object Speaker => _instance != null ? _instance._speaker : null;

        public static void OpenDialogue(object speaker, string name, string[] lines, System.Action onDone = null)
        {
            if (_instance == null || lines == null || lines.Length == 0) return;
            _instance._onDialogueDone = onDone;
            _instance._speaker = speaker;
            _instance._speakerName = name;
            _instance._lines = lines;
            _instance._lineIndex = 0;
            _instance._lineStarted = Time.time;
        }

        /// <summary>E while talking: finish the typing, then go to the next line, then close.</summary>
        public static void AdvanceDialogue()
        {
            var h = _instance;
            if (h == null || h._lines == null) return;
            if (h.VisibleChars() < h._lines[h._lineIndex].Length) { h._lineStarted = -1000f; return; }
            if (++h._lineIndex >= h._lines.Length)
            {
                var done = h._onDialogueDone;
                CloseDialogue();
                done?.Invoke();     // only when every line was read, not when you walk away
                return;
            }
            h._lineStarted = Time.time;
        }

        public static void CloseDialogue()
        {
            if (_instance == null) return;
            _instance._lines = null;
            _instance._speaker = null;
            _instance._onDialogueDone = null;
        }

        public static void Toast(string message, float seconds = 3f)
        {
            if (_instance == null) return;
            _instance._toast = message;
            _instance._toastUntil = Time.time + seconds;
        }

        void Awake()
        {
            _instance = this;
            var hearts = Art.Strip("heart", 9, 8);
            if (hearts != null) { _heartFull = hearts[0]; _heartEmpty = hearts[1]; }
            _coin = Art.Strip("coin", 8, 8)?[0];
            _white = Texture2D.whiteTexture;
        }

        void Update()
        {
            if (_transition >= 0f)
            {
                float before = _transition;
                _transition += Time.deltaTime;
                if (before < TransitionHalf && _transition >= TransitionHalf)
                {
                    var middle = _transitionMiddle;
                    _transitionMiddle = null;
                    middle?.Invoke();
                }
                if (_transition >= TransitionHalf * 2f) { _transition = -1f; _closedFrame = Time.frameCount; }
            }

            if (PlayerStats.Gold != _shownGold) { _shownGold = PlayerStats.Gold; _goldFlash = 0.35f; }
            _goldFlash -= Time.deltaTime;

            // Popups close on E / F / Space after a short beat, so a mashed key doesn't skip them.
            if (_popupTitle != null && Time.time - _popupOpened > 0.3f &&
                (GameInput.TalkPressed() || GameInput.FishPressed() || GameInput.AttackPressed()))
            {
                _popupTitle = null;
                _closedFrame = Time.frameCount;
            }

            if (_shopOpen && Time.time - _shopOpened > 0.2f && (GameInput.TalkPressed() || GameInput.CancelPressed()))
                CloseShop();
            if (_settingsOpen && GameInput.TalkPressed()) CloseSettings();
            if (_chest != null && Time.time - _shopOpened > 0.2f && (GameInput.TalkPressed() || GameInput.CancelPressed() || GameInput.BagPressed()))
                CloseChest();

            if (GameInput.BagPressed() && !DialogueOpen && !PopupOpen && !_shopOpen && !_settingsOpen && _chest == null && _closedFrame != Time.frameCount)
            {
                _bagOpen = !_bagOpen;
                _bagPick = -1;
            }

            // Esc closes whatever is open, or opens the settings when nothing is.
            if (GameInput.CancelPressed() && _closedFrame != Time.frameCount)
            {
                if (_bagOpen) { _bagOpen = false; _closedFrame = Time.frameCount; }
                else if (_settingsOpen) CloseSettings();
                else if (!WindowOpen && !GameClock.Sleeping && !InTransition) _settingsOpen = true;
            }

            // Number keys pick an item-bar slot; the mouse wheel (or Q / R) turns the toolbelt dial.
            if (!DialogueOpen && !PopupOpen && !MenuOpen)
            {
                int slot = GameInput.SlotPressed();
                if (slot >= 0) Inventory.Select(slot);
                int step = GameInput.CycleSlot();
                if (step != 0) Toolbelt.Turn(step);
            }
        }

        int VisibleChars() => Mathf.FloorToInt((Time.time - _lineStarted) * CharsPerSecond);

        void OnGUI()
        {
            int s = Mathf.Max(2, Mathf.RoundToInt(Screen.height / 270f));   // pixel scale for icons
            if (_text == null) _text = new GUIStyle(GUI.skin.label) { wordWrap = true, richText = true };
            _text.fontSize = 7 * s;
            _text.fontStyle = FontStyle.Bold;
            float pad = 4 * s;

            // Evening darkness goes under everything else on the HUD.
            float dark = GameClock.Darkness;
            if (dark > 0f) Fill(new Rect(0, 0, Screen.width, Screen.height), new Color(0.05f, 0.06f, 0.2f, 0.5f * dark));
            if (!Home.Inside && !Mine.Inside && !Cavern.Inside && !Town.Inside) DrawWeather(s);

            // Hearts, top left.
            for (int i = 0; i < PlayerStats.MaxHealth; i++)
                DrawSprite(i < PlayerStats.Health ? _heartFull : _heartEmpty, new Rect(pad + i * 10 * s, pad, 9 * s, 8 * s));

            // Gold, top right.
            string gold = PlayerStats.Gold.ToString();
            Vector2 size = _text.CalcSize(new GUIContent(gold));
            float x = Screen.width - pad - size.x;
            ShadowLabel(new Rect(x, pad - 1 * s, size.x + 4, size.y), gold, _goldFlash > 0f ? new Color(1f, 0.95f, 0.5f) : Color.white);
            DrawSprite(_coin, new Rect(x - 10 * s, pad, 8 * s, 8 * s));

            // Day and time, under the gold.
            {
                var old = _text.fontSize;
                _text.fontSize = 6 * s;
                string clock = $"{Seasons.DateText}   {GameClock.TimeText}";
                Vector2 cs = _text.CalcSize(new GUIContent(clock));
                ShadowLabel(new Rect(Screen.width - pad - cs.x, pad + 9 * s, cs.x + 4, cs.y), clock,
                    GameClock.Hour >= 24f ? new Color(1f, 0.6f, 0.5f) : Color.white);

                // Under the clock: the mine floor while you're down there, or else the quest board's request.
                var quest = QuestBoard.Current;
                if (Mine.Inside || Cavern.Inside || Town.Inside)
                {
                    _text.fontSize = 5 * s;
                    string f = Mine.Inside ? $"Mine, floor {Mine.Floor}" : Cavern.Inside ? "Crystal cave" : Town.Current.Name;
                    Vector2 fs = _text.CalcSize(new GUIContent(f));
                    ShadowLabel(new Rect(Screen.width - pad - fs.x, pad + 17 * s, fs.x + 4, fs.y), f, new Color(1f, 0.85f, 0.6f));
                }
                else if (quest != null)
                {
                    _text.fontSize = 5 * s;
                    string q = $"{quest.Text}  {Inventory.Count(quest.Item)}/{quest.Amount}";
                    Vector2 qs = _text.CalcSize(new GUIContent(q));
                    ShadowLabel(new Rect(Screen.width - pad - qs.x, pad + 17 * s, qs.x + 4, qs.y), q, new Color(1f, 0.95f, 0.6f));
                }
                _text.fontSize = old;
            }

            // Settings button, under the hearts, then the controls hint (keyboard only; touch has its own buttons).
            if (!WindowOpen && !GameClock.Sleeping)
            {
                var menu = new Rect(pad, pad + 10 * s, 24 * s, 9 * s);
                var style = new GUIStyle(GUI.skin.button) { fontSize = 5 * s, fontStyle = FontStyle.Bold };
                bool tapped = TouchControls.Tapped(new Rect(menu.x - 4 * s, menu.y - 4 * s, menu.width + 8 * s, menu.height + 8 * s));
                if (Press(menu, "MENU", style) || tapped) _settingsOpen = true;
                if (!TouchControls.Active && Settings.KeyHints)
                {
                    var old = _text.fontSize;
                    _text.fontSize = 5 * s;
                    ShadowLabel(new Rect(menu.xMax + 4 * s, pad + 10 * s, Screen.width, 10 * s),
                        "WASD move   Shift run   Space attack   E talk / enter   F use   Wheel or Q/R tools   1-8 items   I bag   N sleep   Esc menu", new Color(1f, 1f, 1f, 0.85f));
                    _text.fontSize = old;
                }
            }

            // Toast, upper middle.
            if (_toast != null && Time.time < _toastUntil)
            {
                var r = new Rect(Screen.width * 0.15f, Screen.height * 0.22f, Screen.width * 0.7f, 30 * s);
                var centered = new GUIStyle(_text) { alignment = TextAnchor.UpperCenter };
                GUI.color = Color.black; GUI.Label(new Rect(r.x + s, r.y + s, r.width, r.height), _toast, centered);
                GUI.color = Color.white; GUI.Label(r, _toast, centered);
            }

            if (_lines != null) DrawDialogue(s);
            else
            {
                if (!GameClock.Sleeping) DrawToolbelt(s);
                DrawHotbar(s);
                if (_prompt != null && Time.frameCount - _promptFrame <= 1 && !Busy)
                {
                    var centered = new GUIStyle(_text) { alignment = TextAnchor.UpperCenter, fontSize = 6 * s };
                    var r = new Rect(0, Screen.height - 40 * s, Screen.width, 10 * s);
                    string prompt = TouchPrompt(_prompt);
                    GUI.color = Color.black; GUI.Label(new Rect(r.x + 2, r.y + 2, r.width, r.height), prompt, centered);
                    GUI.color = new Color(1f, 0.95f, 0.6f); GUI.Label(r, prompt, centered);
                    GUI.color = Color.white;
                }
            }
            if (TouchControls.Active && !MenuOpen && !GameClock.Sleeping) DrawTouchControls(s);
            if (_bagOpen) DrawBag(s);
            if (_chest != null) DrawChest(s);
            if (_shopOpen) { if (_crafting) DrawCrafting(s); else DrawShop(s); }
            if (_settingsOpen) DrawSettings(s);
            if (_popupTitle != null) DrawPopup(s);

            // Falling asleep: fade everything to black.
            float black = Mathf.Max(GameClock.Fade, TransitionAlpha);
            if (black > 0f) Fill(new Rect(0, 0, Screen.width, Screen.height), new Color(0f, 0f, 0f, black));
        }

        void DrawHotbar(int s)
        {
            float slot = 20 * s, gap = 2 * s;
            var area = HotbarRect(s);
            float x0 = area.x, y = area.y;
            var items = Inventory.All;
            var count = new GUIStyle(_text) { alignment = TextAnchor.LowerRight, fontSize = 5 * s };
            for (int i = 0; i < Inventory.HotbarCount; i++)
            {
                var r = new Rect(x0 + i * (slot + gap), y, slot, slot);
                if (TouchControls.Tapped(new Rect(r.x - gap / 2f, r.y - 4 * s, r.width + gap, r.height + 8 * s))) Inventory.Select(i);
                bool fresh = i == Inventory.LastChangedSlot && Time.time - Inventory.LastChangedTime < 0.6f;
                bool picked = i == Inventory.Selected && !Toolbelt.Active;
                if (picked) Fill(new Rect(r.x - 2 * s, r.y - 2 * s, r.width + 4 * s, r.height + 4 * s), new Color32(0xff, 0xf4, 0xc0, 0xff));
                Fill(new Rect(r.x - s, r.y - s, r.width + 2 * s, r.height + 2 * s), new Color32(0x2b, 0x1d, 0x1a, 0xe0));
                Fill(r, fresh ? new Color32(0xff, 0xe0, 0x80, 0xf0) : picked ? new Color32(0xe8, 0xcc, 0x98, 0xe8) : new Color32(0xc8, 0xa8, 0x78, 0xd0));
                if (items[i] == null) continue;
                DrawSprite(items[i].Item.Icon, new Rect(r.x + 2 * s, r.y + 2 * s, 16 * s, 16 * s));
                if (items[i].Item == Items.WateringCan)
                {
                    // How much water is left, as a little bar along the bottom of the slot.
                    var bar = new Rect(r.x + 2 * s, r.yMax - 3 * s, 16 * s, 2 * s);
                    Fill(bar, new Color32(0x2b, 0x1d, 0x1a, 0xc0));
                    Fill(new Rect(bar.x, bar.y, bar.width * Inventory.Water / Inventory.WaterMax, bar.height), new Color32(0x4f, 0xa4, 0xd8, 0xff));
                }
                if (items[i].Count > 1)
                {
                    count.normal.textColor = Color.black;
                    GUI.Label(new Rect(r.x + 1, r.y + 1, r.width - s, r.height), items[i].Count.ToString(), count);
                    count.normal.textColor = Color.white;
                    GUI.Label(new Rect(r.x, r.y, r.width - s, r.height), items[i].Count.ToString(), count);
                }
            }

            // Name of the picked item, for a moment after you pick it.
            var selected = Inventory.SelectedItem;
            if (selected != null && !Toolbelt.Active && Time.time - Inventory.SelectedTime < 1.5f)
            {
                var label = new GUIStyle(_text) { alignment = TextAnchor.UpperCenter, fontSize = 6 * s };
                var lr = new Rect(0, y - 11 * s, Screen.width, 10 * s);
                label.normal.textColor = Color.black;
                GUI.Label(new Rect(lr.x + 2, lr.y + 2, lr.width, lr.height), selected.Name, label);
                label.normal.textColor = Color.white;
                GUI.Label(lr, selected.Name, label);
            }
        }

        // The toolbelt: an upright dial of your key tools, top left, like a mouse wheel seen side on.
        // The picked tool sits big in the middle; slide it up or down (or tap above or below) to change.
        void DrawToolbelt(int s)
        {
            var tools = Toolbelt.Tools;
            if (tools.Count == 0) return;
            var box = DialRect(s);
            float step = DialStep(s);
            int n = tools.Count, index = ((Toolbelt.Index % n) + n) % n;
            bool active = Toolbelt.Active;

            // Dragging: every step of finger travel turns the dial one tool. Up shows the tools below.
            if (Event.current.type == EventType.Repaint)
            {
                if (TouchControls.DialHeld)
                {
                    _dialDrag += TouchControls.DialDelta;
                    while (_dialDrag <= -step) { _dialDrag += step; Toolbelt.Turn(1); }
                    while (_dialDrag >= step) { _dialDrag -= step; Toolbelt.Turn(-1); }
                    index = ((Toolbelt.Index % n) + n) % n;
                }
                else _dialDrag = Mathf.MoveTowards(_dialDrag, 0f, step * 8f * Time.unscaledDeltaTime);
                // Ease the drawn position toward the picked tool the short way round.
                float diff = Mathf.Repeat(index - _dialPos + n / 2f, n) - n / 2f;
                _dialPos = Mathf.Repeat(_dialPos + diff * (1f - Mathf.Exp(-16f * Time.unscaledDeltaTime)), n);
            }
            float shown = _dialPos - _dialDrag / step;

            // The wheel: a dark rounded slot, a light band across the middle where the picked tool sits.
            var old = GUI.color;
            var frame = new Rect(box.x - s, box.y - s, box.width + 2 * s, box.height + 2 * s);
            if (active) Fill(new Rect(frame.x - s, frame.y - s, frame.width + 2 * s, frame.height + 2 * s), new Color(1f, 0.92f, 0.55f, 0.9f));
            Fill(frame, new Color32(0x2b, 0x1d, 0x1a, 0xe0));
            Fill(box, new Color(0.25f, 0.17f, 0.14f, active ? 0.85f : 0.6f));
            float cy = box.y + box.height / 2f;
            Fill(new Rect(box.x, cy - 10 * s, box.width, 20 * s), new Color(0.96f, 0.91f, 0.82f, active ? 0.95f : 0.6f));

            GUI.BeginGroup(box);
            for (int k = -3; k <= 3; k++)
            {
                if (n < 2 && k != 0) continue;
                int i = Mathf.RoundToInt(shown) + k;
                float off = i - shown;                      // tools from the middle, fractional while it moves
                if (Mathf.Abs(off) > 2.2f || (n <= 4 && Mathf.Abs(off) > (n - 1) / 2f + 0.5f)) continue;
                var tool = tools[((i % n) + n) % n];
                float t = Mathf.Clamp01(1f - Mathf.Abs(off));
                float size = Mathf.Lerp(9f, 16f, t) * s;
                float y = box.height / 2f + off * 19f * s;
                GUI.color = new Color(1f, 1f, 1f, active ? Mathf.Lerp(0.55f, 1f, t) : Mathf.Lerp(0.4f, 0.6f, t));
                DrawSprite(Toolbelt.Icon(tool), new Rect((box.width - size) / 2f, y - size / 2f, size, size));
            }
            GUI.color = old;
            GUI.EndGroup();

            // Little arrows top and bottom say it slides.
            var tip = new Color(1f, 0.95f, 0.85f, 0.8f);
            float mid = box.x + box.width / 2f;
            for (int row = 0; row < 3; row++)
            {
                Fill(new Rect(mid - (row + 0.5f) * s, box.y + (1 + row) * s, (2 * row + 1) * s, s), tip);
                Fill(new Rect(mid - (row + 0.5f) * s, box.yMax - (2 + row) * s, (2 * row + 1) * s, s), tip);
            }

            var current = tools[index];
            if (current == Items.WateringCan)
            {
                // Water left in the can, as a little bar under the dial.
                var bar = new Rect(box.x, box.yMax + 3 * s, box.width, 2 * s);
                Fill(bar, new Color32(0x2b, 0x1d, 0x1a, 0xc0));
                Fill(new Rect(bar.x, bar.y, bar.width * Inventory.Water / Inventory.WaterMax, bar.height), new Color32(0x4f, 0xa4, 0xd8, 0xff));
            }

            // The tool's name beside the dial for a moment after you turn to it.
            if (Time.time - Toolbelt.TurnedTime < 1.5f)
            {
                var label = new GUIStyle(_text) { alignment = TextAnchor.MiddleLeft, fontSize = 5 * s };
                ShadowLabel(new Rect(box.xMax + 4 * s, cy - 5 * s, 80 * s, 10 * s), current.Name, Color.white, label);
            }

            // A tap (or click) above the middle turns back, below turns forward, on the middle takes the tool up.
            if (WindowOpen) return;
            var upper = new Rect(box.x - 4 * s, box.y - 4 * s, box.width + 8 * s, box.height / 2f - 10 * s + 4 * s);
            var middle = new Rect(box.x - 4 * s, cy - 10 * s, box.width + 8 * s, 20 * s);
            var lower = new Rect(box.x - 4 * s, cy + 10 * s, box.width + 8 * s, box.height / 2f - 10 * s + 4 * s);
            if (TouchControls.Active)
            {
                if (TouchControls.DialTap is Vector2 tap)
                {
                    if (upper.Contains(tap)) Toolbelt.Turn(-1);
                    else if (lower.Contains(tap)) Toolbelt.Turn(1);
                    else if (middle.Contains(tap)) Toolbelt.Pick(current);
                }
            }
            else if (Clicked(upper)) Toolbelt.Turn(-1);
            else if (Clicked(lower)) Toolbelt.Turn(1);
            else if (Clicked(middle)) Toolbelt.Pick(current);
        }

        // A click (mouse) or tap (touch) inside r this frame.
        static bool Clicked(Rect r)
        {
            if (TouchControls.Active) return TouchControls.Tapped(r);
            var e = Event.current;
            if (e == null || e.type != EventType.MouseDown || e.button != 0 || !r.Contains(e.mousePosition)) return false;
            e.Use();
            return true;
        }

        // One slot of a bag or chest grid. Returns true when it was clicked or tapped.
        bool DrawSlot(Rect r, Inventory.Stack stack, bool lit, int s)
        {
            Fill(new Rect(r.x - s, r.y - s, r.width + 2 * s, r.height + 2 * s), lit ? new Color32(0xff, 0xf4, 0xc0, 0xff) : new Color32(0x2b, 0x1d, 0x1a, 0xe0));
            Fill(r, lit ? new Color32(0xff, 0xe0, 0x80, 0xf0) : new Color32(0xc8, 0xa8, 0x78, 0xd0));
            if (stack != null)
            {
                float ic = r.width - 4 * s;
                DrawSprite(stack.Item.Icon, new Rect(r.x + 2 * s, r.y + 2 * s, ic, ic));
                if (stack.Count > 1)
                {
                    var count = new GUIStyle(_text) { alignment = TextAnchor.LowerRight, fontSize = 5 * s };
                    count.normal.textColor = Color.black;
                    GUI.Label(new Rect(r.x + 1, r.y + 1, r.width - s, r.height), stack.Count.ToString(), count);
                    count.normal.textColor = Color.white;
                    GUI.Label(new Rect(r.x, r.y, r.width - s, r.height), stack.Count.ToString(), count);
                }
            }
            return Clicked(r);
        }

        Rect Window(float w, float h, int s, string titleText, string keyHint, System.Action close)
        {
            var box = new Rect((Screen.width - w) / 2f, Mathf.Max(2 * s, (Screen.height - h) / 2f - 10 * s), w, h);
            Fill(new Rect(box.x - s, box.y - s, box.width + 2 * s, box.height + 2 * s), new Color32(0x2b, 0x1d, 0x1a, 0xff));
            Fill(box, new Color32(0xf4, 0xe9, 0xd0, 0xf8));
            var title = new GUIStyle(_text);
            title.normal.textColor = new Color32(0xa8, 0x40, 0x2f, 0xff);
            GUI.Label(new Rect(box.x + 6 * s, box.y + 4 * s, w, 10 * s), titleText, title);
            var hint = new GUIStyle(_text) { alignment = TextAnchor.UpperRight, fontSize = 5 * s };
            hint.normal.textColor = new Color32(0x6b, 0x5a, 0x4a, 0xff);
            if (TouchControls.Active) { if (CloseButton(box, s)) close(); }
            else GUI.Label(new Rect(box.x, box.y + 5 * s, w - 6 * s, 10 * s), keyHint, hint);
            return box;
        }

        void SmallLabel(Rect r, string text, int s, Color32 color)
        {
            var st = new GUIStyle(_text) { fontSize = 5 * s, fontStyle = FontStyle.Normal, wordWrap = false };
            st.normal.textColor = color;
            GUI.Label(r, text, st);
        }

        // The bag: your tools, all 16 slots (the top row is the item bar), and your friends.
        // Tap an item, then tap another slot to move it there.
        void DrawBag(int s)
        {
            var friends = Friendship.All;
            float slot = 18 * s, gap = 2 * s, cols = Inventory.HotbarCount;
            float gridW = cols * slot + (cols - 1) * gap;
            float w = gridW + 12 * s;
            float h = 16 * s + 22 * s + 2 * (slot + gap) + 14 * s + 18 * s + (friends.Count > 0 ? 12 * s + friends.Count * 8 * s : 0);
            var box = Window(w, h, s, "Bag", "I  close", () => { _bagOpen = false; _closedFrame = Time.frameCount; });
            var brown = new Color32(0x6b, 0x5a, 0x4a, 0xff);
            var ink = new Color32(0x2b, 0x1d, 0x1a, 0xff);

            // Two tabs: your things, and your creature friends.
            var tabStyle = new GUIStyle(GUI.skin.button) { fontSize = 5 * s, fontStyle = FontStyle.Bold };
            var itemsTab = new Rect(box.x + 30 * s, box.y + 3 * s, 34 * s, 10 * s);
            var creaturesTab = new Rect(itemsTab.xMax + 2 * s, itemsTab.y, 44 * s, 10 * s);
            var oldBg = GUI.backgroundColor;
            GUI.backgroundColor = _creatureTab ? new Color(0.62f, 0.5f, 0.4f) : new Color(0.66f, 0.25f, 0.18f);
            if (Press(itemsTab, "Items", tabStyle)) { _creatureTab = false; _bagPick = -1; }
            GUI.backgroundColor = _creatureTab ? new Color(0.66f, 0.25f, 0.18f) : new Color(0.62f, 0.5f, 0.4f);
            if (Press(creaturesTab, "Creatures", tabStyle)) { _creatureTab = true; _bagPick = -1; }
            GUI.backgroundColor = oldBg;
            if (_creatureTab) { DrawCreatures(box, s, ink, brown); return; }

            // Toolbelt.
            float y = box.y + 15 * s;
            SmallLabel(new Rect(box.x + 6 * s, y, w, 8 * s), "Toolbelt (slide the dial, or use the mouse wheel or Q / R)", s, brown);
            var tools = Toolbelt.Tools;
            for (int i = 0; i < tools.Count; i++)
            {
                var r = new Rect(box.x + 6 * s + i * (14 * s + gap), y + 8 * s, 14 * s, 14 * s);
                Fill(r, new Color32(0xe8, 0xcc, 0x98, 0xe8));
                DrawSprite(Toolbelt.Icon(tools[i]), new Rect(r.x + s, r.y + s, 12 * s, 12 * s));
                if (Clicked(r)) { Toolbelt.Pick(tools[i]); }
            }

            // Slots: the item bar, then the rest of the bag.
            y += 26 * s;
            SmallLabel(new Rect(box.x + 6 * s, y - 4 * s, w, 8 * s), "Item bar", s, brown);
            for (int i = 0; i < Inventory.SlotCount; i++)
            {
                int row = i / Inventory.HotbarCount, col = i % Inventory.HotbarCount;
                var r = new Rect(box.x + 6 * s + col * (slot + gap), y + 4 * s + row * (slot + gap) + (row > 0 ? 3 * s : 0), slot, slot);
                if (!DrawSlot(r, Inventory.All[i], i == _bagPick, s)) continue;
                if (_bagPick < 0) { if (Inventory.All[i] != null) _bagPick = i; }
                else { Inventory.Swap(_bagPick, i); _bagPick = -1; }
            }

            // What's picked up, or how to move things.
            y += 4 * s + 2 * (slot + gap) + 4 * s;
            var picked = _bagPick >= 0 ? Inventory.All[_bagPick] : null;
            string info = picked == null ? "Tap an item, then tap where you want it."
                : $"{picked.Item.Name}" + (picked.Count > 1 ? $" x{picked.Count}" : "") + (picked.Item.SellPrice > 0 ? $"   Mabel pays {picked.Item.SellPrice}g each" : "")
                  + "   Now tap where it goes.";
            SmallLabel(new Rect(box.x + 6 * s, y, w - 12 * s, 9 * s), info, s, ink);

            // Friends and their hearts.
            if (friends.Count == 0) return;
            float fy = y + 12 * s;
            var title = new GUIStyle(_text) { fontSize = 6 * s };
            title.normal.textColor = new Color32(0xa8, 0x40, 0x2f, 0xff);
            GUI.Label(new Rect(box.x + 6 * s, fy, w, 10 * s), "Friends", title);
            for (int i = 0; i < friends.Count; i++)
            {
                float fr = fy + 10 * s + i * 8 * s;
                SmallLabel(new Rect(box.x + 6 * s, fr, 70 * s, 8 * s), friends[i].Name, s, ink);
                for (int k = 0; k < Friendship.MaxHearts; k++)
                    DrawSprite(k < friends[i].Hearts ? _heartFull : _heartEmpty, new Rect(box.x + 80 * s + k * 9 * s, fr + 1 * s, 7 * s, 6.2f * s));
            }
        }

        // The Creatures tab: your creature friends, and which one follows you (only one at a time).
        void DrawCreatures(Rect box, int s, Color32 ink, Color32 brown)
        {
            float y = box.y + 17 * s;
            var cards = new System.Collections.Generic.List<(CreatureKind kind, Sprite icon, string name, string doing)>();
            if (Jackalope.Friend) cards.Add((CreatureKind.Jackalope, Jackalope.Icon, "Jackalope", Jackalope.Following ? "Hopping along with you. Chases slimes." : "Staying home"));
            if (CannonTurtle.Friend) cards.Add((CreatureKind.Turtle, CannonTurtle.Icon, "Cannonball Turtle", CannonTurtle.Following ? "Trotting after you. Bowls over slimes." : "Staying home"));
            if (BlimpBee.Friend) cards.Add((CreatureKind.BlimpBee, BlimpBee.Icon, "Blimp Bee", BlimpBee.Riding ? "You're riding it!" : !BlimpBee.Following ? "Staying home" : BlimpBee.Landed ? "Resting nearby. Ride it!" : "Floating along behind you"));

            var name = new GUIStyle(_text) { fontSize = 6 * s };
            name.normal.textColor = ink;
            var button = new GUIStyle(GUI.skin.button) { fontSize = 5 * s, fontStyle = FontStyle.Bold };
            foreach (var (kind, icon, title, doing) in cards)
            {
                var card = new Rect(box.x + 6 * s, y, box.width - 12 * s, 24 * s);
                Fill(card, new Color32(0xe8, 0xcc, 0x98, 0xe8));
                DrawSprite(icon, new Rect(card.x + 2 * s, card.y + 2 * s, 20 * s, 20 * s));
                GUI.Label(new Rect(card.x + 25 * s, card.y + 2 * s, 90 * s, 10 * s), title, name);
                SmallLabel(new Rect(card.x + 25 * s, card.y + 12 * s, 100 * s, 8 * s), doing, s, brown);
                bool following = Creatures.Follower == kind;
                var toggle = new Rect(card.xMax - 40 * s, card.y + 6.5f * s, 37 * s, 11 * s);
                if (BlimpBee.Riding && kind != CreatureKind.BlimpBee)
                    SmallLabel(new Rect(toggle.x, toggle.y + 2 * s, toggle.width, 8 * s), "Land first", s, brown);
                else if (Press(toggle, following ? "Stay home" : "Follow me", button))
                {
                    if (following) { if (!BlimpBee.Riding || BlimpBee.Land(false)) Creatures.StayHome(kind); }
                    else Creatures.Follow(kind);
                }
                if (kind == CreatureKind.BlimpBee && following)
                {
                    var ride = new Rect(toggle.x - 30 * s, toggle.y, 28 * s, 11 * s);
                    if (BlimpBee.Riding) { if (Press(ride, "Land", button)) BlimpBee.Land(false); }
                    else if (BlimpBee.CanRide && Press(ride, "Ride", button)) { BlimpBee.Ride(); _bagOpen = false; _closedFrame = Time.frameCount; }
                }
                y += 27 * s;
            }

            // Hints about the ones you haven't met yet.
            var hints = new System.Collections.Generic.List<string>();
            if (!Jackalope.Friend) hints.Add("Something with antlers hops about behind the village...");
            if (!CannonTurtle.Friend) hints.Add("Something clanks and rolls about up in the mountains...");
            if (!BlimpBee.Friend) hints.Add("Something big and fuzzy buzzes in the meadow north of the farm...");
            if (cards.Count == 0) { SmallLabel(new Rect(box.x + 6 * s, y, box.width - 12 * s, 8 * s), "No creature friends yet.", s, ink); y += 9 * s; }
            else if (hints.Count > 0) y += 1 * s;
            else SmallLabel(new Rect(box.x + 6 * s, y, box.width - 12 * s, 8 * s), "Only one friend can follow you at a time.", s, brown);
            foreach (var h in hints)
            {
                SmallLabel(new Rect(box.x + 6 * s, y, box.width - 12 * s, 8 * s), h, s, brown);
                y += 8 * s;
            }
        }

        // A chest: its 16 slots above, your bag below. Tap a stack to move it across.
        void DrawChest(int s)
        {
            float slot = 18 * s, gap = 2 * s, cols = Inventory.HotbarCount;
            float w = cols * slot + (cols - 1) * gap + 12 * s;
            float h = 16 * s + 2 * (2 * (slot + gap) + 12 * s) + 10 * s;
            var box = Window(w, h, s, "Chest", "E / Esc  close", CloseChest);
            var brown = new Color32(0x6b, 0x5a, 0x4a, 0xff);
            float y = box.y + 16 * s;
            SmallLabel(new Rect(box.x + 6 * s, y, w, 8 * s), "In the chest (tap to take)", s, brown);
            for (int i = 0; i < ChestBox.Size; i++)
            {
                var r = new Rect(box.x + 6 * s + (i % 8) * (slot + gap), y + 9 * s + (i / 8) * (slot + gap), slot, slot);
                if (DrawSlot(r, _chest.Slots[i], false, s) && _chest.Slots[i] != null)
                {
                    if (Inventory.Add(_chest.Slots[i].Item, _chest.Slots[i].Count)) _chest.Slots[i] = null;
                    else Toast("Your bag is full!", 2f);
                }
            }
            y += 9 * s + 2 * (slot + gap) + 4 * s;
            SmallLabel(new Rect(box.x + 6 * s, y, w, 8 * s), "Your bag (tap to put away)", s, brown);
            for (int i = 0; i < Inventory.SlotCount; i++)
            {
                var r = new Rect(box.x + 6 * s + (i % 8) * (slot + gap), y + 9 * s + (i / 8) * (slot + gap), slot, slot);
                if (DrawSlot(r, Inventory.All[i], false, s) && Inventory.All[i] != null)
                {
                    var stack = Inventory.All[i];
                    if (_chest.HasRoomFor(stack.Item)) _chest.Put(Inventory.Take(i));
                    else Toast("The chest is full!", 2f);
                }
            }
        }

        void CloseSettings()
        {
            _settingsOpen = false;
            _closedFrame = Time.frameCount;
        }

        // The settings menu: relaxed days, keyboard hints, and resetting your progress (press twice to be sure).
        void DrawSettings(int s)
        {
            float w = Mathf.Min(Screen.width - 16 * s, 170 * s), row = 16 * s, h = 26 * s + 4 * row;
            var box = new Rect((Screen.width - w) / 2f, (Screen.height - h) / 2f - 10 * s, w, h);
            Fill(new Rect(box.x - s, box.y - s, box.width + 2 * s, box.height + 2 * s), new Color32(0x2b, 0x1d, 0x1a, 0xff));
            Fill(box, new Color32(0xf4, 0xe9, 0xd0, 0xf8));

            var title = new GUIStyle(_text);
            title.normal.textColor = new Color32(0xa8, 0x40, 0x2f, 0xff);
            GUI.Label(new Rect(box.x + 6 * s, box.y + 4 * s, w, 10 * s), "Settings", title);
            if (TouchControls.Active) { if (CloseButton(box, s)) CloseSettings(); }
            else
            {
                var hint = new GUIStyle(_text) { alignment = TextAnchor.UpperRight, fontSize = 5 * s };
                hint.normal.textColor = new Color32(0x6b, 0x5a, 0x4a, 0xff);
                GUI.Label(new Rect(box.x, box.y + 5 * s, w - 6 * s, 10 * s), "Esc  close", hint);
            }

            var body = new GUIStyle(_text) { fontStyle = FontStyle.Normal, fontSize = 6 * s };
            body.normal.textColor = new Color32(0x2b, 0x1d, 0x1a, 0xff);
            var button = new GUIStyle(GUI.skin.button) { fontSize = 5 * s, fontStyle = FontStyle.Bold };
            float y = box.y + 18 * s, bw = 46 * s, bx = box.xMax - bw - 6 * s;

            GUI.Label(new Rect(box.x + 6 * s, y + 2 * s, w - bw - 16 * s, row), "Day length", body);
            if (Press(new Rect(bx, y, bw, 12 * s), Settings.LongDays ? "Relaxed (6 min)" : "Normal (3 min)", button))
                Settings.LongDays = !Settings.LongDays;
            y += row;

            if (!TouchControls.Active)
            {
                GUI.Label(new Rect(box.x + 6 * s, y + 2 * s, w - bw - 16 * s, row), "Keyboard hints", body);
                if (Press(new Rect(bx, y, bw, 12 * s), Settings.KeyHints ? "Shown" : "Hidden", button))
                    Settings.KeyHints = !Settings.KeyHints;
            }
            y += row;

            GUI.Label(new Rect(box.x + 6 * s, y + 2 * s, w - 12 * s, row), $"Saved each night. Now: {Seasons.DateText}", body);
            y += row;

            bool asked = Time.time - _resetAsked < 3f;
            GUI.backgroundColor = asked ? new Color(0.8f, 0.2f, 0.15f) : Color.white;
            if (Press(new Rect(box.x + 6 * s, y, w - 12 * s, 12 * s),
                    asked ? (TouchControls.Active ? "Tap again to erase your farm" : "Click again to erase your farm") : "Reset progress", button))
            {
                if (asked) SaveGame.StartOver();
                else _resetAsked = Time.time;
            }
            GUI.backgroundColor = Color.white;
        }

        void DrawCrafting(int s)
        {
            float row = 24 * s;
            var recipes = _benchRecipes ?? Crafting.All;
            float w = Mathf.Min(Screen.width - 16 * s, 250 * s), h = 22 * s + recipes.Length * row;
            var box = new Rect((Screen.width - w) / 2f, (Screen.height - h) / 2f - 10 * s, w, h);
            Fill(new Rect(box.x - s, box.y - s, box.width + 2 * s, box.height + 2 * s), new Color32(0x2b, 0x1d, 0x1a, 0xff));
            Fill(box, new Color32(0xf4, 0xe9, 0xd0, 0xf8));

            var title = new GUIStyle(_text);
            title.normal.textColor = new Color32(0xa8, 0x40, 0x2f, 0xff);
            GUI.Label(new Rect(box.x + 6 * s, box.y + 4 * s, w, 10 * s), _benchTitle, title);
            var hint = new GUIStyle(_text) { alignment = TextAnchor.UpperRight, fontSize = 5 * s };
            hint.normal.textColor = new Color32(0x6b, 0x5a, 0x4a, 0xff);
            if (TouchControls.Active) { if (CloseButton(box, s)) CloseShop(); }
            else GUI.Label(new Rect(box.x, box.y + 5 * s, w - 6 * s, 10 * s), "E / Esc  close", hint);

            var name = new GUIStyle(_text) { fontSize = 6 * s };
            name.normal.textColor = new Color32(0x2b, 0x1d, 0x1a, 0xff);
            var small = new GUIStyle(_text) { fontStyle = FontStyle.Normal, fontSize = 5 * s };
            small.normal.textColor = new Color32(0x4a, 0x3a, 0x2e, 0xff);
            var cost = new GUIStyle(small);
            var button = new GUIStyle(GUI.skin.button) { fontSize = 5 * s, fontStyle = FontStyle.Bold };

            for (int i = 0; i < recipes.Length; i++)
            {
                var r = recipes[i];
                float y = box.y + 18 * s + i * row;
                bool owned = r.Owned != null && r.Owned();
                DrawSprite(r.Icon.Icon, new Rect(box.x + 6 * s, y + 2 * s, 16 * s, 16 * s));
                float textW = w - 74 * s;
                GUI.Label(new Rect(box.x + 26 * s, y, textW, 9 * s), r.Name, name);
                GUI.Label(new Rect(box.x + 26 * s, y + 8 * s, textW, 8 * s), r.Text, small);
                bool can = Crafting.Has(r);
                cost.normal.textColor = owned ? new Color32(0x3f, 0x7a, 0x3f, 0xff) : can ? new Color32(0x4a, 0x3a, 0x2e, 0xff) : new Color32(0xa8, 0x40, 0x2f, 0xff);
                GUI.Label(new Rect(box.x + 26 * s, y + 15 * s, textW, 8 * s), owned ? r.OwnedLabel?.Invoke() ?? "You have this" : "Needs " + r.CostText, cost);
                GUI.enabled = !owned && can;
                if (Press(new Rect(box.xMax - 44 * s, y + 5 * s, 38 * s, 12 * s), owned ? "Done" : r.Verb, button))
                    Toast(Crafting.Make(r), 2.5f);
                GUI.enabled = true;
            }
        }

        void DrawShop(int s)
        {
            var shop = _shopDef;
            if (shop == null) return;
            var sellable = new System.Collections.Generic.List<Inventory.Stack>();
            foreach (var stack in Inventory.All) if (stack != null && shop.Buys(stack.Item)) sellable.Add(stack);

            var stock = shop.Stock();
            int rows = Mathf.Max(stock.Count, Mathf.Max(1, sellable.Count));
            float row = Mathf.Min(18 * s, (Screen.height - 44 * s) / rows);   // squeeze the rows when the bag is full
            float ic = Mathf.Min(16 * s, row - s);
            float w = Mathf.Min(Screen.width - 16 * s, 250 * s), h = 34 * s + rows * row;
            var box = new Rect((Screen.width - w) / 2f, (Screen.height - h) / 2f - 10 * s, w, h);
            Fill(new Rect(box.x - s, box.y - s, box.width + 2 * s, box.height + 2 * s), new Color32(0x2b, 0x1d, 0x1a, 0xff));
            Fill(box, new Color32(0xf4, 0xe9, 0xd0, 0xf8));

            var title = new GUIStyle(_text);
            title.normal.textColor = new Color32(0xa8, 0x40, 0x2f, 0xff);
            GUI.Label(new Rect(box.x + 6 * s, box.y + 4 * s, w, 10 * s), shop.Title, title);
            var hint = new GUIStyle(_text) { alignment = TextAnchor.UpperRight, fontSize = 5 * s };
            hint.normal.textColor = new Color32(0x6b, 0x5a, 0x4a, 0xff);
            if (TouchControls.Active) { if (CloseButton(box, s)) CloseShop(); }
            else GUI.Label(new Rect(box.x, box.y + 5 * s, w - 6 * s, 10 * s), "E / Esc  close", hint);

            var head = new GUIStyle(_text) { fontSize = 6 * s };
            head.normal.textColor = new Color32(0x6b, 0x5a, 0x4a, 0xff);
            var body = new GUIStyle(_text) { fontStyle = FontStyle.Normal, fontSize = 6 * s };
            body.normal.textColor = new Color32(0x2b, 0x1d, 0x1a, 0xff);
            var button = new GUIStyle(GUI.skin.button) { fontSize = 5 * s, fontStyle = FontStyle.Bold };

            float half = w / 2f, top = box.y + 16 * s;
            GUI.Label(new Rect(box.x + 6 * s, top, half, 10 * s), "Buy", head);
            GUI.Label(new Rect(box.x + half + 4 * s, top, half, 10 * s), "Sell", head);
            Fill(new Rect(box.x + half - s / 2f, top, s, h - 20 * s), new Color32(0xc8, 0xa8, 0x78, 0xff));

            // Buy column.
            for (int i = 0; i < stock.Count; i++)
            {
                var (item, price) = stock[i];
                float y = top + 10 * s + i * row;
                DrawSprite(item.Icon, new Rect(box.x + 6 * s, y, ic, ic));
                GUI.Label(new Rect(box.x + 24 * s, y + 4 * s, half - 60 * s, row), item.Name, body);
                bool canAfford = PlayerStats.Gold >= price;
                GUI.enabled = canAfford;
                if (Press(new Rect(box.x + half - 34 * s, y + 2 * s, 30 * s, 12 * s), $"{price}g", button))
                {
                    if (item == Items.Chicken)
                    {
                        if (!Animals.CanBuyChicken) Toast($"Your coop is full. {Animals.MaxChickens} hens is plenty!", 2.5f);
                        else { PlayerStats.Gold -= price; Animals.BuyChicken(); Toast("Your new hen is in the coop yard. She'll lay in a couple of days.", 3f); }
                    }
                    else if (item == Items.Cow || item == Items.Goat || item == Items.Pig)
                    {
                        if (!Barn.CanBuy) Toast($"Your barn is full. {Barn.MaxBeasts} animals is plenty!", 2.5f);
                        else
                        {
                            PlayerStats.Gold -= price;
                            Barn.Buy(item == Items.Cow ? BeastKind.Cow : item == Items.Goat ? BeastKind.Goat : BeastKind.Pig);
                            Toast($"Your new {item.Name.ToLower()} is in the pasture by the barn, west of the crossroads.", 3.5f);
                        }
                    }
                    else if (!Inventory.HasRoomFor(item)) Toast("Your bag is full!", 2f);
                    else { PlayerStats.Gold -= price; Inventory.Add(item); }
                }
                GUI.enabled = true;
            }

            // Sell column.
            if (sellable.Count == 0)
                GUI.Label(new Rect(box.x + half + 4 * s, top + 14 * s, half - 8 * s, row * 2), shop.Empty, body);
            for (int i = 0; i < sellable.Count; i++)
            {
                var stack = sellable[i];
                float y = top + 10 * s + i * row;
                float x = box.x + half + 4 * s;
                DrawSprite(stack.Item.Icon, new Rect(x, y, ic, ic));
                string label = stack.Count > 1 ? $"{stack.Item.Name} x{stack.Count}" : stack.Item.Name;
                GUI.Label(new Rect(x + 18 * s, y + 4 * s, half - 80 * s, row), label, body);
                int pays = shop.Pays(stack.Item);
                if (Press(new Rect(box.xMax - 62 * s, y + 2 * s, 28 * s, 12 * s), $"{pays}g", button))
                    Sell(stack.Item, 1, pays);
                if (stack.Count > 1 && Press(new Rect(box.xMax - 32 * s, y + 2 * s, 28 * s, 12 * s), "All", button))
                    Sell(stack.Item, stack.Count, pays);
            }
        }

        // A shop button. By touch it answers taps instead of clicks, since phones fake a click for every tap.
        static bool Press(Rect r, string label, GUIStyle style)
        {
            // The default button is a see-through grey that washes out on the cream windows,
            // so lay a solid one under it (brown, or the tint given by GUI.backgroundColor).
            var old = GUI.color;
            var fill = GUI.backgroundColor == Color.white ? ButtonFill : GUI.backgroundColor;
            GUI.color = new Color(fill.r, fill.g, fill.b, GUI.enabled ? 1f : 0.45f);
            GUI.DrawTexture(r, Texture2D.whiteTexture);
            GUI.color = old;
            if (!TouchControls.Active) return GUI.Button(r, label, style);
            GUI.Box(r, label, style);
            return GUI.enabled && TouchControls.Tapped(r);
        }

        static readonly Color ButtonFill = new Color(0.45f, 0.29f, 0.19f);

        // The X in a window's corner, for touch.
        bool CloseButton(Rect box, int s)
        {
            var r = new Rect(box.xMax - 16 * s, box.y + 2 * s, 14 * s, 12 * s);
            var style = new GUIStyle(GUI.skin.button) { fontSize = 6 * s, fontStyle = FontStyle.Bold };
            GUI.Box(r, "X", style);
            return TouchControls.Tapped(new Rect(r.x - 4 * s, r.y - 4 * s, r.width + 8 * s, r.height + 8 * s));
        }

        // Keyboard hints in prompts ("F  Plant", "E  Go inside") become the touch button names.
        static string TouchPrompt(string text)
        {
            if (!TouchControls.Active || text.Length < 3 || text[1] != ' ' || text[2] != ' ') return text;
            if (text[0] == 'F') return "USE  " + text.Substring(3);
            if (text[0] == 'E') return "TALK  " + text.Substring(3);
            return text;
        }

        void DrawTouchControls(int s)
        {
            // Joystick: a ring where your thumb landed and a knob that follows it.
            if (TouchControls.StickShown)
            {
                float r = TouchControls.StickRadius;
                DrawDisc(TouchControls.StickBase, r, new Color(1f, 1f, 1f, 0.18f));
                DrawDisc(TouchControls.StickKnob, r * 0.45f, new Color(1f, 1f, 1f, 0.55f));
            }
            else if (!WindowOpen)
            {
                var hint = new GUIStyle(_text) { alignment = TextAnchor.MiddleCenter, fontSize = 5 * s };
                hint.normal.textColor = new Color(1f, 1f, 1f, 0.45f);
                GUI.Label(new Rect(0, Screen.height * 0.45f, Screen.width * 0.3f, 12 * s), "drag here to move", hint);
            }

            var label = new GUIStyle(_text) { alignment = TextAnchor.MiddleCenter, fontSize = 5 * s };
            foreach (TouchControls.Button b in System.Enum.GetValues(typeof(TouchControls.Button)))
            {
                TouchControls.Layout(b, out var c, out var radius);
                bool held = TouchControls.IsHeld(b);
                DrawDisc(c, radius, held ? new Color(1f, 0.92f, 0.6f, 0.75f) : new Color(0.17f, 0.11f, 0.1f, 0.55f));
                label.normal.textColor = held ? new Color(0.17f, 0.11f, 0.1f) : Color.white;
                GUI.Label(new Rect(c.x - radius, c.y - radius, radius * 2, radius * 2), TouchControls.Label(b), label);
            }
        }

        static Texture2D _disc;

        // A soft-edged filled circle, drawn from one small texture made on first use.
        void DrawDisc(Vector2 centre, float radius, Color color)
        {
            if (_disc == null)
            {
                const int n = 64;
                _disc = new Texture2D(n, n, TextureFormat.RGBA32, false) { filterMode = FilterMode.Bilinear, wrapMode = TextureWrapMode.Clamp };
                var px = new Color32[n * n];
                for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(n / 2f, n / 2f)) / (n / 2f);
                    byte a = (byte)(255 * Mathf.Clamp01((1f - d) * 12f));
                    px[y * n + x] = new Color32(255, 255, 255, a);
                }
                _disc.SetPixels32(px);
                _disc.Apply();
            }
            var old = GUI.color;
            GUI.color = color;
            GUI.DrawTexture(new Rect(centre.x - radius, centre.y - radius, radius * 2, radius * 2), _disc);
            GUI.color = old;
        }

        // Snow in winter, falling leaves in fall, blossom drifting by in spring. Drawn over the farm, under the HUD.
        void DrawWeather(int s)
        {
            var season = Seasons.Current;
            if (season == Season.Summer) return;
            int count = season == Season.Winter ? 70 : season == Season.Fall ? 16 : 10;
            float speed = season == Season.Winter ? 22f : 14f;
            for (int i = 0; i < count; i++)
            {
                // Each flake gets its own fixed lane, speed and sway from its index.
                float lane = Mathf.Repeat(i * 0.6180339f, 1f), drift = 0.6f + Mathf.Repeat(i * 0.3819f, 1f) * 0.8f;
                float fall = Time.time * speed * drift * s + i * 97f;
                float y = Mathf.Repeat(fall, Screen.height + 20f * s) - 10f * s;
                float x = Mathf.Repeat(lane * Screen.width + Mathf.Sin(fall / (14f * s) + i) * 8f * s - fall * 0.15f, Screen.width);
                float size = (season == Season.Winter ? 1f + (i % 3 == 0 ? 1f : 0f) : 2f) * s;
                Color c = season == Season.Winter ? new Color(1f, 1f, 1f, 0.85f)
                    : season == Season.Fall ? (i % 3 == 0 ? new Color(0.85f, 0.35f, 0.15f) : new Color(0.95f, 0.65f, 0.2f))
                    : new Color(1f, 0.8f, 0.88f, 0.9f);
                Fill(new Rect(x, y, size, season == Season.Winter ? size : size * 0.6f), c);
            }
        }

        static void Sell(ItemDef item, int count, int price)
        {
            int sold = Inventory.Remove(item, count);
            PlayerStats.Gold += sold * price;
        }

        void DrawPopup(int s)
        {
            float w = Mathf.Min(Screen.width - 16 * s, 170 * s), h = 78 * s;
            var box = new Rect((Screen.width - w) / 2f, (Screen.height - h) / 2f - 16 * s, w, h);
            Fill(new Rect(box.x - s, box.y - s, box.width + 2 * s, box.height + 2 * s), new Color32(0x2b, 0x1d, 0x1a, 0xff));
            Fill(box, new Color32(0xf4, 0xe9, 0xd0, 0xf8));

            // Icon, big, with a little bounce.
            float bounce = Mathf.Abs(Mathf.Sin((Time.time - _popupOpened) * 4f)) * 2f * s;
            DrawSprite(_popupIcon, new Rect(box.center.x - 16 * s, box.y + 6 * s - bounce, 32 * s, 32 * s));

            var title = new GUIStyle(_text) { alignment = TextAnchor.UpperCenter };
            title.normal.textColor = new Color32(0xa8, 0x40, 0x2f, 0xff);
            GUI.Label(new Rect(box.x, box.y + 40 * s, w, 10 * s), _popupTitle, title);

            var body = new GUIStyle(_text) { alignment = TextAnchor.UpperCenter, fontStyle = FontStyle.Normal, fontSize = 5 * s };
            body.normal.textColor = new Color32(0x2b, 0x1d, 0x1a, 0xff);
            GUI.Label(new Rect(box.x + 6 * s, box.y + 52 * s, w - 12 * s, 20 * s), _popupBody, body);
        }

        void DrawDialogue(int s)
        {
            float w = Mathf.Min(Screen.width - 16 * s, 240 * s);
            float h = 44 * s;
            var box = new Rect((Screen.width - w) / 2f, Screen.height - h - 6 * s, w, h);

            Fill(new Rect(box.x - s, box.y - s, box.width + 2 * s, box.height + 2 * s), new Color32(0x2b, 0x1d, 0x1a, 0xff));
            Fill(box, new Color32(0xf4, 0xe9, 0xd0, 0xf5));

            float inner = 6 * s;
            var nameStyle = new GUIStyle(_text);
            nameStyle.normal.textColor = new Color32(0xa8, 0x40, 0x2f, 0xff);
            GUI.Label(new Rect(box.x + inner, box.y + inner * 0.6f, box.width, 10 * s), _speakerName, nameStyle);
            var friend = Friendship.Get(_speakerName);
            if (friend != null)
            {
                float hx = box.x + inner + nameStyle.CalcSize(new GUIContent(_speakerName)).x + 4 * s;
                for (int i = 0; i < Friendship.MaxHearts; i++)
                    DrawSprite(i < friend.Hearts ? _heartFull : _heartEmpty, new Rect(hx + i * 7 * s, box.y + inner * 0.6f + 2 * s, 6 * s, 5.3f * s));
            }

            string line = _lines[_lineIndex];
            int shown = Mathf.Clamp(VisibleChars(), 0, line.Length);
            var body = new GUIStyle(_text);
            body.normal.textColor = new Color32(0x2b, 0x1d, 0x1a, 0xff);
            body.fontStyle = FontStyle.Normal;
            GUI.Label(new Rect(box.x + inner, box.y + inner + 8 * s, box.width - inner * 2, box.height - 18 * s), line.Substring(0, shown), body);

            if (shown >= line.Length)
            {
                var hint = new GUIStyle(body) { alignment = TextAnchor.LowerRight, fontSize = 5 * s };
                bool last = _lineIndex == _lines.Length - 1;
                GUI.Label(new Rect(box.x, box.y, box.width - inner, box.height - inner * 0.5f), last ? "E  close" : "E  more", hint);
            }
        }

        void ShadowLabel(Rect r, string text, Color color, GUIStyle style)
        {
            var old = style.normal.textColor;
            style.normal.textColor = new Color(0f, 0f, 0f, 0.8f);
            GUI.Label(new Rect(r.x + 2, r.y + 2, r.width, r.height), text, style);
            style.normal.textColor = color;
            GUI.Label(r, text, style);
            style.normal.textColor = old;
        }

        void ShadowLabel(Rect r, string text, Color color)
        {
            var old = _text.normal.textColor;
            _text.normal.textColor = new Color(0f, 0f, 0f, 0.8f);
            GUI.Label(new Rect(r.x + 2, r.y + 2, r.width, r.height), text, _text);
            _text.normal.textColor = color;
            GUI.Label(r, text, _text);
            _text.normal.textColor = old;
        }

        void Fill(Rect r, Color c)
        {
            var old = GUI.color;
            GUI.color = c;
            GUI.DrawTexture(r, _white);
            GUI.color = old;
        }

        static void DrawSprite(Sprite sprite, Rect r)
        {
            if (sprite == null) return;
            var tex = sprite.texture;
            Rect t = sprite.textureRect;
            GUI.DrawTextureWithTexCoords(r, tex, new Rect(t.x / tex.width, t.y / tex.height, t.width / tex.width, t.height / tex.height));
        }
    }
}
