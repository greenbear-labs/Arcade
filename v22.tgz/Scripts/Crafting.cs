using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>Tool upgrades made at the workbench. Each starts at 0 (the basic tool). Kept in the save.</summary>
    public static class Upgrades
    {
        /// <summary>Copper can: holds twice the water and waters three tiles at once.</summary>
        public static int Can;
        /// <summary>Iron hoe: digs three tiles at once.</summary>
        public static int Hoe;
        /// <summary>Steel pickaxe: every rock breaks in one hit.</summary>
        public static int Pickaxe;
        /// <summary>Gem sword: hits twice as hard.</summary>
        public static int Sword;

        public static void Reset() => Can = Hoe = Pickaxe = Sword = 0;
    }

    /// <summary>One thing the workbench can make: what it costs and what it does.</summary>
    public class Recipe
    {
        public string Name, Text;
        public ItemDef Icon;
        public (ItemDef item, int count)[] Needs;
        public int Gold;
        /// <summary>The item you get, or null for a tool upgrade.</summary>
        public ItemDef Makes;
        /// <summary>For an upgrade: true once you have it. Null for things you can make again and again.</summary>
        public System.Func<bool> Owned;
        public System.Action Apply;
        /// <summary>Optional: what the window says instead of "You have this" (a job underway, say).</summary>
        public System.Func<string> OwnedLabel;
        /// <summary>The button's word, and what to tell the player once it's done (null: "You made a ...").</summary>
        public string Verb = "Make", Done;

        public string CostText
        {
            get
            {
                var parts = new List<string>();
                foreach (var (item, count) in Needs) parts.Add($"{count} {QuestBoard.Plural(item, count)}");
                if (Gold > 0) parts.Add($"{Gold}g");
                return string.Join(", ", parts);
            }
        }
    }

    /// <summary>
    /// The workbench by your house turns ore, gems and wood into sprinklers,
    /// bee houses and chests. Press E at it to open the crafting window.
    /// (Ingrid the blacksmith does tool upgrades now: see Smithing.)
    /// </summary>
    public static class Crafting
    {
        public static readonly Recipe[] All =
        {
            new Recipe
            {
                Name = "Sprinkler", Icon = Items.Sprinkler, Makes = Items.Sprinkler,
                Text = "Place it in your field. Waters the 8 tiles around it every morning.",
                Needs = new[] { (Items.CopperOre, 2), (Items.IronOre, 1) },
            },
            new Recipe
            {
                Name = "Bee House", Icon = Items.BeeHouse, Makes = Items.BeeHouse,
                Text = "Set it down on grass. The bees make honey.",
                Needs = new[] { (Items.CopperOre, 3) }, Gold = 50,
            },
            new Recipe
            {
                Name = "Chest", Icon = Items.Chest, Makes = Items.Chest,
                Text = "Set it down on grass. Holds 16 stacks.",
                Needs = new[] { (Items.Wood, 10) },
            },
        };

        public static bool Has(Recipe r)
        {
            if (PlayerStats.Gold < r.Gold) return false;
            foreach (var (item, count) in r.Needs) if (Inventory.Count(item) < count) return false;
            return true;
        }

        /// <summary>Make it if you can. Returns what to tell the player.</summary>
        public static string Make(Recipe r)
        {
            if (r.Owned != null && r.Owned()) return $"You already have the {r.Name.ToLower()}.";
            if (!Has(r)) return "You need " + r.CostText + ".";
            if (r.Makes != null && !Inventory.HasRoomFor(r.Makes)) return "Your bag is full!";
            foreach (var (item, count) in r.Needs) Inventory.Remove(item, count);
            PlayerStats.Gold -= r.Gold;
            if (r.Makes != null) Inventory.Add(r.Makes);
            r.Apply?.Invoke();
            if (r.Done != null) return r.Done;
            return r.Makes != null ? $"You made a {r.Name.ToLower()}!" : $"Your {r.Name.ToLower()} is ready!";
        }
    }

    /// <summary>Ingrid's forge in town: ore and gems from the mine, plus her fee, make your tools better.</summary>
    public static class Smithing
    {
        public static readonly Recipe[] All =
        {
            new Recipe
            {
                Name = "Copper Watering Can", Icon = Items.WateringCan,
                Text = "Holds twice the water and waters 3 tiles at once.",
                Needs = new[] { (Items.CopperOre, 5) }, Gold = 100,
                Owned = () => Upgrades.Can >= 1,
                Apply = () => { Upgrades.Can = 1; Inventory.Water = Inventory.WaterMax; },
            },
            new Recipe
            {
                Name = "Iron Hoe", Icon = Items.Hoe,
                Text = "Digs 3 tiles of grass at once.",
                Needs = new[] { (Items.IronOre, 4) }, Gold = 200,
                Owned = () => Upgrades.Hoe >= 1,
                Apply = () => Upgrades.Hoe = 1,
            },
            new Recipe
            {
                Name = "Steel Pickaxe", Icon = Items.Pickaxe,
                Text = "Breaks any rock in one hit.",
                Needs = new[] { (Items.IronOre, 3), (Items.Gem, 1) },
                Owned = () => Upgrades.Pickaxe >= 1,
                Apply = () => Upgrades.Pickaxe = 1,
            },
            new Recipe
            {
                Name = "Gem Sword", Icon = Items.GemSword,
                Text = "Your sword hits twice as hard.",
                Needs = new[] { (Items.IronOre, 2), (Items.Gem, 2) },
                Owned = () => Upgrades.Sword >= 1,
                Apply = () => Upgrades.Sword = 1,
            },
        };
    }

    /// <summary>Sprinklers you've placed in the field. Each morning they water the tiles around them.</summary>
    public static class Sprinklers
    {
        static readonly Dictionary<Vector2Int, GameObject> Placed = new Dictionary<Vector2Int, GameObject>();

        public static IEnumerable<Vector2Int> Cells => Placed.Keys;
        public static bool Has(Vector2Int cell) => Placed.ContainsKey(cell);

        public static void Reset() => Placed.Clear();

        public static void Place(Vector2Int cell, Transform parent)
        {
            if (Placed.ContainsKey(cell)) return;
            var go = new GameObject("Sprinkler");
            go.transform.SetParent(parent, false);
            go.transform.position = new Vector3(cell.x + 0.5f, cell.y + 0.05f, 0f);
            go.AddComponent<SpriteRenderer>().sprite = Art.Strip("items", 16, 16, new Vector2(0.5f, 0f))?[Items.Sprinkler.IconIndex];
            go.AddComponent<YSort>();
            Placed[cell] = go;
        }

        public static void Remove(Vector2Int cell)
        {
            if (!Placed.TryGetValue(cell, out var go)) return;
            if (go != null) Object.Destroy(go);
            Placed.Remove(cell);
        }
    }

    /// <summary>The workbench itself, next to the farmhouse.</summary>
    public class Workbench : MonoBehaviour
    {
        public static readonly Vector2 Spot = new Vector2(17.0f, 19.4f);
        SpriteRenderer _prompt;

        public void Build(Transform parent)
        {
            var bench = new GameObject("Workbench");
            bench.transform.SetParent(parent, false);
            bench.transform.position = Spot;
            bench.AddComponent<SpriteRenderer>().sprite = Art.Single("workbench");
            bench.AddComponent<YSort>();
            var box = bench.AddComponent<BoxCollider2D>();
            box.size = new Vector2(1.8f, 0.4f);
            box.offset = new Vector2(0f, 0.2f);

            _prompt = new GameObject("Prompt").AddComponent<SpriteRenderer>();
            _prompt.transform.SetParent(bench.transform, false);
            _prompt.sprite = Art.Single("key_e", new Vector2(0.5f, 0f));
            _prompt.sortingOrder = 32000;
            _prompt.enabled = false;
        }

        void Update()
        {
            _prompt.enabled = false;
            var player = PlayerController.Instance;
            if (player == null || Hud.Busy || player.Locked || Home.Inside || Mine.Inside || Cavern.Inside || Town.Inside) return;
            Vector2 feet = player.transform.position;
            if (Vector2.Distance(feet, Spot + new Vector2(0f, -0.5f)) > 1.2f || player.Facing != Facing.Up) return;

            float bob = Mathf.Sin(Time.time * 5f) > 0f ? 1f / FarmDemoConfig.PixelsPerUnit : 0f;
            _prompt.enabled = true;
            _prompt.transform.localPosition = new Vector3(0f, 2.1f + bob, 0f);
            Hud.SetPrompt("E  Use the workbench");
            if (GameInput.TalkPressed()) Hud.OpenCrafting();
        }
    }
}
