using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Tilemaps;

namespace FarmDemo
{
    /// <summary>
    /// Builds the whole demo in code when you press Play: a tilemap farm with a
    /// path, a pond and a field, trees and rocks, breakable pots, slimes, four
    /// villagers (one runs a shop), a chicken coop, a day clock with seasons that
    /// repaint the farm, an animated player the camera follows, and the HUD.
    /// Nothing has to be set up by hand.
    ///
    /// It starts itself in any scene that is still empty (only a camera / light),
    /// and never touches a scene you've built yourself. You can also add this
    /// component to a GameObject to build the demo on purpose.
    /// </summary>
    public class FarmDemoWorld : MonoBehaviour
    {
        enum Ground { Grass, Path, Soil, Water }

        public const int ShadowOrder = -29000;
        const int GroundOrder = -30000;

        Ground[,] _ground;
        static FarmDemoWorld _current;

        /// <summary>Is this world position on a pond tile?</summary>
        public static bool IsWater(Vector2 world)
        {
            if (_current == null || _current._ground == null) return false;
            return _current.IsWater(Mathf.FloorToInt(world.x), Mathf.FloorToInt(world.y));
        }

        /// <summary>Is this tile part of the tilled field?</summary>
        public static bool IsSoil(Vector2Int cell)
        {
            if (_current == null || _current._ground == null) return false;
            var g = _current._ground;
            return cell.x >= 0 && cell.y >= 0 && cell.x < g.GetLength(0) && cell.y < g.GetLength(1) && g[cell.x, cell.y] == Ground.Soil;
        }

        /// <summary>Can the hoe dig here? Open grass inside the map, with nothing standing on it.</summary>
        public static bool CanTill(Vector2Int cell)
        {
            if (_current == null || _current._ground == null) return false;
            var g = _current._ground;
            if (cell.x < 3 || cell.y < 2 || cell.x >= g.GetLength(0) - 3 || cell.y >= g.GetLength(1) - 3) return false;
            if (g[cell.x, cell.y] != Ground.Grass || Animals.Covers(cell) || Barn.Covers(cell)) return false;
            foreach (var col in Physics2D.OverlapBoxAll(new Vector2(cell.x + 0.5f, cell.y + 0.5f), new Vector2(0.8f, 0.8f), 0f))
            {
                if (col.isTrigger) continue;
                if (PlayerController.Instance != null && col.attachedRigidbody != null &&
                    col.attachedRigidbody.gameObject == PlayerController.Instance.gameObject) continue;
                return false;   // a tree, rock, pot, villager or slime is in the way
            }
            return true;
        }

        /// <summary>Has Grandpa handed over the turnip seeds yet? (Kept in the save.)</summary>
        public static bool GrandpaGaveSeeds
        {
            get => _current != null && _current._grandpaGaveSeeds;
            set { if (_current != null) _current._grandpaGaveSeeds = value; }
        }

        /// <summary>Every soil tile, the starting field and anything you've dug since.</summary>
        public static List<Vector2Int> SoilCells()
        {
            var cells = new List<Vector2Int>();
            if (_current == null || _current._ground == null) return cells;
            var g = _current._ground;
            for (int x = 0; x < g.GetLength(0); x++)
            for (int y = 0; y < g.GetLength(1); y++)
                if (g[x, y] == Ground.Soil) cells.Add(new Vector2Int(x, y));
            return cells;
        }

        /// <summary>Make a grass tile soil without the hoe's checks (loading a save).</summary>
        public static void SetSoil(Vector2Int cell)
        {
            if (_current == null || _current._ground == null) return;
            var g = _current._ground;
            if (cell.x < 0 || cell.y < 0 || cell.x >= g.GetLength(0) || cell.y >= g.GetLength(1) || g[cell.x, cell.y] != Ground.Grass) return;
            g[cell.x, cell.y] = Ground.Soil;
            _current._groundMap.SetTile(new Vector3Int(cell.x, cell.y, 0), _current._soilTile);
        }

        /// <summary>Turn a grass tile into farm soil.</summary>
        public static void Till(Vector2Int cell)
        {
            if (!CanTill(cell)) return;
            _current._ground[cell.x, cell.y] = Ground.Soil;
            _current._groundMap.SetTile(new Vector3Int(cell.x, cell.y, 0), _current._soilTile);
        }

        Tilemap _groundMap, _waterMap;
        Tile _soilTile;
        Tile[] _tiles;
        // Trees and bushes, repainted when the season changes.
        readonly List<(SpriteRenderer renderer, string art)> _foliage = new List<(SpriteRenderer, string)>();
        Season _shownSeason;
        bool _grandpaGaveSeeds;
        readonly List<(Vector2 spot, GameObject pot)> _pots = new List<(Vector2, GameObject)>();
        Sprite _potSprite, _potBrokenSprite;
        Transform _potParent;
        readonly HashSet<Vector2Int> _blocked = new HashSet<Vector2Int>();
        System.Random _rng;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void AutoStartOnce()
        {
            AutoStart();
            // "Start a new farm" reloads the scene; build the farm again when it does.
            SceneManager.sceneLoaded += (scene, mode) => AutoStart();
        }

        static void AutoStart()
        {
            if (FindAnyObjectByTypeCompat<FarmDemoWorld>() != null) return;
            if (!SceneIsEmpty()) return;
            new GameObject("Farm Demo").AddComponent<FarmDemoWorld>();
        }

        void Awake()
        {
            _current = this;
            _rng = new System.Random(42);
            PlayerStats.Reset();
            Upgrades.Reset();
            Sprinklers.Reset();
            Inventory.Reset();
            GameClock.ResetClock();
            Sprite[] tiles = LoadTiles();
            Sprite[][] farmer = Art.Directional(FarmDemoConfig.CharacterSheet,
                FarmDemoConfig.CharacterFrameWidth, FarmDemoConfig.CharacterFrameHeight);
            if (tiles == null || farmer == null) return;

            gameObject.AddComponent<GameClock>();
            gameObject.AddComponent<TouchControls>();
            GameClock.NewDay += RespawnPots;
            GameClock.NewDay += ShowSeason;
            BuildGround(tiles);
            BuildBorder();
            PlacePots();
            PlaceNpcs();
            PlaceHouse();
            PlaceCoop();
            PlaceBarn();
            PlaceMine();          // before the quest board, which asks the mine how deep you've been
            PlaceQuestBoard();
            PlaceWorkbench();
            PlaceKitchen();
            PlaceSlimes();
            ScatterProps();
            Transform player = BuildPlayer(farmer, new Vector2(24f, 12f));
            SetUpCamera(player);
            new GameObject("HUD").AddComponent<Hud>().transform.SetParent(transform, false);
            gameObject.AddComponent<SaveGame>();

            if (SaveGame.Load())
                Hud.Toast($"Welcome back! It's {Seasons.DateText}.", 4f);
            else
            {
                // A new farm: you start with your tools.
                Inventory.Add(Items.Hoe);
                Inventory.Add(Items.WateringCan);
                Hud.Toast("Your hoe and watering can are on the item bar. Press 1 or 2 to pick one.", 5f);
            }
            _shownSeason = Season.Spring;
            ShowSeason();
        }

        // ------------------------------------------------------------- seasons

        /// <summary>Repaint the grass, trees and bushes if the season has changed.</summary>
        void ShowSeason()
        {
            var season = Seasons.Current;
            if (season == _shownSeason || _tiles == null) return;
            _shownSeason = season;

            int size = FarmDemoConfig.TileSize;
            var sheet = season == Season.Spring
                ? Art.PaddedSheet(FarmDemoConfig.Tileset, size, size, new Vector2(0.5f, 0.5f))
                : Art.PaddedSheet(FarmDemoConfig.Tileset, size, size, new Vector2(0.5f, 0.5f), season.ToString(),
                    c => Seasons.Recolor(c, season, false));
            if (sheet == null) return;
            int i = 0;
            foreach (var row in sheet)
            foreach (var sprite in row)
                if (i < _tiles.Length) _tiles[i++].sprite = sprite;
            _groundMap.RefreshAllTiles();
            _waterMap.RefreshAllTiles();

            foreach (var (renderer, art) in _foliage)
                if (renderer != null) renderer.sprite = Seasons.Prop(art, season);
        }

        // ------------------------------------------------------------- loading

        static Sprite[] LoadTiles()
        {
            int size = FarmDemoConfig.TileSize;
            var sheet = Art.PaddedSheet(FarmDemoConfig.Tileset, size, size, new Vector2(0.5f, 0.5f));
            if (sheet == null) return null;
            var flat = new List<Sprite>();
            foreach (var row in sheet) flat.AddRange(row);
            return flat.ToArray();
        }

        static Sprite LoadProp(string name) => Art.Single(name);

        // ------------------------------------------------------------- world

        void BuildGround(Sprite[] tileSprites)
        {
            int W = FarmDemoConfig.MapWidth, H = FarmDemoConfig.MapHeight;
            _ground = new Ground[W, H];

            Vector2 pond = new Vector2(36f, 23.5f);
            for (int x = 0; x < W; x++)
            for (int y = 0; y < H; y++)
            {
                float px = (x + 0.5f - pond.x) / 6.5f, py = (y + 0.5f - pond.y) / 4.5f;
                if (px * px + py * py <= 1f) _ground[x, y] = Ground.Water;
                else if (x >= 6 && x <= 15 && y >= 18 && y <= 25) _ground[x, y] = Ground.Soil;
                else if ((y == 11 || y == 12) && x >= 2 && x <= W - 3) _ground[x, y] = Ground.Path;
                else if ((x == 23 || x == 24) && y >= 2 && y <= H - 3) _ground[x, y] = Ground.Path;
                else if (x >= 10 && x <= 11 && y >= 13 && y <= 17) _ground[x, y] = Ground.Path; // to the field
                else if (x >= 19 && x <= 20 && y >= 13 && y <= 18) _ground[x, y] = Ground.Path; // to the house
            }

            var tiles = _tiles = new Tile[tileSprites.Length];
            for (int i = 0; i < tiles.Length; i++)
            {
                tiles[i] = ScriptableObject.CreateInstance<Tile>();
                tiles[i].sprite = tileSprites[i];
                tiles[i].colliderType = Tile.ColliderType.None;
            }
            for (int m = 0; m < 16; m++) tiles[FarmDemoConfig.TileWaterBase + m].colliderType = Tile.ColliderType.Grid;

            var grid = new GameObject("Grid", typeof(Grid));
            grid.transform.SetParent(transform, false);
            Tilemap ground = NewTilemap(grid.transform, "Ground", GroundOrder);
            Tilemap water = NewTilemap(grid.transform, "Water (solid)", GroundOrder + 1);
            water.gameObject.AddComponent<TilemapCollider2D>();
            _groundMap = ground;
            _waterMap = water;
            _soilTile = tiles[FarmDemoConfig.TileSoil];

            for (int x = 0; x < W; x++)
            for (int y = 0; y < H; y++)
            {
                var cell = new Vector3Int(x, y, 0);
                switch (_ground[x, y])
                {
                    case Ground.Water: water.SetTile(cell, tiles[FarmDemoConfig.TileWaterBase + WaterMask(x, y)]); break;
                    case Ground.Soil: ground.SetTile(cell, tiles[FarmDemoConfig.TileSoil]); break;
                    case Ground.Path: ground.SetTile(cell, tiles[FarmDemoConfig.TilePath]); break;
                    default: ground.SetTile(cell, tiles[PickGrass()]); break;
                }
            }
        }

        static Tilemap NewTilemap(Transform parent, string name, int order)
        {
            var go = new GameObject(name, typeof(Tilemap), typeof(TilemapRenderer));
            go.transform.SetParent(parent, false);
            go.GetComponent<TilemapRenderer>().sortingOrder = order;
            return go.GetComponent<Tilemap>();
        }

        int WaterMask(int x, int y)
        {
            int mask = 0;
            if (!IsWater(x, y + 1)) mask |= 1;
            if (!IsWater(x + 1, y)) mask |= 2;
            if (!IsWater(x, y - 1)) mask |= 4;
            if (!IsWater(x - 1, y)) mask |= 8;
            return mask;
        }

        bool IsWater(int x, int y) =>
            x >= 0 && y >= 0 && x < _ground.GetLength(0) && y < _ground.GetLength(1) && _ground[x, y] == Ground.Water;

        int PickGrass()
        {
            int r = _rng.Next(100);
            if (r < 45) return FarmDemoConfig.TileGrassA;
            if (r < 75) return FarmDemoConfig.TileGrassB;
            if (r < 85) return FarmDemoConfig.TileGrassC;
            if (r < 95) return FarmDemoConfig.TileGrassD;
            return r < 98 ? FarmDemoConfig.TileFlowersWhite : FarmDemoConfig.TileFlowersPink;
        }

        void BuildBorder()
        {
            int W = FarmDemoConfig.MapWidth, H = FarmDemoConfig.MapHeight;
            var tree = LoadProp("tree");
            var parent = new GameObject("Border").transform;
            parent.SetParent(transform, false);

            // A ring of trees for looks...
            for (int x = 1; x < W; x += 2)
            {
                Foliage(PlaceProp(parent, tree, new Vector2(x, 0f), new Vector2(0.5f, 0.3f)), "tree");
                Foliage(PlaceProp(parent, tree, new Vector2(x, H - 2f), new Vector2(0.5f, 0.3f)), "tree");
            }
            for (int y = 2; y < H - 2; y += 2)
            {
                Foliage(PlaceProp(parent, tree, new Vector2(1f, y), new Vector2(0.5f, 0.3f)), "tree");
                Foliage(PlaceProp(parent, tree, new Vector2(W - 1f, y), new Vector2(0.5f, 0.3f)), "tree");
            }

            // ...and invisible walls so nothing can leave the map.
            AddWall(parent, new Vector2(W / 2f, 0.1f), new Vector2(W + 2f, 2.2f));
            AddWall(parent, new Vector2(W / 2f, H - 1.5f), new Vector2(W + 2f, 1f));
            AddWall(parent, new Vector2(1f, H / 2f), new Vector2(1f, H + 2f));
            AddWall(parent, new Vector2(W - 1f, H / 2f), new Vector2(1f, H + 2f));
        }

        static void AddWall(Transform parent, Vector2 center, Vector2 size)
        {
            var go = new GameObject("Wall");
            go.transform.SetParent(parent, false);
            go.transform.position = center;
            go.AddComponent<BoxCollider2D>().size = size;
        }

        void ScatterProps()
        {
            var props = new[] { ("tree", new Vector2(0.5f, 0.3f), 2),
                                ("rock", new Vector2(0.8f, 0.45f), 1),
                                ("bush", new Vector2(0.8f, 0.45f), 1) };
            var parent = new GameObject("Props").transform;
            parent.SetParent(transform, false);

            int W = FarmDemoConfig.MapWidth, H = FarmDemoConfig.MapHeight;
            var spawn = new Vector2Int(24, 12);
            for (int attempt = 0, placed = 0; attempt < 400 && placed < 45; attempt++)
            {
                int x = _rng.Next(3, W - 3), y = _rng.Next(2, H - 4);
                var (art, collider, radius) = props[_rng.Next(10) < 5 ? 0 : _rng.Next(1, 3)];
                if (Mathf.Abs(x - spawn.x) < 4 && Mathf.Abs(y - spawn.y) < 4) continue;
                if (!AreaIsOpenGrass(x, y, radius)) continue;

                var prop = PlaceProp(parent, LoadProp(art), new Vector2(x + 0.5f, y + 0.1f), collider);
                if (art != "rock") Foliage(prop, art);
                for (int dx = -radius; dx <= radius; dx++)
                for (int dy = -radius; dy <= radius; dy++)
                    _blocked.Add(new Vector2Int(x + dx, y + dy));
                placed++;
            }
        }

        bool AreaIsOpenGrass(int x, int y, int radius)
        {
            for (int dx = -radius; dx <= radius; dx++)
            for (int dy = -radius; dy <= radius + 1; dy++)
            {
                int cx = x + dx, cy = y + dy;
                if (cx < 0 || cy < 0 || cx >= _ground.GetLength(0) || cy >= _ground.GetLength(1)) return false;
                if (_ground[cx, cy] != Ground.Grass || _blocked.Contains(new Vector2Int(cx, cy))) return false;
            }
            return true;
        }

        void Foliage(SpriteRenderer renderer, string art)
        {
            if (renderer != null) _foliage.Add((renderer, art));
        }

        static SpriteRenderer PlaceProp(Transform parent, Sprite sprite, Vector2 position, Vector2 colliderSize)
        {
            if (sprite == null) return null;
            var go = new GameObject(sprite.texture.name);
            go.transform.SetParent(parent, false);
            go.transform.position = position;
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            go.AddComponent<YSort>();
            var box = go.AddComponent<BoxCollider2D>(); // only the base is solid, so you can walk "behind" the top
            box.size = colliderSize;
            box.offset = new Vector2(0f, colliderSize.y * 0.5f);
            return sr;
        }

        // ------------------------------------------------------------- pots, villagers, slimes

        void PlacePots()
        {
            _potSprite = LoadProp("pot");
            _potBrokenSprite = LoadProp("pot_broken");
            _potParent = new GameObject("Pots").transform;
            _potParent.SetParent(transform, false);

            // A cluster by Grandpa, a couple by the crossroads, a few more by the field and pond.
            Vector2[] spots =
            {
                new Vector2(14.5f, 14.2f), new Vector2(15.5f, 14.2f), new Vector2(15.0f, 15.1f),
                new Vector2(27.5f, 9.3f), new Vector2(28.5f, 9.3f),
                new Vector2(16.5f, 17.2f), new Vector2(26.5f, 9.3f), new Vector2(43.5f, 15.2f),
            };
            foreach (var spot in spots)
            {
                _pots.Add((spot, SpawnPot(spot)));
                Reserve(spot, 1);
            }
        }

        GameObject SpawnPot(Vector2 spot)
        {
            var go = new GameObject("Pot");
            go.transform.SetParent(_potParent, false);
            go.transform.position = spot;
            go.AddComponent<SpriteRenderer>().sprite = _potSprite;
            go.AddComponent<YSort>();
            var box = go.AddComponent<BoxCollider2D>();
            box.size = new Vector2(0.7f, 0.45f);
            box.offset = new Vector2(0f, 0.22f);
            go.AddComponent<Pot>().brokenSprite = _potBrokenSprite;
            return go;
        }

        // Smashed pots are back every morning. (Someone in this village really likes pots.)
        void RespawnPots()
        {
            for (int i = 0; i < _pots.Count; i++)
                if (_pots[i].pot == null) _pots[i] = (_pots[i].spot, SpawnPot(_pots[i].spot));
        }

        void OnDestroy()
        {
            GameClock.NewDay -= RespawnPots;
            GameClock.NewDay -= ShowSeason;
        }

        void PlaceNpcs()
        {
            var prompt = Art.Single("key_e", new Vector2(0.5f, 0f));
            var parent = new GameObject("Villagers").transform;
            parent.SetParent(transform, false);

            // What each villager likes to be given, and their thank-you at five hearts.
            Friendship.Reset();
            Friendship.Add("Grandpa Turnip", new[] { Items.Turnip, Items.Pumpkin, Items.TurnipSoup, Items.Cheese }, new[] { Items.Strawberry, Items.Egg, Items.LargeEgg, Items.Tomato },
                new[] { Items.OldBoot, Items.Carp }, "Plant these come fall. Biggest pumpkins in the valley, I promise.", Items.PumpkinSeeds, 4);
            Friendship.Add("Mabel the Baker", new[] { Items.GoldenTrout, Items.LargeEgg, Items.Strawberry, Items.StrawberryJam }, new[] { Items.Egg, Items.Milk, Items.Pumpkin, Items.Tomato },
                new[] { Items.OldBoot }, "A little something from the bakery till. You've earned it, sweetie.", rewardGold: 300);
            Friendship.Add("Pip", new[] { Items.OldBoot, Items.Tomato, Items.FishStew }, new[] { Items.Bluegill, Items.Carp, Items.Egg },
                new[] { Items.Turnip }, "Found this in the trench coat. Don't ask which raccoon had it.", Items.GoldenTrout);
            Friendship.Add("Dot the Miner", new[] { Items.Gem, Items.Pumpkin, Items.PumpkinPie }, new[] { Items.Egg, Items.LargeEgg, Items.Tomato, Items.Carp },
                new[] { Items.Strawberry }, "Found these way down deep. Don't tell the others how far I go.", Items.Gem, 3);
            Friendship.Add("Old Gil", new[] { Items.GoldenTrout, Items.Carp, Items.FishStew, Items.GoatCheese }, new[] { Items.Bluegill, Items.Pumpkin },
                new[] { Items.OldBoot, Items.Strawberry }, "My prize money from the '72 fishing derby. Buy yourself a better hat.", rewardGold: 250);

            // Grandpa Turnip starts you off with some seeds.
            var grandpa = AddNpc(parent, "npc_grandpa", "Grandpa Turnip", new Vector2(12.5f, 15.6f), prompt, null);
            if (grandpa != null)
            {
                grandpa.SetScript(
                    () => _grandpaGaveSeeds
                        ? new[]
                        {
                            "Crops only grow on nights after you water them. Fill your can at the pond.",
                            "Want a bigger field? Pick your hoe and dig up some grass.",
                            "Your bed's in the house next door. Or stay up till 2 AM and pass out like I do.",
                            "That hen by your house lays an egg every morning, as long as her trough has feed. Pet her, too.",
                            "Turnips grow in spring and fall. Come winter, nothing grows at all.",
                            "There's a stove in your kitchen. Two turnips make a soup that'd warm a snowman. Pick food and press F to eat it.",
                            "I've been growing this beard since 1962. Still my best crop.",
                        }
                        : new[]
                        {
                            "Back in my day we didn't have slimes. We had regular jelly, and we were grateful.",
                            "That field up there is going to waste. Here, take some turnip seeds.",
                            "Pick them on your item bar, face the dirt, and press F. Then water them every day.",
                        },
                    () =>
                    {
                        if (_grandpaGaveSeeds) return;
                        if (!Inventory.Add(Items.TurnipSeeds, 5)) { Hud.Toast("Your bag is full!"); return; }
                        _grandpaGaveSeeds = true;
                        Inventory.Select(SlotOf(Items.TurnipSeeds));
                        Hud.ShowPopup(Items.TurnipSeeds.Icon, "You got 5 Turnip Seeds!",
                            "Face a dirt tile in the field and press F to plant. Water them, sleep, and they grow.");
                    });
            }

            // Mabel opens her shop once she's done chatting.
            var mabel = AddNpc(parent, "npc_mabel", "Mabel the Baker", new Vector2(32.5f, 16.6f), prompt, null);
            if (mabel != null)
            {
                string[][] chat =
                {
                    new[] { "I once sold a loaf of bread to a goose. He paid in exact change. I have questions." },
                    new[] { "Are you smashing pots for coins? ...They're not my pots. Carry on." },
                    new[] { "Strawberries take three nights, but they come in bunches. Worth it." },
                    new[] { "A Golden Trout! If you ever catch one, I'll pay a fortune. For a pie. Don't ask." },
                    new[] { "My seeds change with the seasons. Tomatoes in summer, pumpkins in fall." },
                    new[] { "Eggs! Bring me eggs. And if your coop has room, I've got hens for sale." },
                    new[] { "That old barn west of the crossroads is yours now. I sell cows and goats, and hay for the winter." },
                    new[] { "Milk is nice. Cheese is nicer. There's a cheese press out by the barn." },
                };
                int next = 0;
                mabel.SetScript(() => chat[next++ % chat.Length], Hud.OpenShop);
            }
            AddNpc(parent, "npc_pip", "Pip", new Vector2(17.5f, 6.6f), prompt, new[]
            {
                "Psst. Don't tell anyone, but I'm actually three raccoons in a trench coat.",
                "The hat is real though. The hat is very real.",
            });

            // Dot the Miner lends you a pickaxe for the mine.
            var dot = AddNpc(parent, "npc_miner", "Dot the Miner", new Vector2(20.6f, 26.4f), prompt, null);
            if (dot != null)
            {
                string[][] chat =
                {
                    new[] { "Every fifth floor, I'll remember how deep you got. Next time you can start from there." },
                    new[] { "See that workbench by your house? Bring it ore and gems and it'll make you sprinklers and better tools." },
                    new[] { "Copper's orange, iron's pinkish, and gems... you'll know a gem when you see one." },
                    new[] { "Feeling woozy down there? Pick some food and press F to eat it." },
                    new[] { "If you faint, I'll haul you out. Happens to the best of us." },
                    new[] { "The slimes get meaner the deeper you go. Green ones, blue ones... I don't talk about the red ones." },
                };
                int next = 0;
                dot.SetScript(
                    () => Inventory.Has(Items.Pickaxe)
                        ? chat[next++ % chat.Length]
                        : new[]
                        {
                            "Hiya! I'm Dot. I dig.",
                            "That cave goes down and down. Rocks, ore, gems... and slimes. Lots of slimes.",
                            "You look like you could swing a pickaxe. Here, take my spare!",
                        },
                    () =>
                    {
                        if (Inventory.Has(Items.Pickaxe)) return;
                        if (!Inventory.Add(Items.Pickaxe)) { Hud.Toast("Your bag is full!"); return; }
                        Inventory.Select(Inventory.SlotOf(Items.Pickaxe));
                        Hud.ShowPopup(Items.Pickaxe.Icon, "You got a Pickaxe!",
                            "Go into the cave, face a rock and press F to break it. One rock on every floor hides the ladder down.");
                    });
            }

            // Old Gil hands you his fishing rod the first time you chat.
            var gil = AddNpc(parent, "npc_fisher", "Old Gil", new Vector2(40.5f, 18.4f), prompt, null);
            if (gil != null)
            {
                gil.SetScript(
                    () => Inventory.Has(Items.FishingRod)
                        ? new[]
                        {
                            "Pick the rod on your item bar, face the water and press F. When you see the \"!\", press F again. Quick!",
                            "I once caught a fish so big, I had to let it go. Out of respect.",
                        }
                        : new[]
                        {
                            "Name's Gil. Been fishing this pond for forty years.",
                            "Caught mostly boots. Seven boots. None of them match.",
                            "My back's done for. Here, you take my old rod!",
                        },
                    () =>
                    {
                        if (Inventory.Has(Items.FishingRod)) return;
                        if (!Inventory.Add(Items.FishingRod)) { Hud.Toast("Your bag is full!"); return; }
                        Inventory.Select(Inventory.SlotOf(Items.FishingRod));
                        Hud.ShowPopup(Items.FishingRod.Icon, "You got a Fishing Rod!",
                            "Pick it on your item bar, face the pond and press F to cast. When the ! pops up, press F again.");
                    });
            }
        }

        static int SlotOf(ItemDef item)
        {
            for (int i = 0; i < Inventory.SlotCount; i++)
                if (Inventory.All[i] != null && Inventory.All[i].Item == item) return i;
            return Inventory.Selected;
        }

        Npc AddNpc(Transform parent, string sheet, string name, Vector2 position, Sprite prompt, string[] lines)
        {
            var frames = Art.Directional(sheet, FarmDemoConfig.CharacterFrameWidth, FarmDemoConfig.CharacterFrameHeight);
            if (frames == null) return null;

            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.position = position;
            AddShadow(go.transform, 1f);
            go.AddComponent<SpriteRenderer>();
            go.AddComponent<YSort>();
            var box = go.AddComponent<BoxCollider2D>();    // solid, so you bump into them
            box.size = new Vector2(0.6f, 0.3f);
            box.offset = new Vector2(0f, 0.15f);
            var npc = go.AddComponent<Npc>();
            npc.Init(name, lines, frames, prompt);
            Reserve(position, 1);
            return npc;
        }

        void PlaceHouse()
        {
            var home = new GameObject("Home").AddComponent<Home>();
            home.transform.SetParent(transform, false);
            home.Build(home.transform);
            Reserve(Home.DoorOutside + new Vector2(0f, 1.5f), 3);
        }

        void PlaceQuestBoard()
        {
            var board = new GameObject("Quests").AddComponent<QuestBoard>();
            board.transform.SetParent(transform, false);
            board.Build(board.transform);
            Reserve(QuestBoard.Spot, 1);
        }

        void PlaceWorkbench()
        {
            var bench = new GameObject("Crafting").AddComponent<Workbench>();
            bench.transform.SetParent(transform, false);
            bench.Build(bench.transform);
            Reserve(Workbench.Spot, 1);
        }

        void PlaceKitchen()
        {
            var kitchen = new GameObject("Kitchen").AddComponent<Kitchen>();
            kitchen.transform.SetParent(transform, false);
            kitchen.Build(kitchen.transform);
        }

        void PlaceMine()
        {
            var mine = new GameObject("Mine").AddComponent<Mine>();
            mine.transform.SetParent(transform, false);
            mine.Build(mine.transform);
            Reserve(Mine.Mouth + new Vector2(0f, 1f), 2);
        }

        void PlaceCoop()
        {
            var animals = new GameObject("Animals").AddComponent<Animals>();
            animals.transform.SetParent(transform, false);
            animals.Build(animals.transform);
            for (int x = 23; x <= 32; x++)
            for (int y = 12; y <= 23; y++)
                _blocked.Add(new Vector2Int(x, y));
        }

        void PlaceBarn()
        {
            var barn = new GameObject("Barn").AddComponent<Barn>();
            barn.transform.SetParent(transform, false);
            barn.Build(barn.transform);
            for (int x = 3; x <= 16; x++)
            for (int y = 2; y <= 10; y++)
                _blocked.Add(new Vector2Int(x, y));
        }

        void PlaceSlimes()
        {
            var frames = Art.Strip("slime", 16, 16);
            if (frames == null) return;
            var parent = new GameObject("Slimes").transform;
            parent.SetParent(transform, false);

            // They live in the south-east meadow, away from where you start.
            Vector2[] homes = { new Vector2(36.5f, 6.5f), new Vector2(41.5f, 9.5f), new Vector2(33.5f, 4.5f), new Vector2(42.5f, 4.5f) };
            foreach (var home in homes)
            {
                SpawnSlime(parent, home, frames);
                Reserve(home, 2);
            }
        }

        /// <summary>A slime that lives around this spot (the meadow ones, and the mine's).</summary>
        public static Slime SpawnSlime(Transform parent, Vector2 home, Sprite[] frames)
        {
            if (frames == null) return null;
            var root = new GameObject("Slime");
            root.transform.SetParent(parent, false);
            root.transform.position = home;
            var body = new GameObject("Sprite");   // first child: Slime looks for its sprite here
            body.transform.SetParent(root.transform, false);
            body.AddComponent<SpriteRenderer>().sprite = frames[0];
            body.AddComponent<YSort>().isStatic = false;
            AddShadow(root.transform, 1.1f);

            var rb = root.AddComponent<Rigidbody2D>();
            rb.gravityScale = 0f;
            rb.constraints = RigidbodyConstraints2D.FreezeRotation;
            rb.interpolation = RigidbodyInterpolation2D.Interpolate;
            var circle = root.AddComponent<CircleCollider2D>();
            circle.radius = 0.32f;
            circle.offset = new Vector2(0f, 0.3f);

            var slime = root.AddComponent<Slime>();
            slime.Init(frames);
            return slime;
        }

        /// <summary>Keeps randomly scattered trees and rocks away from this spot.</summary>
        void Reserve(Vector2 position, int radius)
        {
            int x = Mathf.FloorToInt(position.x), y = Mathf.FloorToInt(position.y);
            for (int dx = -radius; dx <= radius; dx++)
            for (int dy = -radius; dy <= radius + 1; dy++)
                _blocked.Add(new Vector2Int(x + dx, y + dy));
        }

        static void AddShadow(Transform parent, float scale)
        {
            var shadow = new GameObject("Shadow").AddComponent<SpriteRenderer>();
            shadow.transform.SetParent(parent, false);
            shadow.transform.localPosition = new Vector3(0f, -0.1f, 0f);
            shadow.transform.localScale = new Vector3(scale, scale, 1f);
            shadow.sprite = LoadProp("shadow");
            shadow.sortingOrder = ShadowOrder;
        }

        // ------------------------------------------------------------- player + camera

        Transform BuildPlayer(Sprite[][] frames, Vector2 position)
        {
            var root = new GameObject("Player");
            root.transform.position = position;

            AddShadow(root.transform, 1f);

            var body = new GameObject("Sprite");
            body.transform.SetParent(root.transform, false);
            body.AddComponent<SpriteRenderer>();
            body.AddComponent<SpriteSheetAnimator>().Init(frames);
            body.AddComponent<YSort>().isStatic = false;

            var rb = root.AddComponent<Rigidbody2D>();
            rb.gravityScale = 0f;
            rb.constraints = RigidbodyConstraints2D.FreezeRotation;
            rb.interpolation = RigidbodyInterpolation2D.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;

            var feet = root.AddComponent<CapsuleCollider2D>(); // round feet slide along corners nicely
            feet.direction = CapsuleDirection2D.Horizontal;
            feet.size = new Vector2(0.6f, 0.3f);
            feet.offset = new Vector2(0f, 0.15f);

            root.AddComponent<PlayerController>().Init(Art.Directional("farmer_attack", 32, 32));
            root.AddComponent<FishingController>().Init(Art.Directional("farmer_fish", 32, 32));
            root.AddComponent<FarmingController>();
            return root.transform;
        }

        static void SetUpCamera(Transform player)
        {
            var cam = Camera.main;
            if (cam == null)
            {
                cam = new GameObject("Main Camera", typeof(Camera)).GetComponent<Camera>();
                cam.tag = "MainCamera";
            }
            cam.orthographic = true;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color32(0x2f, 0x7d, 0x3a, 0xff);
            cam.transform.position = new Vector3(player.position.x, player.position.y, -10f);

            var follow = cam.GetComponent<CameraFollow>();
            if (follow == null) follow = cam.gameObject.AddComponent<CameraFollow>();
            follow.target = player;
            follow.bounds = new Rect(0f, 0f, FarmDemoConfig.MapWidth, FarmDemoConfig.MapHeight);
        }

        // ------------------------------------------------------------- helpers

        static bool SceneIsEmpty()
        {
            foreach (var root in SceneManager.GetActiveScene().GetRootGameObjects())
            {
                bool harmless = root.GetComponent<Camera>() != null || root.GetComponent<Light>() != null;
                foreach (var c in root.GetComponents<Component>())
                {
                    string n = c == null ? "" : c.GetType().Name;
                    if (n == "Light2D" || n == "Volume" || n == "EventSystem") harmless = true;
                }
                if (!harmless) return false;
            }
            return true;
        }

        static T FindAnyObjectByTypeCompat<T>() where T : Object
        {
#if UNITY_2023_1_OR_NEWER
            return FindAnyObjectByType<T>();
#else
            return FindObjectOfType<T>();
#endif
        }
    }
}
