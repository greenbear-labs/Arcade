using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    public enum BeastKind { Cow, Goat }

    /// <summary>
    /// The barn west of the crossroads, its fenced pasture, hay feeder and
    /// cheese press, and the cows and goats you buy from Mabel (up to four).
    /// They graze the pasture from spring to fall; in winter each one eats a
    /// hay from the feeder every morning. A fed cow has milk every morning and
    /// a goat every other morning: face one and press F to milk it, E to pet it.
    /// The cheese press turns milk into cheese, which sells for more.
    /// </summary>
    public class Barn : MonoBehaviour
    {
        public const int MaxBeasts = 4, FeederMax = 12;

        // The barn stands with its bottom centre here, inside the top left of the pasture.
        public static readonly Vector2 BarnSpot = new Vector2(7.5f, 6f);
        // Fence cells: x 4..15, y 3..9, with a gate in the top run that opens onto the path.
        const int FenceLeft = 4, FenceRight = 15, FenceBottom = 3, FenceTop = 9, GateX = 11;
        static readonly Rect Pasture = new Rect(5.5f, 3.6f, 8.9f, 4.8f);
        static readonly Rect BarnFootprint = new Rect(5.0f, 5.4f, 5.0f, 4.0f);
        static readonly Vector2 FeederSpot = new Vector2(13.6f, 8.0f);
        public static readonly Vector2 PressSpot = new Vector2(11.2f, 6.2f);
        static readonly Vector2 BarnDoor = BarnSpot + new Vector2(0f, 0.1f);

        static readonly string[] CowNames = { "Daisy", "Buttercup", "Moonpie", "Clover" };
        static readonly string[] GoatNames = { "Billy", "Pepper", "Nibbles", "Juniper" };

        static Barn _instance;
        readonly List<Beast> _beasts = new List<Beast>();
        Sprite[] _cowFrames, _goatFrames, _feederFrames;
        Sprite _heart;
        SpriteRenderer _feeder, _pressPrompt;

        /// <summary>Hay in the feeder: each animal eats one on winter mornings.</summary>
        public static int Hay { get; private set; }
        public static bool CanBuy => _instance != null && _instance._beasts.Count < MaxBeasts;
        public static bool HasAny => _instance != null && _instance._beasts.Count > 0;
        public static int Count(BeastKind kind)
        {
            int n = 0;
            if (_instance != null) foreach (var b in _instance._beasts) if (b.Kind == kind) n++;
            return n;
        }

        /// <summary>Is this tile part of the barn or its pasture? (The hoe leaves it alone.)</summary>
        public static bool Covers(Vector2Int cell) =>
            cell.x >= FenceLeft - 1 && cell.x <= FenceRight + 1 && cell.y >= FenceBottom - 1 && cell.y <= FenceTop + 1;

        public static void Export(List<SaveGame.BeastState> list)
        {
            if (_instance == null) return;
            foreach (var b in _instance._beasts)
                list.Add(new SaveGame.BeastState { name = b.Name, kind = (int)b.Kind, happiness = b.Happiness, ready = b.Ready, days = b.Days });
        }

        public static void Import(int hay, List<SaveGame.BeastState> list)
        {
            if (_instance == null) return;
            Hay = Mathf.Clamp(hay, 0, FeederMax);
            _instance.RefreshFeeder();
            foreach (var b in _instance._beasts) Destroy(b.gameObject);
            _instance._beasts.Clear();
            foreach (var s in list)
            {
                if (_instance._beasts.Count >= MaxBeasts) break;
                var b = _instance.Add((BeastKind)Mathf.Clamp(s.kind, 0, 1), s.name);
                b.Happiness = Mathf.Clamp(s.happiness, 0, 5);
                b.Ready = s.ready;
                b.Days = s.days;
            }
        }

        public static void Buy(BeastKind kind)
        {
            if (!CanBuy) return;
            _instance.Add(kind, null).JustArrived = true;     // first milk the morning after next
        }

        public void Build(Transform parent)
        {
            _instance = this;
            Hay = 0;
            _cowFrames = Art.Strip("cow", 24, 24, new Vector2(0.5f, 0f));
            _goatFrames = Art.Strip("goat", 24, 24, new Vector2(0.5f, 0f));
            _feederFrames = Art.Strip("feeder", 16, 16);
            _heart = Art.Strip("heart", 9, 8, new Vector2(0.5f, 0f))?[0];

            var barn = new GameObject("Barn");
            barn.transform.SetParent(parent, false);
            barn.transform.position = BarnSpot;
            barn.AddComponent<SpriteRenderer>().sprite = Art.Single("barn");
            barn.AddComponent<YSort>();
            var walls = barn.AddComponent<BoxCollider2D>();
            walls.size = new Vector2(3.6f, 1.8f);
            walls.offset = new Vector2(0f, 0.95f);

            var fence = Art.Strip("fence", 16, 16);
            var fenceParent = new GameObject("Pasture fence").transform;
            fenceParent.SetParent(parent, false);
            for (int x = FenceLeft; x <= FenceRight; x++)
            {
                Fence(fenceParent, fence?[0], x, FenceBottom, true);
                if (x != GateX && (x < 6 || x > 8)) Fence(fenceParent, fence?[0], x, FenceTop, true);   // the barn fills 6..8
            }
            for (int y = FenceBottom + 1; y < FenceTop; y++)
            {
                Fence(fenceParent, fence?[1], FenceLeft, y, false);
                Fence(fenceParent, fence?[1], FenceRight, y, false);
            }

            var feeder = new GameObject("Hay feeder");
            feeder.transform.SetParent(parent, false);
            feeder.transform.position = FeederSpot;
            _feeder = feeder.AddComponent<SpriteRenderer>();
            feeder.AddComponent<YSort>();
            var box = feeder.AddComponent<BoxCollider2D>();
            box.size = new Vector2(0.85f, 0.35f);
            box.offset = new Vector2(0f, 0.25f);
            RefreshFeeder();

            var press = new GameObject("Cheese press");
            press.transform.SetParent(parent, false);
            press.transform.position = PressSpot;
            press.AddComponent<SpriteRenderer>().sprite = Art.Single("cheese_press");
            press.AddComponent<YSort>();
            var pbox = press.AddComponent<BoxCollider2D>();
            pbox.size = new Vector2(0.85f, 0.35f);
            pbox.offset = new Vector2(0f, 0.2f);
            _pressPrompt = new GameObject("Prompt").AddComponent<SpriteRenderer>();
            _pressPrompt.transform.SetParent(press.transform, false);
            _pressPrompt.sprite = Art.Single("key_e", new Vector2(0.5f, 0f));
            _pressPrompt.sortingOrder = 32000;
            _pressPrompt.enabled = false;

            GameClock.NewDay += Morning;
        }

        static void Fence(Transform parent, Sprite sprite, int x, int y, bool across)
        {
            var go = new GameObject("Fence");
            go.transform.SetParent(parent, false);
            go.transform.position = new Vector2(x + 0.5f, y);
            go.AddComponent<SpriteRenderer>().sprite = sprite;
            go.AddComponent<YSort>();
            var box = go.AddComponent<BoxCollider2D>();
            box.size = across ? new Vector2(1f, 0.35f) : new Vector2(0.35f, 1f);
            box.offset = across ? new Vector2(0f, 0.2f) : new Vector2(0f, 0.5f);
        }

        Beast Add(BeastKind kind, string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                var names = kind == BeastKind.Cow ? CowNames : GoatNames;
                name = names[Count(kind) % names.Length];
            }
            var go = new GameObject(kind.ToString());
            go.transform.SetParent(transform, false);
            go.transform.position = WanderSpot();
            var shadow = new GameObject("Shadow").AddComponent<SpriteRenderer>();
            shadow.transform.SetParent(go.transform, false);
            shadow.transform.localPosition = new Vector3(0f, 0.05f, 0f);
            shadow.transform.localScale = kind == BeastKind.Cow ? new Vector3(1.6f, 1f, 1f) : new Vector3(1.3f, 0.9f, 1f);
            shadow.sprite = Art.Single("shadow");
            shadow.sortingOrder = FarmDemoWorld.ShadowOrder;
            go.AddComponent<SpriteRenderer>();
            go.AddComponent<YSort>().isStatic = false;
            var beast = go.AddComponent<Beast>();
            beast.Init(name, kind, kind == BeastKind.Cow ? _cowFrames : _goatFrames);
            _beasts.Add(beast);
            return beast;
        }

        /// <summary>A spot in the pasture to walk to, clear of the barn, feeder and press.</summary>
        public static Vector2 WanderSpot()
        {
            for (int i = 0; i < 10; i++)
            {
                var p = new Vector2(Random.Range(Pasture.xMin, Pasture.xMax), Random.Range(Pasture.yMin, Pasture.yMax));
                if (BarnFootprint.Contains(p) || Vector2.Distance(p, FeederSpot) < 1f || Vector2.Distance(p, PressSpot) < 1f) continue;
                return p;
            }
            return new Vector2(12.5f, 4.5f);
        }

        public static Vector2 Door => BarnDoor;

        void RefreshFeeder()
        {
            if (_feederFrames != null) _feeder.sprite = _feederFrames[Hay > 0 ? 1 : 0];
        }

        void OnDestroy()
        {
            GameClock.NewDay -= Morning;
            if (_instance == this) _instance = null;
        }

        // Each morning: out they come. Grass feeds them except in winter, when they need hay.
        void Morning()
        {
            bool winter = Seasons.Current == Season.Winter;
            int hungry = 0;
            foreach (var b in _beasts)
            {
                bool wasPetted = b.PettedToday;
                b.WakeUp(WanderSpot());
                if (b.JustArrived) { b.JustArrived = false; continue; }
                if (!wasPetted) b.Happiness = Mathf.Max(0, b.Happiness - 1);
                if (winter)
                {
                    if (Hay <= 0) { hungry++; continue; }
                    Hay--;
                }
                b.Days++;
                // Cows give milk every day; goats every other day, or every day once they really love you.
                if (b.Kind == BeastKind.Cow || b.Days % 2 == 0 || b.Happiness >= 5) b.Ready = true;
            }
            RefreshFeeder();
            if (hungry > 0) StartCoroutine(Later(4.5f, () => Hud.Toast(
                "There's no grass in winter. Put Hay from Mabel in the barn's feeder, or your animals won't give milk.", 4.5f)));
        }

        static IEnumerator Later(float seconds, System.Action action)
        {
            yield return new WaitForSeconds(seconds);
            action();
        }

        void Update()
        {
            _pressPrompt.enabled = false;
            var player = PlayerController.Instance;
            if (player == null || Hud.Busy || player.Locked || Home.Inside || Mine.Inside) return;
            Vector2 feet = player.transform.position;
            Vector2 ahead = feet + new Vector2(0f, 0.2f) + Art.Dir(player.Facing) * 0.6f;

            // The cheese press.
            if (Vector2.Distance(feet, PressSpot + new Vector2(0f, -0.5f)) < 0.9f && player.Facing == Facing.Up)
            {
                float bob = Mathf.Sin(Time.time * 5f) > 0f ? 1f / FarmDemoConfig.PixelsPerUnit : 0f;
                _pressPrompt.enabled = true;
                _pressPrompt.transform.localPosition = new Vector3(0f, 1.7f + bob, 0f);
                Hud.SetPrompt("E  Use the cheese press");
                if (GameInput.TalkPressed()) Hud.OpenBench("Cheese Press", Dairy.All);
                return;
            }

            // Cows and goats.
            Beast beast = null;
            float best = 1.1f;
            foreach (var b in _beasts)
            {
                if (b.Asleep) continue;
                float d = Vector2.Distance(ahead, (Vector2)b.transform.position + new Vector2(0f, 0.5f));
                if (d < best) { best = d; beast = b; }
            }
            if (beast != null)
            {
                bool pet = GameInput.TalkPressed(), milk = GameInput.FishPressed();
                if (beast.Ready)
                {
                    Hud.SetPrompt(beast.PettedToday ? $"F  Milk {beast.Name}" : $"F  Milk {beast.Name}     E  Pet");
                    if (milk)
                    {
                        var item = beast.Kind == BeastKind.Cow ? Items.Milk : Items.GoatMilk;
                        if (!Inventory.Add(item)) { Hud.Toast("Your bag is full! Sell something to Mabel first.", 2.5f); return; }
                        beast.Ready = false;
                        Hud.Toast($"+1 {item.Name}!", 1.5f);
                        return;
                    }
                }
                else if (beast.PettedToday)
                    Hud.SetPrompt(beast.Kind == BeastKind.Goat ? $"{beast.Name} is happy. Goats give milk every other day" : $"{beast.Name} is happy");
                else Hud.SetPrompt($"E  Pet {beast.Name}");
                if (pet && !beast.PettedToday)
                {
                    beast.Pet();
                    if (_heart != null) StartCoroutine(HeartPop(beast.transform));
                    Hud.Toast(beast.Kind == BeastKind.Cow ? $"{beast.Name} moos happily." : $"{beast.Name} bleats happily.", 1.5f);
                }
                return;
            }

            // The hay feeder.
            if (Vector2.Distance(feet, FeederSpot) > 1.1f) return;
            int have = Inventory.Count(Items.Hay);
            if (Hay >= FeederMax) Hud.SetPrompt($"The feeder is full ({Hay} hay)");
            else if (have == 0)
                Hud.SetPrompt(Hay == 0 ? "The hay feeder is empty. Mabel sells Hay for winter." : $"Feeder: {Hay} hay left. Mabel sells more.");
            else
            {
                Hud.SetPrompt($"F  Fill the feeder ({Hay}/{FeederMax})");
                if (!GameInput.FishPressed()) return;
                int add = Inventory.Remove(Items.Hay, Mathf.Min(have, FeederMax - Hay));
                Hay += add;
                RefreshFeeder();
                Hud.Toast($"You put {add} hay in the feeder.", 1.5f);
            }
        }

        IEnumerator HeartPop(Transform beast)
        {
            var sr = new GameObject("Heart").AddComponent<SpriteRenderer>();
            sr.sprite = _heart;
            sr.sortingOrder = 31500;
            for (float k = 0f; k < 1f; k += Time.deltaTime / 0.9f)
            {
                if (beast == null) break;
                sr.transform.position = (Vector2)beast.position + new Vector2(0f, 1.6f + k * 0.6f);
                sr.color = new Color(1f, 1f, 1f, k < 0.6f ? 1f : 1f - (k - 0.6f) / 0.4f);
                yield return null;
            }
            Destroy(sr.gameObject);
        }
    }

    /// <summary>Recipes for the cheese press.</summary>
    public static class Dairy
    {
        public static readonly Recipe[] All =
        {
            new Recipe
            {
                Name = "Cheese", Icon = Items.Cheese, Makes = Items.Cheese,
                Text = "Sells for 180g. Heals 2 hearts.",
                Needs = new[] { (Items.Milk, 1) },
            },
            new Recipe
            {
                Name = "Goat Cheese", Icon = Items.GoatCheese, Makes = Items.GoatCheese,
                Text = "Sells for 280g. Heals 2 hearts.",
                Needs = new[] { (Items.GoatMilk, 1) },
            },
        };
    }

    /// <summary>One cow or goat: grazes and wanders the pasture by day, goes into the barn at dusk.</summary>
    public class Beast : MonoBehaviour
    {
        public string Name { get; private set; }
        public BeastKind Kind { get; private set; }
        public int Happiness, Days;
        public bool Ready, JustArrived;
        public bool PettedToday { get; private set; }
        public bool Asleep { get; private set; }

        const float Bedtime = 19f;
        Sprite[] _frames;
        SpriteRenderer _sr, _shadow;
        Vector2 _target;
        float _waitUntil, _grazeUntil, _speed;

        public void Init(string name, BeastKind kind, Sprite[] frames)
        {
            Name = name;
            Kind = kind;
            _frames = frames;
            _speed = kind == BeastKind.Cow ? 0.6f : 0.9f;
            _sr = GetComponent<SpriteRenderer>();
            _shadow = transform.GetChild(0).GetComponent<SpriteRenderer>();
            _target = transform.position;
            _waitUntil = Time.time + Random.Range(0.5f, 3f);
            if (GameClock.Hour >= Bedtime) Show(false);
        }

        public void Pet()
        {
            PettedToday = true;
            Happiness = Mathf.Min(5, Happiness + 1);
        }

        public void WakeUp(Vector2 at)
        {
            transform.position = at;
            _target = at;
            PettedToday = false;
            Show(true);
        }

        void Show(bool on)
        {
            Asleep = !on;
            _sr.enabled = on;
            if (_shadow != null) _shadow.enabled = on;
        }

        void Update()
        {
            if (_frames == null || Asleep) return;
            Vector2 pos = transform.position;

            if (GameClock.Hour >= Bedtime)
            {
                _target = Barn.Door;
                if (Vector2.Distance(pos, _target) < 0.15f) { Show(false); return; }
            }
            else if (Time.time >= _waitUntil && Vector2.Distance(pos, _target) < 0.05f)
            {
                // Arrived: graze for a while, then amble somewhere else.
                _grazeUntil = Time.time + Random.Range(1.5f, 4f);
                _waitUntil = _grazeUntil + Random.Range(1f, 4f);
                _target = Barn.WanderSpot();
            }

            bool walking = Time.time >= _waitUntil || GameClock.Hour >= Bedtime;
            if (walking && Vector2.Distance(pos, _target) > 0.05f)
            {
                Vector2 next = Vector2.MoveTowards(pos, _target, _speed * Time.deltaTime);
                if (Mathf.Abs(next.x - pos.x) > 0.001f) _sr.flipX = next.x > pos.x;   // the art faces left
                transform.position = next;
                _sr.sprite = _frames[1 + (int)(Time.time * 4f) % 2];
            }
            else _sr.sprite = _frames[Time.time < _grazeUntil ? 3 : 0];
        }
    }
}
