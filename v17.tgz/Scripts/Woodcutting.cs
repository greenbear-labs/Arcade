using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// A tree on the farm you can chop down with the axe. A few swings fell it
    /// for wood and leave a stump, which grows back into a tree after a few days.
    /// </summary>
    public class ChoppableTree : MonoBehaviour
    {
        public const int HitsToFell = 4, WoodPerTree = 5, DaysToRegrow = 5;

        public Vector2Int Cell;
        public bool Stump { get; private set; }
        public int StumpDays;
        int _hits;
        SpriteRenderer _sr;

        public static readonly List<ChoppableTree> All = new List<ChoppableTree>();

        void Awake() => _sr = GetComponent<SpriteRenderer>();
        void OnEnable() => All.Add(this);
        void OnDisable() => All.Remove(this);

        public void Hit()
        {
            if (Stump) return;
            StopAllCoroutines();
            StartCoroutine(Shake());
            if (++_hits < HitsToFell) return;
            _hits = 0;
            Fell();
            Hud.Toast($"Timber! +{WoodPerTree} Wood", 2f);
        }

        public void Fell()
        {
            Stump = true;
            StumpDays = 0;
            _sr.sprite = Art.Single("stump");
            _sr.transform.localScale = Vector3.one;
        }

        public void Regrow()
        {
            Stump = false;
            _hits = 0;
            _sr.sprite = Seasons.Prop("tree", Seasons.Current);
        }

        IEnumerator Shake()
        {
            Vector3 home = transform.position;
            for (float t = 0f; t < 0.25f; t += Time.deltaTime)
            {
                transform.position = home + new Vector3(Mathf.Sin(t * 70f) * 0.06f * (1f - t / 0.25f), 0f, 0f);
                yield return null;
            }
            transform.position = home;
        }
    }

    /// <summary>Swinging the axe at trees, and stumps growing back each morning.</summary>
    public class Woodcutting : MonoBehaviour
    {
        void OnEnable() => GameClock.NewDay += Morning;
        void OnDisable() => GameClock.NewDay -= Morning;

        static void Morning()
        {
            foreach (var t in ChoppableTree.All)
            {
                if (!t.Stump) continue;
                if (++t.StumpDays >= ChoppableTree.DaysToRegrow) t.Regrow();
            }
        }

        public static void Export(List<SaveGame.CellDays> list)
        {
            foreach (var t in ChoppableTree.All)
                if (t.Stump) list.Add(new SaveGame.CellDays { x = t.Cell.x, y = t.Cell.y, days = t.StumpDays });
        }

        public static void Import(List<SaveGame.CellDays> list)
        {
            foreach (var s in list)
                foreach (var t in ChoppableTree.All)
                    if (t.Cell.x == s.x && t.Cell.y == s.y) { t.Fell(); t.StumpDays = s.days; }
        }

        void Update()
        {
            var player = PlayerController.Instance;
            if (player == null || Hud.Busy || player.Locked || player.IsAttacking || Home.Inside || Mine.Inside) return;
            if (Inventory.SelectedItem != Items.Axe) return;
            Vector2 feet = (Vector2)player.transform.position + new Vector2(0f, 0.15f);
            Vector2 ahead = feet + Art.Dir(player.Facing) * 0.7f;

            ChoppableTree tree = null;
            float best = 0.9f;
            foreach (var t in ChoppableTree.All)
            {
                float d = Vector2.Distance(ahead, (Vector2)t.transform.position + new Vector2(0f, 0.2f));
                if (d < best) { best = d; tree = t; }
            }
            if (tree == null) return;
            if (tree.Stump)
            {
                int left = ChoppableTree.DaysToRegrow - tree.StumpDays;
                Hud.SetPrompt($"A stump. A new tree grows here in {left} day{(left == 1 ? "" : "s")}");
                return;
            }
            Hud.SetPrompt("F  Chop the tree");
            if (!GameInput.FishPressed()) return;
            if (!Inventory.HasRoomFor(Items.Wood)) { Hud.Toast("Your bag is full! Make room for the wood first.", 2.5f); return; }
            tree.Hit();
            if (tree.Stump) Inventory.Add(Items.Wood, ChoppableTree.WoodPerTree);
        }
    }
}
