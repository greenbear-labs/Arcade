using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace FarmDemo
{
    /// <summary>
    /// Keeps your farm between visits, like Stardew: the game saves each morning
    /// after you sleep, and picks up from there next time you open it. It's kept in
    /// PlayerPrefs (the browser's own storage on the web), so it stays on this device.
    /// "Reset progress" in the settings menu wipes it.
    /// </summary>
    public class SaveGame : MonoBehaviour
    {
        const string Key = "MythicaFarmer.Save";
        const int Version = 1;

        [System.Serializable]
        public class Cell { public int x, y; }

        [System.Serializable]
        public class Slot { public string item; public int count; }

        [System.Serializable]
        public class CropState { public int x, y; public string crop; public int days; public bool wilted; }

        [System.Serializable]
        public class HenState { public string name; public int happiness; public bool brown; }

        [System.Serializable]
        public class EggState { public string item; public float x, y; }

        [System.Serializable]
        public class BeastState { public string name; public int kind, happiness, days; public bool ready; }

        [System.Serializable]
        public class HiveState { public int x, y, days; public bool ready; }

        [System.Serializable]
        public class CellDays { public int x, y, days; }

        [System.Serializable]
        public class ChestState { public int x, y; public List<Slot> slots = new List<Slot>(); }

        [System.Serializable]
        public class FriendState { public string name; public int points; public bool rewardGiven; }

        [System.Serializable]
        public class QuestState { public string giver, item; public int amount, reward, daysLeft; }

        [System.Serializable]
        public class Data
        {
            public int version = Version;
            public int day, gold, water, selected, feed, deepest, hay;
            public int canLevel, hoeLevel, pickaxeLevel, swordLevel;
            public List<Cell> sprinklers = new List<Cell>();
            public bool grandpaGaveSeeds;
            public List<Slot> slots = new List<Slot>();
            public List<Cell> soil = new List<Cell>();
            public List<CropState> crops = new List<CropState>();
            public List<HenState> hens = new List<HenState>();
            public List<EggState> eggs = new List<EggState>();
            public List<BeastState> barn = new List<BeastState>();
            public List<EggState> truffles = new List<EggState>();
            public List<HiveState> hives = new List<HiveState>();
            public List<string> tools = new List<string>();
            public int toolIndex;
            public bool toolActive;
            public List<ChestState> chests = new List<ChestState>();
            public List<CellDays> stumps = new List<CellDays>();
            public List<CellDays> dirt = new List<CellDays>();
            public List<FriendState> friends = new List<FriendState>();
            public List<QuestState> quest = new List<QuestState>();     // zero or one
        }

        public static bool HasSave => PlayerPrefs.HasKey(Key);

        void Start() => GameClock.NewDay += Save;      // subscribes after everything else, so it sees the finished morning
        void OnDestroy() => GameClock.NewDay -= Save;

        public static void Save()
        {
            var d = new Data
            {
                day = GameClock.Day,
                gold = PlayerStats.Gold,
                water = Inventory.Water,
                selected = Inventory.Selected,
                feed = Animals.Feed,
                hay = Barn.Hay,
                deepest = Mine.Deepest,
                canLevel = Upgrades.Can, hoeLevel = Upgrades.Hoe, pickaxeLevel = Upgrades.Pickaxe, swordLevel = Upgrades.Sword,
                grandpaGaveSeeds = FarmDemoWorld.GrandpaGaveSeeds,
            };
            foreach (var s in Inventory.All) d.slots.Add(s == null ? new Slot() : new Slot { item = s.Item.Name, count = s.Count });
            foreach (var c in FarmDemoWorld.SoilCells()) d.soil.Add(new Cell { x = c.x, y = c.y });
            foreach (var c in Sprinklers.Cells) d.sprinklers.Add(new Cell { x = c.x, y = c.y });
            FarmingController.Export(d.crops);
            Animals.Export(d.hens, d.eggs);
            Barn.Export(d.barn, d.truffles);
            Apiary.Export(d.hives);
            foreach (var t in Toolbelt.Tools) d.tools.Add(t.Name);
            d.toolIndex = Toolbelt.Index;
            d.toolActive = Toolbelt.Active;
            Chests.Export(d.chests);
            Woodcutting.Export(d.stumps);
            FarmDemoWorld.ExportDirt(d.dirt);
            foreach (var f in Friendship.All) d.friends.Add(new FriendState { name = f.Name, points = f.Points, rewardGiven = f.RewardGiven });
            var q = QuestBoard.Current;
            if (q != null) d.quest.Add(new QuestState { giver = q.Giver, item = q.Item.Name, amount = q.Amount, reward = q.Reward, daysLeft = q.DaysLeft });
            PlayerPrefs.SetString(Key, JsonUtility.ToJson(d));
            PlayerPrefs.Save();
        }

        /// <summary>Put the saved farm back. Returns false (and changes nothing) if there's no usable save.</summary>
        public static bool Load()
        {
            if (!HasSave) return false;
            Data d;
            try { d = JsonUtility.FromJson<Data>(PlayerPrefs.GetString(Key)); }
            catch (System.Exception e) { Debug.LogWarning("[Farm Demo] Couldn't read the save: " + e.Message); return false; }
            if (d == null || d.version != Version || d.day < 1) return false;

            GameClock.SetDay(d.day);
            Upgrades.Can = d.canLevel; Upgrades.Hoe = d.hoeLevel; Upgrades.Pickaxe = d.pickaxeLevel; Upgrades.Sword = d.swordLevel;
            PlayerStats.Gold = d.gold;
            for (int i = 0; i < Inventory.SlotCount; i++)
            {
                var s = i < d.slots.Count ? d.slots[i] : null;
                var item = s != null ? Items.ByName(s.item) : null;
                Inventory.SetSlot(i, item, s != null ? s.count : 0);
            }
            foreach (var name in d.tools) if (Items.ByName(name) is ItemDef tool) Toolbelt.Give(tool);
            Inventory.Water = Mathf.Clamp(d.water, 0, Inventory.WaterMax);
            Inventory.Select(d.selected);
            if (d.tools.Count > 0) Toolbelt.Restore(d.toolIndex, d.toolActive);
            else Toolbelt.Pick(Items.Hoe);     // a save from before the toolbelt: its tools just moved onto the dial
            FarmDemoWorld.GrandpaGaveSeeds = d.grandpaGaveSeeds;
            Mine.Deepest = Mathf.Max(0, d.deepest);
            foreach (var c in d.soil) FarmDemoWorld.SetSoil(new Vector2Int(c.x, c.y));
            FarmingController.Import(d.crops);
            foreach (var c in d.sprinklers) FarmingController.PlaceSprinkler(new Vector2Int(c.x, c.y));
            Animals.Import(d.feed, d.hens, d.eggs);
            Barn.Import(d.hay, d.barn, d.truffles);
            Apiary.Import(d.hives);
            Chests.Import(d.chests);
            Woodcutting.Import(d.stumps);
            FarmDemoWorld.ImportDirt(d.dirt);
            foreach (var fs in d.friends)
            {
                var f = Friendship.Get(fs.name);
                if (f == null) continue;
                f.Points = Mathf.Clamp(fs.points, 0, Friendship.MaxHearts * Friendship.PointsPerHeart);
                f.RewardGiven = fs.rewardGiven;
            }
            QuestBoard.Quest quest = null;
            if (d.quest.Count > 0 && Items.ByName(d.quest[0].item) is ItemDef qi)
                quest = new QuestBoard.Quest { Giver = d.quest[0].giver, Item = qi, Amount = d.quest[0].amount, Reward = d.quest[0].reward, DaysLeft = d.quest[0].daysLeft };
            QuestBoard.Restore(quest);
            return true;
        }

        /// <summary>Erase the save and start again on Spring 1. Settings are kept.</summary>
        public static void StartOver()
        {
            PlayerPrefs.DeleteKey(Key);
            PlayerPrefs.Save();
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }

    /// <summary>Choices from the settings menu, kept on this device apart from the save.</summary>
    public static class Settings
    {
        const string LongDaysKey = "MythicaFarmer.LongDays", HintsKey = "MythicaFarmer.KeyHints";

        /// <summary>Relaxed days last twice as long, for more time to farm.</summary>
        public static bool LongDays
        {
            get => PlayerPrefs.GetInt(LongDaysKey, 0) == 1;
            set { PlayerPrefs.SetInt(LongDaysKey, value ? 1 : 0); PlayerPrefs.Save(); }
        }

        /// <summary>The line of keyboard controls under the hearts.</summary>
        public static bool KeyHints
        {
            get => PlayerPrefs.GetInt(HintsKey, 1) == 1;
            set { PlayerPrefs.SetInt(HintsKey, value ? 1 : 0); PlayerPrefs.Save(); }
        }

        /// <summary>Real seconds from 6 AM to 2 AM.</summary>
        public static float DayLength => FarmDemoConfig.DayLengthSeconds * (LongDays ? 2f : 1f);
    }
}
