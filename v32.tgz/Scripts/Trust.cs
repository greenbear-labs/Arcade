using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>How someone in town feels about creatures. Everyone has always known creatures
    /// as wild, dangerous animals; you're the first to try befriending them.</summary>
    public enum TrustStage { Afraid, Wary, Curious, Welcoming, Connected }

    /// <summary>
    /// Creature trust: every townsperson has their own meter (0 to 100, 20 points a stage).
    /// It grows from what creatures do: town events add to everyone at once (Trust.Town),
    /// personal tasks and small everyday moments add to one person (Trust.Add). You see a
    /// person's meter when you talk to them, and everyone you've met in the bag's Townsfolk tab,
    /// with their state of mind and any clues you've heard about what's bothering them.
    /// Reaching Welcoming, and then Connected, they give you a gift.
    /// What everyone says lives in TownLines.
    /// </summary>
    public static class Trust
    {
        public const int Max = 100, PerStage = 20;
        /// <summary>Chatting with your creature beside you, once a day per person.</summary>
        const int DailyChat = 2;
        const float CreatureNear = 5f;

        public class Gift
        {
            public ItemDef Item;
            public int Count = 1, Gold;
            public string Line;
        }

        public class Person
        {
            public string Name, Short;
            public int Points;
            public bool Met, ChattedToday;
            public bool GaveWelcomeGift, GaveConnectedGift;
            /// <summary>What they say about creatures, one line per stage (the first chat each day).</summary>
            public string[] Says = new string[5];
            /// <summary>Their state of mind for the Townsfolk tab, one per stage (null = the general one).</summary>
            public string[] Mind = new string[5];
            public Gift WelcomeGift, ConnectedGift;
            public TrustStage Stage => StageOf(Points);
            /// <summary>0..1 of the way through the whole meter.</summary>
            public float Fill => Points / (float)Max;
        }

        /// <summary>Something one person tells you about another's trouble. Shows in the Townsfolk tab
        /// under the person it's about once you've heard it, ticked once Done says so.</summary>
        public class Clue
        {
            public string Id, From, About, Line, Note;
            public System.Func<bool> Ready, Done;
        }

        static readonly List<Person> People = new List<Person>();
        static readonly List<Clue> Clues = new List<Clue>();
        static readonly HashSet<string> Heard = new HashSet<string>();

        public static IReadOnlyList<Person> All => People;
        public static IEnumerable<string> HeardClues => Heard;

        public static TrustStage StageOf(int points) => (TrustStage)Mathf.Clamp(points / PerStage, 0, 4);

        public static void Reset()
        {
            People.Clear();
            Clues.Clear();
            Heard.Clear();
            GameClock.NewDay -= Morning;
            GameClock.NewDay += Morning;
        }

        public static Person Register(string name, string shortName, int start, string[] says, Gift welcome, Gift connected, string[] mind = null)
        {
            var p = new Person
            {
                Name = name, Short = shortName, Points = Mathf.Clamp(start, 0, Max),
                Says = says ?? new string[5], WelcomeGift = welcome, ConnectedGift = connected,
            };
            if (mind != null) p.Mind = mind;
            People.Add(p);
            return p;
        }

        public static void AddClue(string id, string from, string about, string line, string note, System.Func<bool> done, System.Func<bool> ready = null) =>
            Clues.Add(new Clue { Id = id, From = from, About = about, Line = line, Note = note, Done = done, Ready = ready });

        public static Person Get(string name) => People.Find(p => p.Name == name);
        public static bool Knows(string name) => Get(name) != null;
        /// <summary>Their stage, or Connected for anyone without a meter (the forest folk don't fear creatures).</summary>
        public static TrustStage Stage(string name) => Get(name)?.Stage ?? TrustStage.Connected;
        public static string StageName(TrustStage s) => s.ToString();

        public static Color StageColor(TrustStage s)
        {
            switch (s)
            {
                case TrustStage.Afraid: return new Color32(0x6a, 0x7a, 0x9a, 0xff);
                case TrustStage.Wary: return new Color32(0x9a, 0x6a, 0xb8, 0xff);
                case TrustStage.Curious: return new Color32(0xe0, 0xa8, 0x30, 0xff);
                case TrustStage.Welcoming: return new Color32(0x5f, 0xae, 0x47, 0xff);
                default: return new Color32(0xe8, 0x6a, 0x9a, 0xff);
            }
        }

        static void Morning()
        {
            foreach (var p in People) p.ChattedToday = false;
        }

        /// <summary>Trust for one person. A new stage gets a toast (unless quiet).</summary>
        public static void Add(string name, int points, bool quiet = false)
        {
            var p = Get(name);
            if (p == null || points == 0) return;
            var before = p.Stage;
            p.Points = Mathf.Clamp(p.Points + points, 0, Max);
            if (p.Stage != before && !quiet)
                Hud.Toast($"{p.Short} is {Describe(p.Stage)} creatures now!", 3f);
        }

        /// <summary>A town event: it adds to everyone's meter. One toast, naming who reached a new stage.</summary>
        public static void Town(int points, string message)
        {
            var moved = new List<string>();
            foreach (var p in People)
            {
                var before = p.Stage;
                p.Points = Mathf.Clamp(p.Points + points, 0, Max);
                if (p.Stage != before) moved.Add(p.Short);
            }
            string who = moved.Count == 0 ? "" : moved.Count == 1 ? $" {moved[0]} feels differently now."
                : moved.Count == 2 ? $" {moved[0]} and {moved[1]} feel differently now." : $" {moved[0]}, {moved[1]} and others feel differently now.";
            Hud.Toast(message + who, 4f);
        }

        static string Describe(TrustStage s)
        {
            switch (s)
            {
                case TrustStage.Afraid: return "afraid of";
                case TrustStage.Wary: return "only wary of";
                case TrustStage.Curious: return "curious about";
                case TrustStage.Welcoming: return "welcoming to";
                default: return "connected to";
            }
        }

        /// <summary>Their state of mind for the Townsfolk tab.</summary>
        public static string MindOf(Person p)
        {
            string own = p.Mind != null && p.Mind.Length > (int)p.Stage ? p.Mind[(int)p.Stage] : null;
            if (!string.IsNullOrEmpty(own)) return own;
            switch (p.Stage)
            {
                case TrustStage.Afraid: return $"{p.Short} thinks creatures are wild and dangerous, and keeps well away.";
                case TrustStage.Wary: return $"{p.Short} has stopped running from creatures, but doesn't trust them.";
                case TrustStage.Curious: return $"{p.Short} is curious about creatures and full of questions.";
                case TrustStage.Welcoming: return $"{p.Short} is happy to see creatures about town.";
                default: return $"{p.Short} feels connected to creatures now.";
            }
        }

        /// <summary>Clues you've heard about this person, with whether they're sorted.</summary>
        public static IEnumerable<(string note, bool done)> CluesAbout(string name)
        {
            foreach (var c in Clues)
                if (c.About == name && Heard.Contains(c.Id)) yield return (c.Note, c.Done != null && c.Done());
        }

        public static void Restore(string name, int points, bool met, bool welcomeGift, bool connectedGift)
        {
            var p = Get(name);
            if (p == null) return;
            p.Points = Mathf.Clamp(points, 0, Max);
            p.Met = met;
            p.GaveWelcomeGift = welcomeGift;
            p.GaveConnectedGift = connectedGift;
        }

        public static void RestoreClue(string id) => Heard.Add(id);

        /// <summary>
        /// You've pressed E on someone: what they say before their usual lines. The first chat
        /// of the day, a line about creatures for their stage (a warning, before you have any;
        /// a reaction, if your creature's right there), and a clue if they have one for you. Chatting with your creature beside
        /// you is a small everyday moment that adds a little trust.
        /// </summary>
        public static string[] Chat(string name, Vector2 at)
        {
            var p = Get(name);
            if (p == null) return new string[0];
            p.Met = true;
            var lines = new List<string>();
            bool creature = Creatures.FollowerNear(at, CreatureNear);
            if (!p.ChattedToday)
            {
                p.ChattedToday = true;
                // Before you've befriended any creature, folk just warn you about them.
                string say = creature ? TownLines.CreatureHere(p) : !Creatures.AnyFriend ? TownLines.Warning(p) : p.Says[(int)p.Stage];
                if (!string.IsNullOrEmpty(say)) lines.Add(say);
                foreach (var c in Clues)
                {
                    if (c.From != name || Heard.Contains(c.Id) || (c.Done != null && c.Done()) || (c.Ready != null && !c.Ready())) continue;
                    Heard.Add(c.Id);
                    lines.Add(c.Line);
                    Hud.Toast("New clue in your bag, under Townsfolk.", 2.5f);
                    break;
                }
                if (creature) Add(name, DailyChat);
            }
            return lines.ToArray();
        }

        /// <summary>A gift once they reach Welcoming, and another at Connected (shown after the chat). Null if none is due.</summary>
        public static System.Action GiftIfDue(string name)
        {
            var p = Get(name);
            if (p == null) return null;
            bool connected = p.Stage >= TrustStage.Connected && !p.GaveConnectedGift && p.GaveWelcomeGift;
            bool welcome = p.Stage >= TrustStage.Welcoming && !p.GaveWelcomeGift;
            if (!welcome && !connected) return null;
            var gift = welcome ? p.WelcomeGift : p.ConnectedGift;
            return () =>
            {
                if (welcome ? p.GaveWelcomeGift : p.GaveConnectedGift) return;
                if (gift != null && gift.Item != null && !Inventory.Add(gift.Item, gift.Count)) { Hud.Toast("Your bag is full! Come back for your gift.", 2.5f); return; }
                if (welcome) p.GaveWelcomeGift = true; else p.GaveConnectedGift = true;
                if (gift == null) return;
                PlayerStats.Gold += gift.Gold;
                string what = gift.Item != null ? (gift.Count > 1 ? $"{gift.Count} x {gift.Item.Name}" : gift.Item.Name) : $"{gift.Gold} gold";
                Hud.ShowPopup(gift.Item != null ? gift.Item.Icon : null, $"A gift from {p.Short}: {what}!", gift.Line);
            };
        }
    }
}
