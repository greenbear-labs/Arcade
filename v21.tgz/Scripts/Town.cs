using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>What a shop sells, and what (and for how much) it buys from you.</summary>
    public class ShopDef
    {
        public string Title;
        /// <summary>What the Sell column says when you've nothing they want.</summary>
        public string Empty = "Nothing to sell.";
        public System.Func<List<(ItemDef item, int price)>> Stock = () => new List<(ItemDef, int)>();
        /// <summary>Which of your things they'll buy. Null: nothing.</summary>
        public System.Func<ItemDef, bool> Wants;
        /// <summary>How much over the usual price they pay (Mabel pays 1x).</summary>
        public float Markup = 1f;

        public bool Buys(ItemDef item) => Wants != null && item.SellPrice > 0 && Wants(item);
        public int Pays(ItemDef item) => Mathf.Max(1, Mathf.RoundToInt(item.SellPrice * Markup));
    }

    /// <summary>
    /// The town: Mabel's bakery and the market street east of the village, with a
    /// shop for seeds, flowers, the blacksmith, the restaurant, livestock, the
    /// carpenter, the science lab, the seamstress and the builders. Press E at a
    /// shop's door to go in while it's open; the shopkeeper's behind the counter.
    /// Each morning the townsfolk walk from their homes (along the street behind the
    /// shops) to work, and back home again in the evening. Homes stay locked.
    /// </summary>
    public class Town : MonoBehaviour
    {
        public class Shop
        {
            public string Name, Owner;
            public Vector2 Door;            // outside: the bottom middle of the shopfront
            public Vector2 RoomOrigin;      // inside: an 8x6 room, bottom left corner
            public Resident Keeper;
            public Vector2 RoomDoor => RoomOrigin + new Vector2(RoomWidth / 2f, 0.35f);
            public Vector2 KeeperSpot => RoomOrigin + new Vector2(RoomWidth / 2f, 3.85f);
            public bool Open => Keeper == null || Keeper.AtWork;
        }

        /// <summary>A townsperson with a home and a job.</summary>
        public class Resident
        {
            public Npc Npc;
            public Vector2 HomeDoor;
            public Shop Work;               // their shop, or null for someone who works outdoors
            public Vector2 WorkSpot;        // outdoors: where they stand all day. In a shop: where they stand inside.
            public float Arrive, GoHome;    // hours
            /// <summary>Somewhere else to work today (the builders' job site), or null.</summary>
            public System.Func<Vector2?> Site;
            public bool AtWork;
            internal List<Vector2> Route, SiteRoute;
            internal Vector2? SiteFor;
            internal float Length, SiteLength;
            internal Collider2D Feet;
        }

        public const float RoomWidth = 8f, RoomHeight = 6f;
        /// <summary>Townsfolk walk at this many tiles a second, a bit slower than you.</summary>
        const float WalkSpeed = 3f;
        const float OpenHour = 9f;
        static readonly Color32 IndoorBackground = new Color32(0x1a, 0x12, 0x10, 0xff);

        // ------------------------------------------------------------- the layout (the world reads this to lay the paths)

        /// <summary>The market street: the road's east end, two lanes up, and a back street behind the shops.</summary>
        public const int StreetLeft = 76, StreetRight = 137, BackStreetY = 20, HomesY = 23, ShopsY = 14;
        /// <summary>Shopfronts along the north side of the road: art, door x, width in tiles.</summary>
        public static readonly (string art, int x, string name)[] Fronts =
        {
            ("shop_seeds", 80, "Hazel's Seeds"), ("shop_flowers", 86, "Poppy's Flowers"), ("shop_smithy", 92, "Ingrid's Forge"),
            ("shop_food", 98, "The Basil Leaf"), ("shop_livestock", 105, "Hank's Livestock"), ("shop_carpenter", 112, "Oakley's Workshop"),
            ("shop_lab", 118, "Science Lab"), ("shop_tailor", 124, "Bea's Sewing Room"), ("shop_builder", 131, "Brick & Crew Builders"),
        };
        /// <summary>Homes along the back street: door x. Mabel, Hazel, Poppy, Ingrid, Basil, Hank, Oakley, Quill, Bea, and the builders.</summary>
        public static readonly int[] HomeXs = { 80, 86, 92, 98, 104, 110, 116, 122, 128, 134 };
        public static readonly Vector2 BakeryDoor = new Vector2(54f, 14f), PipsDoor = new Vector2(70f, 14f);

        /// <summary>Is this tile a path in town (the lanes, the back street and the door steps)?</summary>
        public static bool IsStreet(int x, int y)
        {
            if (x < StreetLeft || x > StreetRight) return false;
            if (y >= 13 && y <= BackStreetY + 1 && (x <= StreetLeft + 1 || x >= StreetRight - 1)) return true;
            if (y == BackStreetY || y == BackStreetY + 1) return true;
            if (y == 13) foreach (var f in Fronts) if (x == f.x - 1 || x == f.x) return true;
            if (y == HomesY - 1) foreach (int h in HomeXs) if (x == h - 1 || x == h) return true;
            return false;
        }

        // ------------------------------------------------------------- state

        public static Shop Current { get; private set; }
        public static bool Inside => Current != null;

        static Town _instance;
        readonly List<Shop> _shops = new List<Shop>();
        readonly List<Resident> _residents = new List<Resident>();
        readonly List<(Vector2 door, string owner)> _homes = new List<(Vector2, string)>();
        SpriteRenderer _prompt;
        Sprite _promptSprite;
        bool _routed;

        void OnDestroy()
        {
            GameClock.NewDay -= Morning;
            if (_instance == this) { _instance = null; Current = null; }
        }

        // The night's over: you wake up at home, whatever shop you fell asleep in.
        static void Morning()
        {
            Current = null;
            Builder.Morning();
        }

        // ------------------------------------------------------------- building it

        public void Build(Npc mabel, Npc pip, Sprite prompt)
        {
            _instance = this;
            Current = null;
            Builder.Reset();
            _promptSprite = prompt;
            _prompt = new GameObject("Door prompt").AddComponent<SpriteRenderer>();
            _prompt.transform.SetParent(transform, false);
            _prompt.sprite = prompt;
            _prompt.sortingOrder = 32000;
            _prompt.enabled = false;
            GameClock.NewDay += Morning;

            var people = new GameObject("Townsfolk").transform;
            people.SetParent(transform, false);

            // Mabel's bakery was already standing; now you can go in.
            var bakery = AddShop("Mabel's Bakery", "room_bakery", BakeryDoor, false, 0);
            var shops = new Shop[Fronts.Length];
            for (int i = 0; i < Fronts.Length; i++)
            {
                var f = Fronts[i];
                shops[i] = AddShop(f.name, f.art.Replace("shop_", "room_"), new Vector2(f.x, ShopsY), true, i + 1);
            }
            for (int i = 0; i < HomeXs.Length; i++)
            {
                var sr = Prop(transform, $"home{i % 5}", new Vector2(HomeXs[i], HomesY), new Vector2(2.7f, 1.4f));
                if (sr != null) FarmDemoWorld.Tall(sr.gameObject);
            }
            Decorate();

            Vector2 Home(int i) => new Vector2(HomeXs[i], HomesY);
            int n = 0;
            if (mabel != null)
            {
                var r = Keep(bakery, mabel, Home(0), n++);
                string[][] chat =
                {
                    new[] { "Welcome in, sweetie! Fresh bread, pies and cakes. And I'll buy anything you've got." },
                    new[] { "I once sold a loaf of bread to a goose. He paid in exact change. I have questions." },
                    new[] { "Seeds? Hazel's got those now, up the market street. I've got my hands full with the ovens." },
                    new[] { "Hens and cows are Hank's department these days. He's the one in the big hat." },
                    new[] { "A Golden Trout! If you ever catch one, I'll pay a fortune. For a pie. Don't ask." },
                    new[] { "Got a pig yet? They root up truffles. I'll pay 300g apiece, no questions asked." },
                    new[] { "I walk to work every morning from my little house on the back street. Keeps the legs strong." },
                    new[] { "Basil at the restaurant pays a bit more for good ingredients. Don't tell him I told you." },
                };
                int next = 0;
                mabel.SetScript(() => chat[next++ % chat.Length], () => Hud.OpenShop(Shops.Bakery));
                _homes.Add((Home(0), "Mabel"));
                _homes.Add((Home(9), "Brick and the crew"));
            }
            if (pip != null)
            {
                // Pip doesn't have a shop. Pip has the fountain.
                var r = new Resident { Npc = pip, HomeDoor = PipsDoor, WorkSpot = new Vector2(59.5f, 16.5f), Arrive = 9.2f, GoHome = 18f };
                Prepare(r);
                _homes.Add((PipsDoor, "Pip"));
            }

            var hazel = Person(people, "npc_hazel", "Hazel", new[] { "Hazel's Seeds! Everything here grows, if you water it." });
            var poppy = Person(people, "npc_poppy", "Poppy", null);
            var ingrid = Person(people, "npc_ingrid", "Ingrid", null);
            var basil = Person(people, "npc_basil", "Chef Basil", null);
            var hank = Person(people, "npc_hank", "Hank", null);
            var oakley = Person(people, "npc_oakley", "Oakley", null);
            var quill = Person(people, "npc_quill", "Dr. Quill", null);
            var bea = Person(people, "npc_bea", "Bea", null);
            var brick = Person(people, "npc_brick", "Brick", null);
            var nails = Person(people, "npc_nails", "Nails", null);
            var plank = Person(people, "npc_plank", "Plank", null);

            Talk(hazel, () => Hud.OpenShop(Shops.Seeds),
                "Hazel's Seeds! Everything here grows, if you water it.",
                "My seeds change with the seasons. Tomatoes in summer, pumpkins in fall.",
                "Fruit trees! Plant a sapling on open grass with a bit of room round it. A week to grow up, then fruit every couple of days in its season.",
                "Cherries in spring, peaches and oranges in summer, apples in fall. Nothing fruits in winter, poor things.",
                "Strawberries take three nights, but they come in bunches. Worth it.");
            Talk(poppy, () => Hud.OpenShop(Shops.Flowers),
                "Poppy's Flowers! Tulips in spring, sunflowers summer and fall, lavender spring and summer.",
                "Bring me your flowers. I pay more than Mabel does, because I actually appreciate them.",
                "Bee houses near flowers make the happiest bees. I sell those too.",
                "Lavender is the blimp bee's favourite, you know. Everyone in the meadow knows.");
            Talk(ingrid, () => Hud.OpenBench("Ingrid's Forge", Smithing.All),
                "Ingrid. Blacksmith. Bring me ore and gems and I'll make your tools better.",
                "Copper for your can, iron for your hoe, a gem or two for the pickaxe and sword.",
                "Dot sends me her best ore. Dig deep and you'll find it too.");
            Talk(basil, () => Hud.OpenShop(Shops.Restaurant),
                "Welcome to the Basil Leaf! Sit, eat. Or sell me your fresh ingredients, I pay well.",
                "Crops, eggs, milk, fish, fruit. If it's fresh, I want it.",
                "Too tired to cook? My kitchen's always hot. Hearty meals, ready to go.");
            Talk(hank, () => Hud.OpenShop(Shops.Livestock),
                "Howdy! Hank's Livestock. Hens, cows, goats, pigs, and the feed and hay to keep 'em happy.",
                "Your coop's full? Brick and his crew can build you a bigger one.",
                "Eggs, milk and cheese, I'll buy. Pay a bit over Mabel for 'em, too.");
            Talk(oakley, null,
                "Oakley's Workshop. Tables, chairs, beds, the lot.",
                "I'm still setting up. Give me a little while and I'll make furniture for your house.",
                "Good wood makes good furniture. Save yours up for when I'm ready.");
            Talk(quill, null,
                "Dr. Quill, at your service. This is the valley's one and only science lab.",
                "My experiments aren't ready for the public. Yet. Come back later and I'll have upgrades for you.",
                "That crystal cave in the mountains? Fascinating readings. Fascinating.");
            Talk(bea, null,
                "Hello, dear! Bea's Sewing Room. I'm still unpacking all my thread.",
                "One day soon I'll stitch you a whole new outfit. Any colour you like.",
                "That hat of yours has seen some weather. I could fix that. Later, later.");
            Talk(brick, () => Hud.OpenBench("Brick & Crew Builders", Builder.Jobs),
                "Brick! Me and the boys build anything. Coops, barns, you name it.",
                "Hire us and we'll come out to your farm the next day. It's done the morning after.",
                "Bring wood. We always need more wood.");
            Talk(nails, null,
                "Nails. I measure twice, cut once. Then cut again, because I measured wrong.",
                "The boss pays in sandwiches. Good sandwiches, though.");
            Talk(plank, null,
                "I'm Plank. Yes, really. My brother's called Beam.",
                "Did you know a barn's just a big box with opinions?");

            var keepers = new[] { hazel, poppy, ingrid, basil, hank, oakley, quill, bea, brick };
            int[] homeOf = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            for (int i = 0; i < keepers.Length; i++)
            {
                if (keepers[i] == null) continue;
                var r = Keep(shops[i], keepers[i], Home(homeOf[i]), n++);
                _homes.Add((Home(homeOf[i]), keepers[i].displayName));
                if (keepers[i] == brick) r.Site = () => Builder.WorkDay ? Builder.SiteSpot(0) : (Vector2?)null;
            }
            // The crew live with Brick and work in his yard, or out on the job.
            var yard = shops[8];
            int crew = 1;
            foreach (var worker in new[] { nails, plank })
            {
                if (worker == null) continue;
                int me = crew++;
                var r = new Resident
                {
                    Npc = worker, HomeDoor = Home(9), Work = yard, WorkSpot = yard.RoomOrigin + new Vector2(me == 1 ? 1.6f : 6.4f, 2.1f),
                    Arrive = 8.7f + 0.1f * me, GoHome = 17.2f + 0.1f * me,
                    Site = () => Builder.WorkDay ? Builder.SiteSpot(me) : (Vector2?)null,
                };
                Prepare(r);
            }
        }

        Shop AddShop(string name, string room, Vector2 door, bool front, int index)
        {
            var shop = new Shop { Name = name, Door = door, RoomOrigin = new Vector2(320f + index * 12f, 2f) };
            _shops.Add(shop);
            if (front)
            {
                var f = System.Array.Find(Fronts, x => x.name == name);
                bool wide = f.art == "shop_livestock" || f.art == "shop_builder";
                var sr = Prop(transform, f.art, door, new Vector2(wide ? 4.7f : 3.7f, 1.7f));
                if (sr != null) FarmDemoWorld.Tall(sr.gameObject);
            }

            var inside = new GameObject(name + " (inside)");
            inside.transform.SetParent(transform, false);
            inside.transform.position = shop.RoomOrigin;
            var floor = inside.AddComponent<SpriteRenderer>();
            floor.sprite = Art.Single(room, Vector2.zero);
            floor.sortingOrder = -30000;
            Wall(inside.transform, new Vector2(-0.1f, RoomHeight / 2f), new Vector2(0.4f, RoomHeight));
            Wall(inside.transform, new Vector2(RoomWidth + 0.1f, RoomHeight / 2f), new Vector2(0.4f, RoomHeight));
            Wall(inside.transform, new Vector2(RoomWidth / 2f, RoomHeight - 0.9f), new Vector2(RoomWidth, 1.8f));
            Wall(inside.transform, new Vector2(RoomWidth / 2f, -0.25f), new Vector2(RoomWidth, 0.5f));
            var counter = Prop(inside.transform, "counter", shop.RoomOrigin + new Vector2(RoomWidth / 2f, 2.9f), new Vector2(4f, 0.45f));
            if (counter != null) counter.name = "Counter";
            return shop;
        }

        static void Wall(Transform parent, Vector2 localCenter, Vector2 size)
        {
            var go = new GameObject("Wall");
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localCenter;
            go.AddComponent<BoxCollider2D>().size = size;
        }

        static SpriteRenderer Prop(Transform parent, string art, Vector2 at, Vector2 colliderSize)
        {
            var sprite = Art.Single(art);
            if (sprite == null) return null;
            var go = new GameObject(art);
            go.transform.SetParent(parent, false);
            go.transform.position = at;
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            go.AddComponent<YSort>();
            var box = go.AddComponent<BoxCollider2D>();
            box.size = colliderSize;
            box.offset = new Vector2(0f, colliderSize.y * 0.5f);
            return sr;
        }

        // Lamps along the street, and trees and berry bushes about the place.
        void Decorate()
        {
            var parent = new GameObject("Market street").transform;
            parent.SetParent(transform, false);
            foreach (float x in new[] { 77.5f, 89.5f, 101.5f, 115.5f, 127.5f, 135.5f })
            {
                var lamp = Prop(parent, "lamp", new Vector2(x, 10.3f), new Vector2(0.3f, 0.25f));
                if (lamp != null) FarmDemoWorld.Tall(lamp.gameObject);
            }
            Prop(parent, "signpost", new Vector2(75.2f, 13.8f), new Vector2(0.3f, 0.25f));
            Prop(parent, "bench", new Vector2(108.5f, 9.2f), new Vector2(1.6f, 0.3f));
            Prop(parent, "fountain", new Vector2(120.5f, 6.5f), new Vector2(1.7f, 0.8f));
        }

        // A townsperson: they start the day at home (hidden) and the routine shows them.
        Npc Person(Transform parent, string sheet, string name, string[] lines)
        {
            var frames = Art.Directional(sheet, FarmDemoConfig.CharacterFrameWidth, FarmDemoConfig.CharacterFrameHeight);
            if (frames == null) return null;
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            FarmDemoWorld.AddShadow(go.transform, 1f);
            go.AddComponent<SpriteRenderer>();
            go.AddComponent<YSort>().isStatic = false;
            var box = go.AddComponent<BoxCollider2D>();
            box.size = new Vector2(0.6f, 0.3f);
            box.offset = new Vector2(0f, 0.15f);
            var npc = go.AddComponent<Npc>();
            npc.Init(name, lines ?? new[] { "Hello!" }, frames, _promptSprite);
            return npc;
        }

        static void Talk(Npc npc, System.Action after, params string[] lines)
        {
            if (npc == null) return;
            int next = 0;
            // The first chat is the hello; after that, a different line each time.
            npc.SetScript(() => new[] { lines[next == 0 ? next++ : 1 + (next++ - 1) % (lines.Length - 1)] }, after);
        }

        Resident Keep(Shop shop, Npc npc, Vector2 home, int order)
        {
            npc.talkRange = 1.8f;
            var r = new Resident
            {
                Npc = npc, HomeDoor = home, Work = shop, WorkSpot = shop.KeeperSpot,
                Arrive = OpenHour - 0.4f + order * 0.04f, GoHome = 17f + order * 0.08f,
            };
            shop.Keeper = r;
            shop.Owner = npc.displayName.Replace(" the Baker", "");
            Prepare(r);
            return r;
        }

        void Prepare(Resident r)
        {
            var y = r.Npc.GetComponent<YSort>();
            if (y != null) y.isStatic = false;
            r.Feet = r.Npc.GetComponent<Collider2D>();
            _residents.Add(r);
        }

        // ------------------------------------------------------------- routes

        // Townsfolk keep to the paths, around anything standing on them (the fountain, a bench).
        static bool Walkable(Vector2Int c, HashSet<Vector2Int> blocked) => FarmDemoWorld.IsPath(c) && !blocked.Contains(c);

        static HashSet<Vector2Int> BlockedPaths()
        {
            Physics2D.SyncTransforms();
            var blocked = new HashSet<Vector2Int>();
            var b = FarmDemoWorld.OutdoorBounds;
            for (int x = (int)b.xMin; x < (int)b.xMax; x++)
            for (int y = (int)b.yMin; y < (int)b.yMax; y++)
            {
                var c = new Vector2Int(x, y);
                if (!FarmDemoWorld.IsPath(c)) continue;
                foreach (var col in Physics2D.OverlapBoxAll(new Vector2(x + 0.5f, y + 0.5f), new Vector2(0.6f, 0.6f), 0f))
                {
                    if (col.isTrigger || col.GetComponent<Npc>() != null) continue;
                    if (col.attachedRigidbody != null) continue;    // the player, slimes, critters
                    blocked.Add(c);
                    break;
                }
            }
            return blocked;
        }

        /// <summary>A walk along the paths from one spot to another (both just off a path is fine).</summary>
        static List<Vector2> FindRoute(Vector2 from, Vector2 to, HashSet<Vector2Int> blocked)
        {
            var start = Nearest(from, blocked);
            var goal = Nearest(to, blocked);
            var route = new List<Vector2> { from };
            if (start == null || goal == null) { route.Add(to); return route; }

            // Distances back from the goal, then walk downhill from the start, going straight where we can.
            var dist = new Dictionary<Vector2Int, int> { [goal.Value] = 0 };
            var queue = new Queue<Vector2Int>();
            queue.Enqueue(goal.Value);
            var steps = new[] { Vector2Int.right, Vector2Int.left, Vector2Int.up, Vector2Int.down };
            while (queue.Count > 0)
            {
                var c = queue.Dequeue();
                if (c == start.Value) break;
                foreach (var s in steps)
                {
                    var nc = c + s;
                    if (dist.ContainsKey(nc) || !Walkable(nc, blocked)) continue;
                    dist[nc] = dist[c] + 1;
                    queue.Enqueue(nc);
                }
            }
            if (!dist.ContainsKey(start.Value)) { route.Add(to); return route; }

            var cell = start.Value;
            var heading = Vector2Int.zero;
            var cells = new List<Vector2Int> { cell };
            while (cell != goal.Value)
            {
                Vector2Int best = cell;
                int bestD = dist[cell];
                foreach (var s in heading == Vector2Int.zero ? steps : new[] { heading, steps[0], steps[1], steps[2], steps[3] })
                    if (dist.TryGetValue(cell + s, out int d) && d < bestD) { bestD = d; best = cell + s; }
                if (best == cell) break;
                heading = best - cell;
                cell = best;
                cells.Add(cell);
            }
            // Keep only the corners. Walk down the middle of two-wide paths, roughly.
            for (int i = 0; i < cells.Count; i++)
            {
                bool corner = i == 0 || i == cells.Count - 1 || cells[i] - cells[i - 1] != cells[i + 1] - cells[i];
                if (corner) route.Add(new Vector2(cells[i].x + 0.5f, cells[i].y + 0.5f));
            }
            route.Add(to);
            return route;
        }

        static Vector2Int? Nearest(Vector2 at, HashSet<Vector2Int> blocked)
        {
            var c = new Vector2Int(Mathf.FloorToInt(at.x), Mathf.FloorToInt(at.y));
            for (int r = 0; r <= 4; r++)
            for (int dx = -r; dx <= r; dx++)
            for (int dy = -r; dy <= r; dy++)
            {
                if (Mathf.Max(Mathf.Abs(dx), Mathf.Abs(dy)) != r) continue;
                var n = c + new Vector2Int(dx, dy);
                if (Walkable(n, blocked)) return n;
            }
            return null;
        }

        static float Length(List<Vector2> route)
        {
            float len = 0f;
            for (int i = 1; i < route.Count; i++) len += Vector2.Distance(route[i - 1], route[i]);
            return len;
        }

        static Vector2 Along(List<Vector2> route, float distance, out Vector2 heading)
        {
            heading = Vector2.down;
            for (int i = 1; i < route.Count; i++)
            {
                float seg = Vector2.Distance(route[i - 1], route[i]);
                if (seg <= 0f) continue;
                heading = route[i] - route[i - 1];
                if (distance <= seg) return Vector2.Lerp(route[i - 1], route[i], distance / seg);
                distance -= seg;
            }
            return route[route.Count - 1];
        }

        HashSet<Vector2Int> _blocked;

        void RouteEveryone()
        {
            _blocked = BlockedPaths();
            foreach (var r in _residents)
            {
                Vector2 work = r.Work != null ? r.Work.Door + new Vector2(0f, -0.4f) : r.WorkSpot;
                r.Route = FindRoute(r.HomeDoor + new Vector2(0f, -0.4f), work, _blocked);
                r.Length = Length(r.Route);
            }
            _routed = true;
        }

        // ------------------------------------------------------------- every frame

        void Update()
        {
            if (!_routed) RouteEveryone();
            foreach (var r in _residents) Schedule(r);
            Doors();
        }

        // Where each townsperson is depends only on the time of day, so loading a save or sleeping just works.
        void Schedule(Resident r)
        {
            if (r.Npc == null || r.Route == null) return;
            if (ReferenceEquals(Hud.Speaker, r.Npc)) return;     // finish the chat first

            // Out on a job today?
            var site = r.Site?.Invoke();
            var route = r.Route;
            float length = r.Length;
            if (site != null)
            {
                if (r.SiteFor != site)
                {
                    r.SiteRoute = FindRoute(r.HomeDoor + new Vector2(0f, -0.4f), site.Value, _blocked);
                    r.SiteLength = Length(r.SiteRoute);
                    r.SiteFor = site;
                }
                route = r.SiteRoute;
                length = r.SiteLength;
            }

            float perHour = WalkSpeed * Settings.DayLength / (GameClock.EndHour - GameClock.StartHour);
            float travel = length / perHour;
            float leave = Mathf.Max(GameClock.StartHour + 0.2f, r.Arrive - travel);
            float hour = GameClock.Hour;
            bool inShop = r.Work != null && site == null;

            r.AtWork = false;
            if (hour < leave || hour >= r.GoHome + travel)
            {
                Show(r, false);                           // at home
            }
            else if (hour < leave + travel)
            {
                Walk(r, route, (hour - leave) * perHour, false);   // on the way to work
            }
            else if (hour < r.GoHome)
            {
                r.AtWork = true;
                Stand(r, inShop ? r.WorkSpot : route[route.Count - 1]);
            }
            else
            {
                Walk(r, route, length - (hour - r.GoHome) * perHour, true);    // on the way home
            }
        }

        static void Show(Resident r, bool shown)
        {
            if (r.Npc.gameObject.activeSelf != shown) r.Npc.gameObject.SetActive(shown);
        }

        static void Walk(Resident r, List<Vector2> route, float distance, bool homeward)
        {
            Show(r, true);
            var at = Along(route, Mathf.Max(0f, distance), out var heading);
            bool back = homeward;
            r.Npc.transform.position = at;
            r.Npc.Walking = true;
            r.Npc.WalkFacing = Art.FacingToward(back ? -heading : heading);
            if (r.Feet != null) r.Feet.enabled = false;
        }

        static void Stand(Resident r, Vector2 at)
        {
            Show(r, true);
            r.Npc.transform.position = at;
            r.Npc.Walking = false;
            if (r.Feet != null) r.Feet.enabled = true;
        }

        // ------------------------------------------------------------- doors

        void Doors()
        {
            _prompt.enabled = false;
            var player = PlayerController.Instance;
            if (player == null || Hud.Busy || player.Locked || BlimpBee.Riding) return;
            Vector2 feet = player.transform.position;
            float bob = Mathf.Sin(Time.time * 5f) > 0f ? 1f / FarmDemoConfig.PixelsPerUnit : 0f;

            if (Inside)
            {
                // Step on the door mat to leave.
                var shop = Current;
                if (feet.y < shop.RoomOrigin.y + 0.45f && Mathf.Abs(feet.x - shop.RoomDoor.x) < 0.7f)
                    Hud.Transition(() => GoOutside(shop));
                return;
            }
            if (Home.Inside || Mine.Inside || Cavern.Inside || player.Facing != Facing.Up) return;

            foreach (var shop in _shops)
            {
                if (Vector2.Distance(feet, shop.Door + new Vector2(0f, -0.3f)) >= 0.8f) continue;
                if (!shop.Open)
                {
                    bool away = shop.Keeper != null && shop.Keeper.Site != null && shop.Keeper.Site() != null;
                    Hud.SetPrompt(away ? $"{shop.Name} is closed today. The crew's out on a job."
                        : $"{shop.Name} is closed. {shop.Owner} opens up around {OpenHour:0} AM.");
                    return;
                }
                _prompt.enabled = true;
                _prompt.transform.position = shop.Door + new Vector2(0f, 2.3f + bob);
                Hud.SetPrompt($"E  Go into {shop.Name}");
                if (GameInput.TalkPressed()) Hud.Transition(() => GoInside(shop));
                return;
            }
            foreach (var (door, owner) in _homes)
                if (Vector2.Distance(feet, door + new Vector2(0f, -0.3f)) < 0.8f)
                {
                    Hud.SetPrompt($"{owner}'s house. It's locked.");
                    return;
                }
        }

        static void GoInside(Shop shop)
        {
            Current = shop;
            Home.Move(shop.RoomDoor + new Vector2(0f, 0.6f), Facing.Up,
                new Rect(shop.RoomOrigin.x, shop.RoomOrigin.y, RoomWidth, RoomHeight), IndoorBackground);
        }

        static void GoOutside(Shop shop)
        {
            Current = null;
            Home.Move(shop.Door + new Vector2(0f, -0.6f), Facing.Down, FarmDemoWorld.OutdoorBounds, Home.OutdoorBackground);
        }
    }

    /// <summary>What each shop sells and buys.</summary>
    public static class Shops
    {
        static bool IsFlower(ItemDef i) => i == Items.Tulip || i == Items.Sunflower || i == Items.Lavender;
        static bool IsMeal(ItemDef i) => i == Items.FriedEgg || i == Items.TurnipSoup || i == Items.StrawberryJam || i == Items.FishStew ||
                                         i == Items.PumpkinPie || i == Items.HoneyCake || i == Items.Cheese || i == Items.GoatCheese;
        static bool IsFish(ItemDef i) => i == Items.Bluegill || i == Items.Carp || i == Items.GoldenTrout;

        public static readonly ShopDef Bakery = new ShopDef
        {
            Title = "Mabel's Bakery", Empty = "Nothing to sell. I'll buy just about anything!",
            Stock = () => new List<(ItemDef, int)> { (Items.FriedEgg, 120), (Items.StrawberryJam, 450), (Items.HoneyCake, 500), (Items.PumpkinPie, 650) },
            Wants = item => true,
        };

        public static readonly ShopDef Seeds = new ShopDef
        {
            Title = "Hazel's Seeds", Empty = "I only sell. Mabel buys your crops, or Basil pays a bit more.",
            Stock = () =>
            {
                var stock = new List<(ItemDef, int)>();
                foreach (var crop in CropDef.All)
                    if (crop.InSeason(Seasons.Current) && !IsFlower(crop.Produce)) stock.Add((crop.Seeds, crop.SeedPrice));
                foreach (var tree in FruitKind.All) stock.Add((tree.Sapling, tree.Price));
                return stock;
            },
        };

        public static readonly ShopDef Flowers = new ShopDef
        {
            Title = "Poppy's Flowers", Empty = "Bring me tulips, sunflowers and lavender!", Markup = 1.2f,
            Stock = () =>
            {
                var stock = new List<(ItemDef, int)>();
                foreach (var crop in CropDef.All)
                    if (crop.InSeason(Seasons.Current) && IsFlower(crop.Produce)) stock.Add((crop.Seeds, crop.SeedPrice));
                stock.Add((Items.BeeHouse, 300));
                return stock;
            },
            Wants = IsFlower,
        };

        public static readonly ShopDef Livestock = new ShopDef
        {
            Title = "Hank's Livestock", Empty = "Bring me eggs, milk and cheese.", Markup = 1.1f,
            Stock = () => new List<(ItemDef, int)>
            {
                (Items.ChickenFeed, 10), (Items.Chicken, 150), (Items.Hay, 12), (Items.Cow, 600), (Items.Goat, 450), (Items.Pig, 800),
            },
            Wants = i => i == Items.Egg || i == Items.LargeEgg || i == Items.Milk || i == Items.GoatMilk || i == Items.Cheese ||
                         i == Items.GoatCheese || i == Items.Truffle,
        };

        public static readonly ShopDef Restaurant = new ShopDef
        {
            Title = "The Basil Leaf", Empty = "Fresh crops, eggs, milk, fish and fruit, please!", Markup = 1.2f,
            Stock = () => new List<(ItemDef, int)>
            {
                (Items.FriedEgg, 120), (Items.TurnipSoup, 240), (Items.FishStew, 270), (Items.HoneyCake, 500), (Items.PumpkinPie, 650),
            },
            Wants = i => !IsMeal(i) && (Food.Healing(i) > 0 || IsFish(i) || FruitKind.ForFruit(i) != null || i == Items.Pumpkin || i == Items.Melon),
        };
    }

    /// <summary>
    /// Brick and his crew build onto your farm. Hire them in their yard on the market
    /// street; the next day the three of them walk out to the farm and work all day,
    /// and it's done the morning after. Kept in the save.
    /// </summary>
    public static class Builder
    {
        public static int CoopLevel, BarnLevel;
        /// <summary>The job underway: "" none, "coop" or "barn".</summary>
        public static string Project = "";
        /// <summary>Mornings until it's done: 2 the day you hire them, 1 on the day they're out working.</summary>
        public static int DaysLeft;

        public static bool Busy => Project != "";
        public static bool WorkDay => Busy && DaysLeft == 1;

        public static void Reset()
        {
            CoopLevel = BarnLevel = 0;
            Project = "";
            DaysLeft = 0;
        }

        /// <summary>Where the crew stand while they work (0 is Brick).</summary>
        public static Vector2 SiteSpot(int who) => Project == "coop"
            ? new Vector2(25.5f, 15.4f + who * 1.8f)
            : new Vector2(6.5f + who * 1.5f, 10.4f);

        public static void Morning()
        {
            if (!Busy) return;
            if (--DaysLeft > 0)
            {
                Hud.Toast(Project == "coop" ? "Brick's crew are coming out to work on your coop today." : "Brick's crew are coming out to work on your barn today.", 4f);
                return;
            }
            if (Project == "coop") { CoopLevel = 1; Hud.Toast($"Your bigger coop is done! It holds {Animals.MaxChickens} hens now.", 4f); }
            else { BarnLevel = 1; Hud.Toast($"Your bigger barn is done! It holds {Barn.MaxBeasts} animals now.", 4f); }
            Project = "";
        }

        static string Label(string job, bool built) =>
            built ? "Built!" : Project == job ? (DaysLeft >= 2 ? "Hired! The crew comes out tomorrow" : "The crew are at work on it") : "The crew are busy with another job";

        public static readonly Recipe[] Jobs =
        {
            new Recipe
            {
                Name = "Bigger Coop", Icon = Items.Chicken, Verb = "Hire",
                Text = "Room for 8 hens instead of 4.",
                Needs = new[] { (Items.Wood, 30) }, Gold = 400,
                Owned = () => CoopLevel >= 1 || Busy,
                OwnedLabel = () => Label("coop", CoopLevel >= 1),
                Apply = () => { Project = "coop"; DaysLeft = 2; },
                Done = "Hired! Brick's crew will be at your coop tomorrow.",
            },
            new Recipe
            {
                Name = "Bigger Barn", Icon = Items.Cow, Verb = "Hire",
                Text = "Room for 10 animals instead of 6.",
                Needs = new[] { (Items.Wood, 50) }, Gold = 700,
                Owned = () => BarnLevel >= 1 || Busy,
                OwnedLabel = () => Label("barn", BarnLevel >= 1),
                Apply = () => { Project = "barn"; DaysLeft = 2; },
                Done = "Hired! Brick's crew will be at your barn tomorrow.",
            },
        };
    }
}
