using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// A villager who breathes, turns to look at you when you're close, shows an
    /// "E" prompt, and says their lines when you press E. Press F with an item
    /// picked to give it as a gift (see Friendship).
    /// </summary>
    public class Npc : MonoBehaviour
    {
        public string displayName = "Villager";
        [TextArea] public string[] lines = { "Hello!" };
        public float talkRange = 1.4f;
        public float idleFps = 2f;

        static readonly List<Npc> All = new List<Npc>();

        System.Func<string[]> _script;     // optional: pick lines at talk time
        System.Action _afterTalk;           // optional: runs once the last line is read

        /// <summary>Choose what to say each time you talk, and what happens after.</summary>
        public void SetScript(System.Func<string[]> lines, System.Action afterTalk)
        {
            _script = lines;
            _afterTalk = afterTalk;
        }

        Sprite[][] _frames;            // [Facing][frame]
        SpriteRenderer _sprite;
        SpriteRenderer _prompt;
        Facing _facing = Facing.Down;
        float _clock;
        float _lookAwayTimer;

        public void Init(string name, string[] says, Sprite[][] frames, Sprite promptSprite)
        {
            displayName = name;
            lines = says;
            _frames = frames;
            _sprite = GetComponent<SpriteRenderer>();

            var prompt = new GameObject("Talk prompt").AddComponent<SpriteRenderer>();
            prompt.transform.SetParent(transform, false);
            prompt.sprite = promptSprite;
            prompt.sortingOrder = 32000;     // always on top
            prompt.enabled = false;
            _prompt = prompt;
            _clock = Random.value;
        }

        void OnEnable() => All.Add(this);
        void OnDisable() => All.Remove(this);

        void Update()
        {
            if (_frames == null) return;
            var player = PlayerController.Instance;
            float distance = player != null ? Vector2.Distance(player.transform.position, transform.position) : float.MaxValue;
            bool talkingToMe = ReferenceEquals(Hud.Speaker, this);

            // Turn toward the player while they're nearby, then drift back to facing down.
            if (distance < talkRange * 1.6f)
            {
                _facing = Art.FacingToward((Vector2)player.transform.position - (Vector2)transform.position);
                _lookAwayTimer = 1.5f;
            }
            else if ((_lookAwayTimer -= Time.deltaTime) <= 0f)
            {
                _facing = Facing.Down;
            }

            _clock += Time.deltaTime;
            var set = _frames[(int)_facing];
            _sprite.sprite = set[Mathf.FloorToInt(_clock * idleFps) % set.Length];

            bool closest = distance < talkRange && Closest(player) == this && (!Hud.Busy || talkingToMe);
            _prompt.enabled = closest && !talkingToMe;
            // Bob the prompt by one whole pixel so it stays crisp.
            float bob = Mathf.Sin(Time.time * 5f) > 0f ? 1f / FarmDemoConfig.PixelsPerUnit : 0f;
            _prompt.transform.localPosition = new Vector3(0f, 1.75f + bob, 0f);

            var held = Inventory.SelectedItem;
            bool canGift = closest && !talkingToMe && !Hud.Busy && Friendship.CanGift(displayName, held);
            if (canGift) Hud.SetPrompt($"F  Give the {held.Name.ToLower()} to {displayName.Split(' ')[0]}");

            if (closest && GameInput.TalkPressed())
            {
                if (talkingToMe) Hud.AdvanceDialogue();
                else
                {
                    Friendship.Talked(displayName);
                    var after = _afterTalk;
                    var reward = Friendship.RewardIfDue(displayName);
                    Hud.OpenDialogue(this, displayName, _script != null ? _script() : lines,
                        after == null && reward == null ? null : (System.Action)(() => { after?.Invoke(); reward?.Invoke(); }));
                }
            }
            else if (canGift && GameInput.FishPressed())
            {
                string reply = Friendship.Gift(displayName, held);
                if (reply != null) Hud.OpenDialogue(this, displayName, new[] { reply }, Friendship.RewardIfDue(displayName));
            }
            else if (talkingToMe && distance > talkRange + 0.75f)
            {
                Hud.CloseDialogue();   // walked away mid-chat
            }
        }

        static Npc Closest(PlayerController player)
        {
            Npc best = null;
            float bestDistance = float.MaxValue;
            foreach (var npc in All)
            {
                float d = Vector2.Distance(player.transform.position, npc.transform.position);
                if (d < bestDistance) { bestDistance = d; best = npc; }
            }
            return best;
        }
    }
}
