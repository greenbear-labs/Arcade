using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// Night, and the dark. A soft layer of shade is laid over the world in front of
    /// the camera: a deep blue at night, and pitch black in the dark cave. Things that
    /// glow (the Enfield, the town lamps, your own little circle of sight in the dark)
    /// clear the shade around them, so you see the ground lit up round them.
    /// </summary>
    [DefaultExecutionOrder(100)]     // after the camera has moved
    public class Lighting : MonoBehaviour
    {
        const int TexelsPerTile = 4;
        const int SortingOrder = 31000;     // over the world, under the prompts

        /// <summary>Something that glows: where it is, and how far its light reaches (0 = off right now).</summary>
        public class Light
        {
            public Object Owner;          // the light goes out with it
            public System.Func<Vector2> At;
            public System.Func<float> Radius;
        }

        static readonly List<Light> Lights = new List<Light>();

        public static Light Add(Object owner, System.Func<Vector2> at, System.Func<float> radius)
        {
            var light = new Light { Owner = owner, At = at, Radius = radius };
            Lights.Add(light);
            return light;
        }


        static readonly Color32 NightTint = new Color32(13, 15, 51, 255);
        static readonly Color32 CaveTint = new Color32(4, 3, 8, 255);

        SpriteRenderer _sprite;
        Texture2D _texture;
        Color32[] _pixels;
        int _w, _h;
        readonly List<(Vector2 at, float r)> _lit = new List<(Vector2, float)>();

        void Awake()
        {
            _sprite = gameObject.AddComponent<SpriteRenderer>();
            _sprite.sortingOrder = SortingOrder;
            _sprite.enabled = false;
        }

        /// <summary>How deep the shade is (0 to 1) and its colour, wherever you are.</summary>
        static float Ambient(out Color32 tint)
        {
            if (DarkCave.Inside) { tint = CaveTint; return 0.97f; }
            tint = NightTint;
            return 0.5f * GameClock.Darkness;
        }

        void LateUpdate()
        {
            var cam = Camera.main;
            float ambient = Ambient(out var tint);
            if (cam == null || ambient <= 0.001f) { _sprite.enabled = false; return; }

            // Cover the view plus a tile's margin, snapped to whole tiles so the shade doesn't swim.
            float halfH = cam.orthographicSize, halfW = halfH * cam.aspect;
            Vector2 c = cam.transform.position;
            int x0 = Mathf.FloorToInt(c.x - halfW) - 1, y0 = Mathf.FloorToInt(c.y - halfH) - 1;
            int w = (Mathf.CeilToInt(c.x + halfW) + 1 - x0) * TexelsPerTile, h = (Mathf.CeilToInt(c.y + halfH) + 1 - y0) * TexelsPerTile;
            if (_texture == null || w != _w || h != _h) Resize(w, h);
            transform.position = new Vector3(x0, y0, 0f);

            // The lights that are on and near enough to matter.
            _lit.Clear();
            var view = new Rect(x0, y0, w / (float)TexelsPerTile, h / (float)TexelsPerTile);
            Lights.RemoveAll(l => l.Owner == null);
            foreach (var light in Lights)
            {
                float r = light.Radius();
                if (r <= 0f) continue;
                Vector2 at = light.At();
                if (at.x + r < view.xMin || at.x - r > view.xMax || at.y + r < view.yMin || at.y - r > view.yMax) continue;
                _lit.Add((at, r));
            }

            float step = 1f / TexelsPerTile;
            for (int py = 0; py < h; py++)
            {
                float wy = y0 + (py + 0.5f) * step;
                for (int px = 0; px < w; px++)
                {
                    float wx = x0 + (px + 0.5f) * step;
                    float bright = 0f;
                    foreach (var (at, r) in _lit)
                    {
                        float dx = wx - at.x, dy = wy - at.y, d2 = dx * dx + dy * dy;
                        if (d2 >= r * r) continue;
                        // Full light in the middle, fading out smoothly to the edge.
                        float t = Mathf.Sqrt(d2) / r;
                        float b = t < 0.45f ? 1f : 1f - Mathf.SmoothStep(0f, 1f, (t - 0.45f) / 0.55f);
                        if (b > bright) bright = b;
                    }
                    tint.a = (byte)(255f * ambient * (1f - bright));
                    _pixels[py * w + px] = tint;
                }
            }
            _texture.SetPixels32(_pixels);
            _texture.Apply(false);
            _sprite.enabled = true;
        }

        void Resize(int w, int h)
        {
            if (_texture != null) { Destroy(_sprite.sprite); Destroy(_texture); }
            _w = w;
            _h = h;
            _texture = new Texture2D(w, h, TextureFormat.RGBA32, false) { filterMode = FilterMode.Bilinear, wrapMode = TextureWrapMode.Clamp };
            _pixels = new Color32[w * h];
            _sprite.sprite = Sprite.Create(_texture, new Rect(0, 0, w, h), Vector2.zero, TexelsPerTile);
        }
    }
}
