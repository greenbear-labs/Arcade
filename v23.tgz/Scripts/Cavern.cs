using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

namespace FarmDemo
{
    /// <summary>
    /// The crystal cave, the second cave in the mountain cliff. No floors to climb
    /// down: one big cave of tunnels and rooms to explore, with an underground pool,
    /// crystals, glowing mushrooms and a few slimes. Somewhere at the end of a
    /// winding tunnel there's an old chest full of gems (it opens once). Like the
    /// mine, it's built off to the side of the map.
    /// </summary>
    public class Cavern : MonoBehaviour
    {
        // Outside: the cave sprite stands with its bottom-centre here.
        public static readonly Vector2 Mouth = new Vector2(-7f, 22f);
        // Inside: the map below, its bottom-left corner here.
        public static readonly Vector2 RoomOrigin = new Vector2(270f, 2f);
        const int GemsInChest = 5;

        // # rock, ~ water, . floor, * crystals, m mushrooms, C the chest, S a slime, X where you come in.
        static readonly string[] Map =
        {
            "########################################",
            "#..C.#####################.....*########",
            "#.m..####m......m.....m####......*######",
            "##..#####...........S........*.......*##",
            "##.######..m....##.....m...#....S.....##",
            "##.######......####........##.....*...##",
            "##......##..........m.......##........##",
            "#######.###....m.......##....###...*..##",
            "#######..######...S....##.....###..#####",
            "########.######............m....##..####",
            "###......##########......#########..####",
            "##...~~~..###########..############..###",
            "#...~~~~~..##########..##########....*##",
            "#..~~~~~~~..#########..#########..*....#",
            "#..~~~~~~..S.####......####.........*..#",
            "#...~~~~...............##.....S..*.....#",
            "##....m.........#......................#",
            "###......####...#......#...####.......##",
            "#####..########.#......#.#######..*..###",
            "##########......#......##########...####",
            "################....X..#################",
            "########################################",
        };

        static readonly Color32 CaveBackground = new Color32(0x0e, 0x0c, 0x14, 0xff);
        static int Width => Map[0].Length;
        static int Height => Map.Length;

        public static bool Inside { get; private set; }
        /// <summary>Has the hidden chest been opened? (Kept in the save.)</summary>
        public static bool ChestOpened
        {
            get => _instance != null && _instance._chestOpened;
            set { if (_instance != null) { _instance._chestOpened = value; _instance.RefreshChest(); } }
        }

        static Cavern _instance;
        bool _chestOpened;
        Vector2 _arrival, _chestSpot;
        SpriteRenderer _chest, _mouthPrompt;
        Sprite[] _chestFrames, _slimeFrames;
        readonly List<Vector2> _slimeSpots = new List<Vector2>();
        Transform _slimes;

        static Vector2 Local(int col, int row) => RoomOrigin + new Vector2(col, Height - 1 - row);

        public void Build(Transform parent)
        {
            _instance = this;
            Inside = false;
            _slimeFrames = Art.Strip("slime", 16, 16);
            _chestFrames = Art.Strip("cavechest", 16, 16);

            // Outside: the mouth in the cliff.
            var cave = new GameObject("Crystal cave (outside)");
            cave.transform.SetParent(parent, false);
            cave.transform.position = Mouth;
            cave.AddComponent<SpriteRenderer>().sprite = Art.Single("cave2");
            cave.AddComponent<YSort>();
            FarmDemoWorld.Tall(cave);
            var rock = cave.AddComponent<BoxCollider2D>();
            rock.size = new Vector2(2.7f, 1.3f);
            rock.offset = new Vector2(0f, 0.65f);
            _mouthPrompt = new GameObject("Prompt").AddComponent<SpriteRenderer>();
            _mouthPrompt.transform.SetParent(transform, false);
            _mouthPrompt.sprite = Art.Single("key_e", new Vector2(0.5f, 0f));
            _mouthPrompt.sortingOrder = 32000;
            _mouthPrompt.enabled = false;

            // Inside: rock, water and floor as tiles; the rock and water are solid.
            var tiles = Art.Strip("cave_tiles", 16, 16, new Vector2(0.5f, 0.5f));
            var grid = new GameObject("Crystal cave (inside)", typeof(Grid));
            grid.transform.SetParent(parent, false);
            grid.transform.position = RoomOrigin;
            var floor = NewTilemap(grid.transform, "Floor", -30000);
            var walls = NewTilemap(grid.transform, "Rock (solid)", -29999);
            walls.gameObject.AddComponent<TilemapCollider2D>();
            Tile Make(int i, bool solid)
            {
                var t = ScriptableObject.CreateInstance<Tile>();
                t.sprite = tiles != null && i < tiles.Length ? tiles[i] : null;
                t.colliderType = solid ? Tile.ColliderType.Grid : Tile.ColliderType.None;
                return t;
            }
            Tile floorA = Make(0, false), floorB = Make(1, false), wall = Make(2, true), water = Make(3, true);
            var crystal = Art.Strip("crystal", 16, 16);
            var mushroom = Art.Single("mushroom");
            var rng = new System.Random(5);

            for (int row = 0; row < Height; row++)
            for (int col = 0; col < Width; col++)
            {
                char c = Map[row][col];
                var cell = new Vector3Int(col, Height - 1 - row, 0);
                if (c == '#') { walls.SetTile(cell, wall); continue; }
                if (c == '~') { walls.SetTile(cell, water); continue; }
                floor.SetTile(cell, rng.Next(4) == 0 ? floorB : floorA);
                Vector2 at = Local(col, row) + new Vector2(0.5f, 0.1f);
                if (c == '*' && crystal != null) Decor(grid.transform, crystal[rng.Next(crystal.Length)], at, true);
                else if (c == 'm' && mushroom != null) Decor(grid.transform, mushroom, at, false);
                else if (c == 'S') _slimeSpots.Add(at + new Vector2(0f, 0.1f));
                else if (c == 'X') _arrival = at + new Vector2(0f, 0.3f);
                else if (c == 'C')
                {
                    _chestSpot = at;
                    _chest = Decor(grid.transform, _chestFrames?[0], at, true);
                }
            }
            GameClock.NewDay += Morning;
        }

        static Tilemap NewTilemap(Transform parent, string name, int order)
        {
            var go = new GameObject(name, typeof(Tilemap), typeof(TilemapRenderer));
            go.transform.SetParent(parent, false);
            go.GetComponent<TilemapRenderer>().sortingOrder = order;
            return go.GetComponent<Tilemap>();
        }

        static SpriteRenderer Decor(Transform parent, Sprite sprite, Vector2 at, bool solid)
        {
            var go = new GameObject(sprite != null ? sprite.name : "Decor");
            go.transform.SetParent(parent, false);
            go.transform.position = at;
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            go.AddComponent<YSort>();
            if (solid)
            {
                var box = go.AddComponent<BoxCollider2D>();
                box.size = new Vector2(0.8f, 0.45f);
                box.offset = new Vector2(0f, 0.22f);
            }
            return sr;
        }

        void RefreshChest()
        {
            if (_chest != null && _chestFrames != null) _chest.sprite = _chestFrames[_chestOpened ? 1 : 0];
        }

        void OnDestroy()
        {
            GameClock.NewDay -= Morning;
            if (_instance == this) { _instance = null; Inside = false; }
        }

        // You always wake up at home.
        void Morning()
        {
            Inside = false;
            ClearSlimes();
        }

        void ClearSlimes()
        {
            if (_slimes != null) Destroy(_slimes.gameObject);
            _slimes = null;
        }

        void GoIn()
        {
            Inside = true;
            ClearSlimes();
            _slimes = new GameObject("Cave slimes").transform;
            _slimes.SetParent(transform, false);
            foreach (var spot in _slimeSpots)
            {
                var slime = FarmDemoWorld.SpawnSlime(_slimes, spot, _slimeFrames);
                if (slime == null) continue;
                slime.health = 3;
                slime.tint = new Color(0.75f, 0.6f, 1f);
            }
            RefreshChest();
            Home.Move(_arrival, Facing.Up, new Rect(RoomOrigin.x, RoomOrigin.y, Width, Height), CaveBackground);
            Hud.Toast("The crystal cave. It goes a long way back...", 2.5f);
        }

        static void Leave()
        {
            Inside = false;
            if (_instance != null) _instance.ClearSlimes();
            Home.Move(Mouth + new Vector2(0f, -0.6f), Facing.Down, FarmDemoWorld.OutdoorBounds, Home.OutdoorBackground);
        }

        /// <summary>Fainted in the cave: Dot finds you and walks you out.</summary>
        public static void CarryOut()
        {
            Hud.Toast("You fainted! Dot heard the echo and walked you out of the cave.", 3.5f);
            Hud.Transition(Leave);
        }

        void Update()
        {
            _mouthPrompt.enabled = false;
            var player = PlayerController.Instance;
            if (player == null || Hud.Busy || player.Locked || player.IsAttacking) return;
            Vector2 feet = player.transform.position;

            if (!Inside)
            {
                if (Home.Inside || Mine.Inside || Town.Inside) return;
                if (Vector2.Distance(feet, Mouth + new Vector2(0f, -0.3f)) > 0.8f || player.Facing != Facing.Up) return;
                _mouthPrompt.enabled = true;
                _mouthPrompt.transform.position = Mouth + new Vector2(0f, 2.8f + (Mathf.Sin(Time.time * 5f) > 0f ? 1f / FarmDemoConfig.PixelsPerUnit : 0f));
                Hud.SetPrompt("E  Go into the crystal cave");
                if (GameInput.TalkPressed()) Hud.Transition(GoIn);
                return;
            }

            // The way out, where you came in.
            if (Vector2.Distance(feet, _arrival) < 0.8f && player.Facing == Facing.Down)
            {
                Hud.SetPrompt("E  Leave the cave");
                if (GameInput.TalkPressed()) Hud.Transition(Leave);
                return;
            }

            // The hidden chest.
            Vector2 ahead = feet + new Vector2(0f, 0.15f) + Art.Dir(player.Facing) * 0.7f;
            if (Vector2.Distance(ahead, _chestSpot + new Vector2(0f, 0.25f)) < 0.7f)
            {
                if (_chestOpened) { Hud.SetPrompt("An old chest. Empty now"); return; }
                Hud.SetPrompt("E  Open the old chest");
                if (!GameInput.TalkPressed()) return;
                if (!Inventory.HasRoomFor(Items.Gem)) { Hud.Toast("Your bag is full! Make room first.", 2.5f); return; }
                Inventory.Add(Items.Gem, GemsInChest);
                _chestOpened = true;
                RefreshChest();
                Hud.ShowPopup(Items.Gem.Icon, $"You found {GemsInChest} Gems!", "Someone hid these here long ago. Dot will be jealous.");
                return;
            }
        }
    }
}
