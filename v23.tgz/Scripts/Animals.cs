using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// The chicken coop next to the farmhouse, its fenced yard and feed trough,
    /// and your chickens. You start with one hen; Hank sells more (up to four, or eight in a bigger coop)
    /// and the feed. Each morning every hen eats one feed from the trough and
    /// lays an egg in the yard; a hen you pet every day sometimes lays a large one.
    /// F picks up eggs and fills the trough, E pets a hen. They sleep in the coop at night.
    /// </summary>
    public class Animals : MonoBehaviour
    {
        public const int TroughMax = 8;
        /// <summary>Hens the coop holds: 4, or 8 once Brick's crew have made it bigger.</summary>
        public static int MaxChickens => Builder.CoopLevel >= 1 ? 8 : 4;

        // The coop stands with its bottom centre here; its door opens into the yard below it.
        public static readonly Vector2 CoopSpot = new Vector2(28f, 19f);
        // Fence cells: x 25..30 along the bottom (y 13) and up both sides to the coop, with a gate on the left.
        const int FenceLeft = 25, FenceRight = 30, FenceBottom = 13, FenceTop = 19, GateY = 15;
        // Where hens wander and eggs land: the yard inside the fence.
        static readonly Rect Yard = new Rect(26.3f, 14.3f, 3.4f, 4.2f);
        static readonly Vector2 TroughSpot = new Vector2(26.9f, 17.4f);
        static readonly Vector2 CoopDoor = CoopSpot + new Vector2(0f, 0.1f);

        static readonly string[] Names = { "Nugget", "Henrietta", "Bok Choy", "Clucky", "Omelette", "Pecky" };

        static Animals _instance;
        readonly List<Chicken> _chickens = new List<Chicken>();
        readonly List<(GameObject go, ItemDef item)> _eggs = new List<(GameObject, ItemDef)>();
        Sprite[] _chickenFrames, _troughFrames;
        Sprite _heart;
        SpriteRenderer _trough;

        /// <summary>Days of feed in the trough: each hen eats one every morning.</summary>
        public static int Feed { get; private set; }
        public static bool CanBuyChicken => _instance != null && _instance._chickens.Count < MaxChickens;

        /// <summary>Is this tile part of the coop or its yard? (The hoe leaves it alone.)</summary>
        public static bool Covers(Vector2Int cell) =>
            cell.x >= FenceLeft - 1 && cell.x <= FenceRight + 1 && cell.y >= FenceBottom - 1 && cell.y <= FenceTop + 3;

        /// <summary>The hens and any eggs lying in the yard, for the save.</summary>
        public static void Export(List<SaveGame.HenState> hens, List<SaveGame.EggState> eggs)
        {
            if (_instance == null) return;
            foreach (var hen in _instance._chickens)
                hens.Add(new SaveGame.HenState { name = hen.Name, happiness = hen.Happiness, brown = hen.Brown });
            foreach (var (go, item) in _instance._eggs)
                eggs.Add(new SaveGame.EggState { item = item.Name, x = go.transform.position.x, y = go.transform.position.y });
        }

        /// <summary>Bring back saved hens, eggs and feed in place of the starting hen.</summary>
        public static void Import(int feed, List<SaveGame.HenState> hens, List<SaveGame.EggState> eggs)
        {
            if (_instance == null) return;
            Feed = Mathf.Clamp(feed, 0, TroughMax);
            _instance.RefreshTrough();
            foreach (var hen in _instance._chickens) Destroy(hen.gameObject);
            _instance._chickens.Clear();
            foreach (var h in hens)
            {
                if (_instance._chickens.Count >= MaxChickens) break;
                var hen = _instance.AddChicken(h.name, h.brown);
                hen.Happiness = Mathf.Clamp(h.happiness, 0, 5);
            }
            foreach (var e in eggs)
            {
                var item = Items.ByName(e.item);
                if (item != null) _instance.LayEgg(item, new Vector2(e.x, e.y));
            }
        }

        public static void BuyChicken()
        {
            if (!CanBuyChicken) return;
            var hen = _instance.AddChicken();
            hen.JustArrived = true;     // starts laying the morning after next
        }

        public void Build(Transform parent)
        {
            _instance = this;
            Feed = 3;
            _chickenFrames = Art.Strip("chicken", 16, 16);
            _troughFrames = Art.Strip("trough", 16, 16);
            _heart = Art.Strip("heart", 9, 8, new Vector2(0.5f, 0f))?[0];

            var coop = new GameObject("Coop");
            coop.transform.SetParent(parent, false);
            coop.transform.position = CoopSpot;
            coop.AddComponent<SpriteRenderer>().sprite = Art.Single("coop");
            coop.AddComponent<YSort>();
            FarmDemoWorld.Tall(coop);
            var walls = coop.AddComponent<BoxCollider2D>();
            walls.size = new Vector2(3.8f, 1.5f);
            walls.offset = new Vector2(0f, 0.85f);

            var fence = Art.Strip("fence", 16, 16);
            var fenceParent = new GameObject("Fence").transform;
            fenceParent.SetParent(parent, false);
            for (int x = FenceLeft; x <= FenceRight; x++) Fence(fenceParent, fence?[0], x, FenceBottom, true);
            for (int y = FenceBottom + 1; y <= FenceTop; y++)
            {
                if (y != GateY) Fence(fenceParent, fence?[1], FenceLeft, y, false);
                Fence(fenceParent, fence?[1], FenceRight, y, false);
            }

            var trough = new GameObject("Trough");
            trough.transform.SetParent(parent, false);
            trough.transform.position = TroughSpot;
            _trough = trough.AddComponent<SpriteRenderer>();
            trough.AddComponent<YSort>();
            var box = trough.AddComponent<BoxCollider2D>();
            box.size = new Vector2(0.85f, 0.35f);
            box.offset = new Vector2(0f, 0.25f);
            RefreshTrough();

            AddChicken();
            GameClock.NewDay += Morning;
        }

        static void Fence(Transform parent, Sprite sprite, int x, int y, bool across)
        {
            var go = new GameObject("Fence");
            go.transform.SetParent(parent, false);
            go.transform.position = new Vector2(x + 0.5f, y);
            go.AddComponent<SpriteRenderer>().sprite = sprite;
            go.AddComponent<YSort>();
            var box = go.AddComponent<BoxCollider2D>();
            box.size = across ? new Vector2(1f, 0.35f) : new Vector2(0.35f, 1f);
            box.offset = across ? new Vector2(0f, 0.2f) : new Vector2(0f, 0.5f);
        }

        Chicken AddChicken() => AddChicken(Names[_chickens.Count % Names.Length], _chickens.Count % 2 == 1);

        Chicken AddChicken(string name, bool brown)
        {
            var go = new GameObject("Chicken");
            go.transform.SetParent(transform, false);
            go.transform.position = RandomYardSpot();
            var shadow = new GameObject("Shadow").AddComponent<SpriteRenderer>();
            shadow.transform.SetParent(go.transform, false);
            shadow.transform.localPosition = new Vector3(0f, -0.05f, 0f);
            shadow.transform.localScale = new Vector3(0.8f, 0.8f, 1f);
            shadow.sprite = Art.Single("shadow");
            shadow.sortingOrder = FarmDemoWorld.ShadowOrder;
            go.AddComponent<SpriteRenderer>();
            go.AddComponent<YSort>().isStatic = false;
            var hen = go.AddComponent<Chicken>();
            hen.Init(name, _chickenFrames, brown);   // every other hen is a brown one
            _chickens.Add(hen);
            return hen;
        }

        static Vector2 RandomYardSpot() =>
            new Vector2(Random.Range(Yard.xMin, Yard.xMax), Random.Range(Yard.yMin, Yard.yMax));

        /// <summary>A spot in the yard for a hen to walk to, kept clear of the trough.</summary>
        public static Vector2 WanderSpot()
        {
            for (int i = 0; i < 6; i++)
            {
                var p = RandomYardSpot();
                if (Vector2.Distance(p, TroughSpot) > 0.8f) return p;
            }
            return Yard.center;
        }

        public static Vector2 Door => CoopDoor;

        void RefreshTrough()
        {
            if (_troughFrames != null) _trough.sprite = _troughFrames[Feed > 0 ? 1 : 0];
        }

        void OnDestroy()
        {
            GameClock.NewDay -= Morning;
            if (_instance == this) _instance = null;
        }

        // Each morning, while the screen is black: the hens come out, eat, and lay.
        void Morning()
        {
            int hungry = 0;
            foreach (var hen in _chickens)
            {
                bool wasPetted = hen.PettedToday;
                hen.WakeUp(RandomYardSpot());
                if (hen.JustArrived) { hen.JustArrived = false; continue; }
                if (!wasPetted) hen.Happiness = Mathf.Max(0, hen.Happiness - 1);
                if (Feed <= 0) { hungry++; continue; }
                Feed--;
                if (_eggs.Count >= MaxChickens * 3) continue;   // the yard is full of eggs; she keeps this one
                bool large = Random.value < hen.Happiness * 0.12f;
                LayEgg(large ? Items.LargeEgg : Items.Egg, RandomYardSpot());
            }
            RefreshTrough();
            if (hungry > 0) StartCoroutine(Later(4.5f, () => Hud.Toast(hungry == 1
                ? "A hen went hungry. Fill the trough with Chicken Feed from Hank."
                : "Your hens went hungry. Fill the trough with Chicken Feed from Hank.", 4f)));
        }

        static IEnumerator Later(float seconds, System.Action action)
        {
            yield return new WaitForSeconds(seconds);
            action();
        }

        void LayEgg(ItemDef item, Vector2 at)
        {
            var go = new GameObject(item.Name);
            go.transform.SetParent(transform, false);
            go.transform.position = at;
            go.transform.localScale = new Vector3(0.7f, 0.7f, 1f);
            go.AddComponent<SpriteRenderer>().sprite = Art.Strip("items", 16, 16, new Vector2(0.5f, 0.1f))?[item.IconIndex];
            go.AddComponent<YSort>();
            _eggs.Add((go, item));
        }

        void Update()
        {
            var player = PlayerController.Instance;
            if (player == null || Hud.Busy || player.Locked || Home.Inside || Cavern.Inside || DarkCave.Inside || Town.Inside) return;
            Vector2 feet = player.transform.position;
            Vector2 ahead = feet + Art.Dir(player.Facing) * 0.5f;

            // Eggs.
            int egg = -1;
            float best = 0.75f;
            for (int i = 0; i < _eggs.Count; i++)
            {
                float d = Vector2.Distance(ahead, _eggs[i].go.transform.position);
                if (d < best) { best = d; egg = i; }
            }
            if (egg >= 0)
            {
                var item = _eggs[egg].item;
                Hud.SetPrompt($"F  Pick up the {item.Name.ToLower()}");
                if (!GameInput.FishPressed()) return;
                if (!Inventory.Add(item)) { Hud.Toast("Your bag is full! Sell something to Mabel first.", 2.5f); return; }
                Destroy(_eggs[egg].go);
                _eggs.RemoveAt(egg);
                Hud.Toast($"+1 {item.Name}!", 1.5f);
                return;
            }

            // Hens.
            Chicken hen = null;
            best = 0.9f;
            foreach (var c in _chickens)
            {
                if (c.Asleep) continue;
                float d = Vector2.Distance(ahead, c.transform.position);
                if (d < best) { best = d; hen = c; }
            }
            if (hen != null)
            {
                if (hen.PettedToday) { Hud.SetPrompt($"{hen.Name} is happy"); return; }
                Hud.SetPrompt($"E  Pet {hen.Name}");
                if (GameInput.TalkPressed())
                {
                    hen.Pet();
                    if (_heart != null) StartCoroutine(HeartPop(hen.transform));
                    Hud.Toast($"{hen.Name} clucks happily.", 1.5f);
                }
                return;
            }

            // The trough.
            if (Vector2.Distance(feet, TroughSpot) > 1.1f) return;
            int have = Inventory.Count(Items.ChickenFeed);
            if (Feed >= TroughMax) Hud.SetPrompt($"The trough is full ({Feed} feed)");
            else if (have == 0)
                Hud.SetPrompt(Feed == 0 ? "The trough is empty. Hank sells Chicken Feed." : $"Trough: {Feed} feed left. Hank sells more.");
            else
            {
                Hud.SetPrompt($"F  Fill the trough ({Feed}/{TroughMax})");
                if (!GameInput.FishPressed()) return;
                int add = Inventory.Remove(Items.ChickenFeed, Mathf.Min(have, TroughMax - Feed));
                Feed += add;
                RefreshTrough();
                Hud.Toast($"You put {add} feed in the trough.", 1.5f);
            }
        }

        // A heart floats up over a hen you pet.
        IEnumerator HeartPop(Transform hen)
        {
            var sr = new GameObject("Heart").AddComponent<SpriteRenderer>();
            sr.sprite = _heart;
            sr.sortingOrder = 31500;
            for (float k = 0f; k < 1f; k += Time.deltaTime / 0.9f)
            {
                if (hen == null) break;
                sr.transform.position = (Vector2)hen.position + new Vector2(0f, 1.05f + k * 0.6f);
                sr.color = new Color(1f, 1f, 1f, k < 0.6f ? 1f : 1f - (k - 0.6f) / 0.4f);
                yield return null;
            }
            Destroy(sr.gameObject);
        }
    }

    /// <summary>One hen: pecks and wanders around the yard by day, goes into the coop at dusk.</summary>
    public class Chicken : MonoBehaviour
    {
        public string Name { get; private set; }
        public int Happiness;
        public bool PettedToday { get; private set; }
        public bool JustArrived;
        public bool Asleep { get; private set; }
        public bool Brown { get; private set; }

        const float Speed = 1.1f, Bedtime = 19.5f;
        Sprite[] _frames;
        SpriteRenderer _sr, _shadow;
        Vector2 _target;
        float _waitUntil, _peckUntil;

        public void Init(string name, Sprite[] frames, bool brown)
        {
            Name = name;
            Brown = brown;
            _frames = frames;
            _sr = GetComponent<SpriteRenderer>();
            _sr.color = brown ? new Color(0.95f, 0.72f, 0.5f) : Color.white;
            _shadow = transform.GetChild(0).GetComponent<SpriteRenderer>();
            _target = transform.position;
            _waitUntil = Time.time + Random.Range(0.5f, 2f);
        }

        public void Pet()
        {
            PettedToday = true;
            Happiness = Mathf.Min(5, Happiness + 1);
            StartCoroutine(Hop());
        }

        public void WakeUp(Vector2 at)
        {
            transform.position = at;
            _target = at;
            PettedToday = false;
            Show(true);
        }

        void Show(bool on)
        {
            Asleep = !on;
            _sr.enabled = on;
            if (_shadow != null) _shadow.enabled = on;
        }

        void Update()
        {
            if (_frames == null || Asleep) return;
            Vector2 pos = transform.position;

            // Dusk: walk to the coop door and go in.
            if (GameClock.Hour >= Bedtime)
            {
                _target = Animals.Door;
                if (Vector2.Distance(pos, _target) < 0.15f) { Show(false); return; }
            }
            else if (Time.time >= _waitUntil && Vector2.Distance(pos, _target) < 0.05f)
            {
                // Arrived: peck about for a bit, then pick a new spot.
                _peckUntil = Time.time + Random.Range(0.6f, 1.6f);
                _waitUntil = _peckUntil + Random.Range(0.5f, 2.5f);
                _target = Animals.WanderSpot();
            }

            bool walking = Time.time >= _waitUntil || GameClock.Hour >= Bedtime;
            if (walking && Vector2.Distance(pos, _target) > 0.05f)
            {
                Vector2 next = Vector2.MoveTowards(pos, _target, Speed * Time.deltaTime);
                if (Mathf.Abs(next.x - pos.x) > 0.001f) _sr.flipX = next.x > pos.x;   // the art faces left
                transform.position = next;
                _sr.sprite = _frames[1 + (int)(Time.time * 6f) % 2];
            }
            else
            {
                bool peck = Time.time < _peckUntil && (int)(Time.time * 4f) % 2 == 0;
                _sr.sprite = _frames[peck ? 3 : 0];
            }
        }

        IEnumerator Hop()
        {
            for (float k = 0f; k < 1f; k += Time.deltaTime / 0.25f)
            {
                _sr.transform.localScale = new Vector3(1f, 1f + 0.2f * Mathf.Sin(k * Mathf.PI), 1f);
                yield return null;
            }
            _sr.transform.localScale = Vector3.one;
        }
    }
}
