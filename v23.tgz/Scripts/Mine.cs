using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// The mine in the mountain west of the farm. Press E at the cave mouth to go down
    /// (Dot the Miner lends you a pickaxe first). Each floor is a stone room full of
    /// rocks and slimes: pick the pickaxe and press F to break rocks for copper, iron
    /// and gems. One rock on every floor hides the ladder down. The deeper you go,
    /// the better the ore and the tougher the slimes. Every fifth floor is
    /// remembered, so next time you start from there. Faint down here and Dot
    /// carries you out. Like the house, each floor is a room built off to the side
    /// of the map.
    /// </summary>
    public class Mine : MonoBehaviour
    {
        // Outside: the cave sprite stands with its bottom-centre here; the way in is in the middle.
        public static readonly Vector2 Mouth = new Vector2(-15f, 22f);
        // Inside: a 16x11 tile room whose bottom-left corner is here. The top 2 rows are the back wall.
        public static readonly Vector2 RoomOrigin = new Vector2(220f, 2f);
        const int RoomWidth = 16, RoomHeight = 11, FloorRows = 9;

        static Vector2 LadderUp => RoomOrigin + new Vector2(2.5f, FloorRows - 0.4f);
        static Vector2 Arrival => RoomOrigin + new Vector2(2.5f, FloorRows - 1.2f);

        static readonly Color32 MineBackground = new Color32(0x12, 0x0d, 0x0c, 0xff);

        public static bool Inside { get; private set; }
        public static int Floor { get; private set; }
        /// <summary>The deepest floor reached (kept in the save).</summary>
        public static int Deepest { get; set; }

        static Mine _instance;
        Transform _level;
        Sprite[] _bits, _slimeFrames, _puff;
        Sprite _prompt;
        SpriteRenderer _mouthPrompt, _ladderPrompt;
        Vector2? _ladderDown;

        public void Build(Transform parent)
        {
            _instance = this;
            Inside = false;
            Floor = 0;
            Deepest = 0;
            _prompt = Art.Single("key_e", new Vector2(0.5f, 0f));
            _bits = Art.Strip("mine_bits", 16, 16);
            _slimeFrames = Art.Strip("slime", 16, 16);
            _puff = Art.Strip("puff", 16, 16, new Vector2(0.5f, 0.5f));

            // Outside: the cave mouth. Only the rock is solid; you stand in front of the opening.
            var cave = new GameObject("Mine (outside)");
            cave.transform.SetParent(parent, false);
            cave.transform.position = Mouth;
            cave.AddComponent<SpriteRenderer>().sprite = Art.Single("cave");
            cave.AddComponent<YSort>();
            FarmDemoWorld.Tall(cave);
            var rock = cave.AddComponent<BoxCollider2D>();
            rock.size = new Vector2(2.7f, 1.3f);
            rock.offset = new Vector2(0f, 0.65f);
            _mouthPrompt = MakePrompt();

            // Inside: one room, refilled with rocks and slimes for each floor.
            var room = new GameObject("Mine (inside)");
            room.transform.SetParent(parent, false);
            room.transform.position = RoomOrigin;
            var floor = room.AddComponent<SpriteRenderer>();
            floor.sprite = Art.Single("mine_floor", Vector2.zero);
            floor.sortingOrder = -30000;
            Wall(room.transform, new Vector2(-0.1f, RoomHeight / 2f), new Vector2(0.4f, RoomHeight));             // left
            Wall(room.transform, new Vector2(RoomWidth + 0.1f, RoomHeight / 2f), new Vector2(0.4f, RoomHeight)); // right
            Wall(room.transform, new Vector2(RoomWidth / 2f, RoomHeight - 0.9f), new Vector2(RoomWidth, 1.8f));  // back wall
            Wall(room.transform, new Vector2(RoomWidth / 2f, -0.25f), new Vector2(RoomWidth, 0.5f));             // front

            var ladder = new GameObject("Ladder up").AddComponent<SpriteRenderer>();
            ladder.transform.SetParent(room.transform, false);
            ladder.transform.position = LadderUp;
            ladder.sprite = _bits?[5];
            ladder.sortingOrder = FarmDemoWorld.ShadowOrder - 100;
            _ladderPrompt = MakePrompt();

            GameClock.NewDay += Morning;
        }

        SpriteRenderer MakePrompt()
        {
            var sr = new GameObject("Prompt").AddComponent<SpriteRenderer>();
            sr.transform.SetParent(transform, false);
            sr.sprite = _prompt;
            sr.sortingOrder = 32000;
            sr.enabled = false;
            return sr;
        }

        static void Wall(Transform parent, Vector2 localCenter, Vector2 size)
        {
            var go = new GameObject("Wall");
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localCenter;
            go.AddComponent<BoxCollider2D>().size = size;
        }

        void OnDestroy()
        {
            GameClock.NewDay -= Morning;
            if (_instance == this) { _instance = null; Inside = false; }
        }

        // You always wake up at home; the mine is put away for the night.
        void Morning()
        {
            Inside = false;
            ClearLevel();
        }

        void ClearLevel()
        {
            if (_level != null) Destroy(_level.gameObject);
            _level = null;
            _ladderDown = null;
        }

        // ------------------------------------------------------------- going in and out

        /// <summary>Fainted in the mine: Dot hauls you back out to the cave mouth.</summary>
        public static void CarryOut()
        {
            Hud.Toast("You fainted! Dot found you and carried you out of the mine.", 3.5f);
            Hud.Transition(Leave);
        }

        static void Leave()
        {
            Inside = false;
            if (_instance != null) _instance.ClearLevel();
            Home.Move(Mouth + new Vector2(0f, -0.6f), Facing.Down,
                FarmDemoWorld.OutdoorBounds, Home.OutdoorBackground);
        }

        /// <summary>Where a trip down starts: floor 1, or the deepest fifth floor you've reached.</summary>
        static int StartFloor => Deepest >= 5 ? Deepest / 5 * 5 : 1;

        void GoTo(int floor)
        {
            Inside = true;
            Floor = floor;
            if (floor > Deepest) Deepest = floor;
            BuildLevel(floor);
            Home.Move(Arrival, Facing.Down, new Rect(RoomOrigin.x, RoomOrigin.y, RoomWidth, RoomHeight), MineBackground);
            Hud.Toast(floor % 5 == 0 && floor == Deepest
                ? $"Floor {floor}. Dot will remember you made it this far."
                : $"Mine floor {floor}", 2f);
        }

        // ------------------------------------------------------------- building a floor

        void BuildLevel(int floor)
        {
            ClearLevel();
            _level = new GameObject($"Floor {floor}").transform;
            _level.SetParent(transform, false);

            // Free spots on the floor, away from the ladder you arrive by.
            var cells = new List<Vector2Int>();
            for (int x = 1; x < RoomWidth - 1; x++)
            for (int y = 1; y < FloorRows - 1; y++)
                if (!(x <= 4 && y >= FloorRows - 4)) cells.Add(new Vector2Int(x, y));
            for (int i = cells.Count - 1; i > 0; i--)
            {
                int j = Random.Range(0, i + 1);
                (cells[i], cells[j]) = (cells[j], cells[i]);
            }

            int rocks = Random.Range(12, 19);
            int ladderRock = Random.Range(0, rocks);
            for (int i = 0; i < rocks && i < cells.Count; i++)
                AddRock(cells[i], PickKind(floor), i == ladderRock);

            int slimes = Mathf.Min(6, 2 + floor / 3);
            for (int i = 0, placed = 0; placed < slimes && rocks + i < cells.Count; i++)
            {
                var cell = cells[rocks + i];
                var at = RoomOrigin + new Vector2(cell.x + 0.5f, cell.y + 0.2f);
                if (Vector2.Distance(at, Arrival) < 5f) continue;
                AddSlime(at, floor);
                placed++;
            }
        }

        static RockKind PickKind(int floor)
        {
            int roll = Random.Range(0, 100);
            if (floor >= 6 && roll < 3 + floor / 4) return RockKind.Gem;
            if (floor >= 3 && roll < 14 + floor) return RockKind.Iron;
            if (roll < 36 + floor) return RockKind.Copper;
            return RockKind.Stone;
        }

        void AddRock(Vector2Int cell, RockKind kind, bool hidesLadder)
        {
            var go = new GameObject($"{kind} rock");
            go.transform.SetParent(_level, false);
            go.transform.position = RoomOrigin + new Vector2(cell.x + 0.5f, cell.y + 0.1f);
            go.AddComponent<SpriteRenderer>().sprite = _bits?[(int)kind];
            go.AddComponent<YSort>();
            var box = go.AddComponent<BoxCollider2D>();
            box.size = new Vector2(0.8f, 0.5f);
            box.offset = new Vector2(0f, 0.25f);
            var rock = go.AddComponent<MineRock>();
            rock.Kind = kind;
            rock.Hits = kind == RockKind.Stone ? 1 : kind == RockKind.Copper ? 2 : 3;
            rock.HidesLadder = hidesLadder;
        }

        void AddSlime(Vector2 at, int floor)
        {
            var slime = FarmDemoWorld.SpawnSlime(_level, at, _slimeFrames);
            if (slime == null) return;
            slime.health = 2 + floor / 4;
            slime.contactDamage = 1 + floor / 10;
            slime.chaseSpeed = 1.7f + Mathf.Min(0.8f, floor * 0.05f);
            slime.coinsOnDeath = 2 + floor / 5;
            slime.tint = floor >= 15 ? new Color(1f, 0.55f, 0.45f)
                : floor >= 10 ? new Color(0.6f, 0.75f, 1f)
                : floor >= 5 ? new Color(0.55f, 1f, 0.55f)
                : Color.white;
        }

        // ------------------------------------------------------------- every frame

        void Update()
        {
            _mouthPrompt.enabled = _ladderPrompt.enabled = false;
            var player = PlayerController.Instance;
            if (player == null || Hud.Busy || player.Locked || player.IsAttacking) return;
            Vector2 feet = player.transform.position;
            float bob = Mathf.Sin(Time.time * 5f) > 0f ? 1f / FarmDemoConfig.PixelsPerUnit : 0f;

            if (!Inside)
            {
                if (Home.Inside || Town.Inside) return;
                bool atMouth = Vector2.Distance(feet, Mouth + new Vector2(0f, -0.3f)) < 0.8f && player.Facing == Facing.Up;
                if (!atMouth) return;
                ShowPrompt(_mouthPrompt, Mouth + new Vector2(0f, 2.8f), bob);
                if (!Inventory.Has(Items.Pickaxe))
                {
                    Hud.SetPrompt("E  Look into the mine");
                    if (GameInput.TalkPressed()) Hud.Toast("It's dark, and full of rocks. Dot the Miner might lend you a pickaxe.", 3f);
                    return;
                }
                Hud.SetPrompt(StartFloor > 1 ? $"E  Go down to floor {StartFloor}" : "E  Go into the mine");
                if (GameInput.TalkPressed()) Hud.Transition(() => GoTo(StartFloor));
                return;
            }

            // The ladder you came down: back out to the farm.
            if (Vector2.Distance(feet, LadderUp + new Vector2(0f, -0.4f)) < 0.8f && player.Facing == Facing.Up)
            {
                ShowPrompt(_ladderPrompt, LadderUp + new Vector2(0f, 1.2f), bob);
                Hud.SetPrompt("E  Climb out of the mine");
                if (GameInput.TalkPressed()) Hud.Transition(Leave);
                return;
            }

            // The ladder down, once you've found it.
            if (_ladderDown is Vector2 down && Vector2.Distance(feet, down) < 0.7f)
            {
                ShowPrompt(_ladderPrompt, down + new Vector2(0f, 1.6f), bob);
                Hud.SetPrompt($"E  Climb down to floor {Floor + 1}");
                if (GameInput.TalkPressed()) Hud.Transition(() => GoTo(Floor + 1));
                return;
            }

            var held = Inventory.SelectedItem;
            bool use = GameInput.FishPressed();

            // A snack heals you down here.
            if (Food.Healing(held) > 0 && PlayerStats.Health < PlayerStats.MaxHealth)
            {
                Hud.SetPrompt(Food.Prompt(held));
                if (use)
                {
                    string said = Food.Eat(held);
                    if (said != null) Hud.Toast(said, 1.5f);
                }
                return;
            }

            // Break the rock in front of you.
            var rock = RockAhead(player);
            if (rock == null) return;
            if (held != Items.Pickaxe) { Hud.SetPrompt("Pick your pickaxe to break rocks"); return; }
            Hud.SetPrompt("F  Break the rock");
            if (use) Strike(rock);
        }

        static void ShowPrompt(SpriteRenderer sr, Vector2 at, float bob)
        {
            sr.enabled = true;
            sr.transform.position = at + new Vector2(0f, bob);
        }

        static MineRock RockAhead(PlayerController player)
        {
            Vector2 feet = (Vector2)player.transform.position + new Vector2(0f, 0.15f);
            Vector2 ahead = feet + Art.Dir(player.Facing) * 0.75f;
            foreach (var col in Physics2D.OverlapCircleAll(ahead, 0.4f))
            {
                var rock = col.GetComponent<MineRock>();
                if (rock != null) return rock;
            }
            return null;
        }

        void Strike(MineRock rock)
        {
            Effect(rock.transform.position + new Vector3(0f, 0.4f));
            if (Upgrades.Pickaxe >= 1) rock.Hits = 1;    // the steel pickaxe breaks anything in one go
            if (--rock.Hits > 0) { StartCoroutine(Shake(rock.transform)); return; }

            Vector2 at = rock.transform.position;
            var drop = rock.Kind == RockKind.Copper ? Items.CopperOre : rock.Kind == RockKind.Iron ? Items.IronOre : rock.Kind == RockKind.Gem ? Items.Gem : null;
            if (drop != null)
            {
                int count = rock.Kind == RockKind.Gem ? 1 : Random.Range(1, 3);
                if (Inventory.Add(drop, count))
                {
                    StartCoroutine(PopUp(drop.Icon, at));
                    Hud.Toast($"+{count} {QuestBoard.Plural(drop, count)}", 1.5f);
                }
                else Hud.Toast($"Your bag is full! The {drop.Name.ToLower()} rolled away.", 2.5f);
            }
            else if (Random.value < 0.2f) Coin.Spawn(at + new Vector2(0f, 0.3f));

            if (rock.HidesLadder)
            {
                var ladder = new GameObject("Ladder down").AddComponent<SpriteRenderer>();
                ladder.transform.SetParent(_level, false);
                ladder.transform.position = at + new Vector2(0f, -0.1f);
                ladder.sprite = _bits?[4];
                ladder.sortingOrder = FarmDemoWorld.ShadowOrder - 100;
                _ladderDown = at + new Vector2(0f, 0.4f);
                Hud.Toast("You found the ladder down!", 2f);
            }
            Destroy(rock.gameObject);
        }

        void Effect(Vector2 at)
        {
            if (_puff != null) StartCoroutine(PlayEffect(_puff, at));
        }

        static IEnumerator PlayEffect(Sprite[] frames, Vector2 at)
        {
            var sr = new GameObject("Effect").AddComponent<SpriteRenderer>();
            sr.transform.position = at;
            sr.sortingOrder = 31200;
            foreach (var f in frames)
            {
                sr.sprite = f;
                yield return new WaitForSeconds(0.07f);
            }
            Destroy(sr.gameObject);
        }

        static IEnumerator Shake(Transform t)
        {
            Vector3 home = t.position;
            for (float k = 0f; k < 1f && t != null; k += Time.deltaTime / 0.15f)
            {
                t.position = home + new Vector3(Mathf.Sin(k * Mathf.PI * 4f) / FarmDemoConfig.PixelsPerUnit, 0f, 0f);
                yield return null;
            }
            if (t != null) t.position = home;
        }

        // The ore hops up and fades out.
        static IEnumerator PopUp(Sprite icon, Vector2 from)
        {
            var sr = new GameObject("Found").AddComponent<SpriteRenderer>();
            sr.sprite = icon;
            sr.sortingOrder = 31500;
            for (float k = 0f; k < 1f; k += Time.deltaTime / 0.6f)
            {
                sr.transform.position = from + new Vector2(0f, 0.5f + Mathf.Sin(k * Mathf.PI * 0.5f) * 0.9f);
                sr.color = new Color(1f, 1f, 1f, k < 0.6f ? 1f : 1f - (k - 0.6f) / 0.4f);
                yield return null;
            }
            Destroy(sr.gameObject);
        }
    }

    public enum RockKind { Stone, Copper, Iron, Gem }

    /// <summary>A rock on a mine floor: how many more pickaxe hits it takes, and what's in it.</summary>
    public class MineRock : MonoBehaviour
    {
        public RockKind Kind;
        public int Hits;
        public bool HidesLadder;
    }
}
