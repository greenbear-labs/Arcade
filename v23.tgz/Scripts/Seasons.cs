using UnityEngine;

namespace FarmDemo
{
    public enum Season { Spring, Summer, Fall, Winter }

    /// <summary>
    /// The calendar: four seasons of FarmDemoConfig.DaysPerSeason days, then the
    /// year starts over. Each season recolours the grass and trees (see Recolor),
    /// changes which seeds Hazel sells, and wilts crops that are out of season.
    /// </summary>
    public static class Seasons
    {
        public static Season Current => Of(GameClock.Day);
        public static Season Of(int day) => (Season)((day - 1) / FarmDemoConfig.DaysPerSeason % 4);
        public static int DayOfSeason => (GameClock.Day - 1) % FarmDemoConfig.DaysPerSeason + 1;
        public static int Year => (GameClock.Day - 1) / (FarmDemoConfig.DaysPerSeason * 4) + 1;
        public static bool FirstDay => DayOfSeason == 1 && GameClock.Day > 1;

        /// <summary>"Spring 3", or "Spring 3, Year 2" after the first year.</summary>
        public static string DateText => $"{Current} {DayOfSeason}" + (Year > 1 ? $", Year {Year}" : "");

        /// <summary>The morning message on the first day of a season.</summary>
        public static string Arrival(Season s)
        {
            switch (s)
            {
                case Season.Summer: return "Summer is here! Hazel has tomato seeds now.";
                case Season.Fall: return "Fall is here! Pumpkins are in season. Summer crops have wilted.";
                case Season.Winter: return "Winter is here. Nothing grows in the cold, but your chickens still lay.";
                default: return "Spring is back! Hazel has turnip and strawberry seeds again.";
            }
        }

        /// <summary>
        /// Repaints one pixel of grass or leaves for a season. Spring is the art as drawn.
        /// Only clear greens change, so paths, soil, water, outlines and berries keep their colour.
        /// Foliage (trees, bushes) turns orange in fall; the ground turns gold. Winter brings snow.
        /// </summary>
        public static Color32 Recolor(Color32 c, Season s, bool foliage)
        {
            if (s == Season.Spring) return c;
            Color.RGBToHSV(c, out float h, out float sat, out float v);
            if (h < 0.16f || h > 0.47f || sat < 0.2f || v < 0.3f) return c;

            switch (s)
            {
                case Season.Summer:
                    h -= 0.025f; sat = Mathf.Min(1f, sat * 1.12f); v = Mathf.Min(1f, v * 1.04f);
                    break;
                case Season.Fall:
                    h = (foliage ? 0.055f : 0.115f) + (h - 0.25f) * 0.2f;
                    sat = Mathf.Min(1f, sat * (foliage ? 1.35f : 1.05f));
                    v = Mathf.Min(1f, v * 1.05f);
                    break;
                case Season.Winter:
                    if (foliage) { sat *= 0.35f; v = 0.45f + 0.5f * v; }
                    else { h = 0.58f; sat = 0.06f + 0.06f * (1f - v); v = 0.72f + 0.28f * v; }
                    break;
            }
            var o = (Color32)Color.HSVToRGB(Mathf.Repeat(h, 1f), Mathf.Clamp01(sat), Mathf.Clamp01(v));
            o.a = c.a;
            return o;
        }

        /// <summary>A tree or bush image in this season's colours.</summary>
        public static Sprite Prop(string name, Season s) =>
            s == Season.Spring ? Art.Single(name) : Art.RecoloredSingle(name, s.ToString(), c => Recolor(c, s, true));
    }
}
