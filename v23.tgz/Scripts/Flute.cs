using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// The flute. Lark, a Ventara who plays all day by the huts in the forest, will
    /// swap it for a piece of fruit: hold some fruit (or wild berries) beside Lark and
    /// press F. Then it's on your tool dial. Hold it and press F to play: you march
    /// along slowly, stepping high, with music notes floating up off you. F again to
    /// stop. Play it standing in the toadstool ring and the Snawfus comes out of the
    /// trees (see Snawfus).
    /// </summary>
    public class Flute : MonoBehaviour
    {
        /// <summary>How much slower you walk while you play.</summary>
        public const float MarchSpeed = 0.5f;
        const float NoteEvery = 0.32f, NoteLife = 1.4f;

        static Flute _instance;
        public static bool Playing { get; private set; }
        /// <summary>How long you've been playing this time.</summary>
        public static float PlayingFor { get; private set; }
        /// <summary>You traded Lark for the flute. (Kept in the save.)</summary>
        public static bool Traded
        {
            get => _instance != null && _instance._traded;
            set { if (_instance != null) _instance._traded = value; }
        }
        /// <summary>You're beside Lark with fruit in hand: F is for trading it.</summary>
        public static bool WantsTrade => _instance != null && _instance._wantsTrade;

        public static bool IsFruit(ItemDef item) =>
            item != null && (FruitKind.ForFruit(item) != null || item == Items.WildBerries || item == Items.Strawberry || item == Items.Melon);

        bool _traded, _wantsTrade, _wasMoving;
        Transform _lark;
        Sprite[] _notes;
        float _noteClock, _larkClock, _march;
        Vector2 _lastFeet;

        class Note { public SpriteRenderer Sprite; public Vector2 From; public float Age, Sway; }
        readonly List<Note> _live = new List<Note>();
        readonly Stack<SpriteRenderer> _spare = new Stack<SpriteRenderer>();

        static readonly Color[] NoteColours =
        {
            new Color(1f, 0.95f, 0.6f), new Color(0.75f, 0.9f, 1f), new Color(1f, 0.75f, 0.85f), new Color(0.8f, 1f, 0.75f),
        };

        public void Build(Transform lark)
        {
            _instance = this;
            Playing = false;
            _lark = lark;
            _notes = Art.Strip("notes", 8, 8, new Vector2(0.5f, 0.5f));
        }

        void OnDestroy()
        {
            if (_instance == this) { _instance = null; Playing = false; }
        }

        /// <summary>What Lark says.</summary>
        public static string[] LarkSays()
        {
            if (Traded) return new[]
            {
                "How's my old flute? Play it in the toadstool ring sometime, east along the trail. Something with antlers loves a tune.",
            };
            return new[]
            {
                "La la laaa... oh! Hello! I'm Lark. I play for the trees. They're a very polite audience.",
                "I've played this flute since I was a sprout. But I'm SO hungry, and nothing grows up in the branches but leaves.",
                "Tell you what: bring me a piece of fruit, any fruit, and the flute is yours. Hold it out and I'll swap you!",
            };
        }

        void Update()
        {
            _wantsTrade = false;
            var player = PlayerController.Instance;
            UpdateNotes();
            if (player == null) return;

            // Lark plays until the flute is yours.
            if (!_traded && _lark != null && (_larkClock += Time.deltaTime) > 0.55f)
            {
                _larkClock = 0f;
                SpawnNote((Vector2)_lark.position + new Vector2(Random.Range(-0.2f, 0.3f), 1.1f));
            }
            if (!_traded) Trade(player);

            // Stop if you put it away, climb on a creature, or something takes over.
            if (Playing && (Inventory.SelectedItem != Items.Flute || Creatures.Riding || player.Locked)) Stop(player);
            if (!Hud.Busy && !player.Locked && !Creatures.Riding && Inventory.SelectedItem == Items.Flute && !Creatures.WantUse && GameInput.FishPressed())
            {
                if (Playing) Stop(player);
                else { Playing = true; PlayingFor = 0f; _noteClock = 0f; }
            }
            if (!Playing) return;

            PlayingFor += Time.deltaTime;
            if (!Hud.Busy) Hud.SetPrompt("F  Stop playing");
            if ((_noteClock -= Time.deltaTime) <= 0f)
            {
                _noteClock = NoteEvery;
                SpawnNote(player.Center + new Vector2(Random.Range(-0.35f, 0.35f), 0.55f));
            }
        }

        // Marching: a high step on each beat while you walk, a little sway while you stand and play.
        void LateUpdate()
        {
            var player = PlayerController.Instance;
            if (!Playing || player == null) return;
            var body = player.GetComponentInChildren<SpriteSheetAnimator>();
            if (body == null) return;
            Vector2 feet = player.transform.position;
            bool moving = (feet - _lastFeet).sqrMagnitude > 0.00001f;
            _lastFeet = feet;
            if (moving != _wasMoving) _march = 0f;
            _wasMoving = moving;
            _march += Time.deltaTime;
            float lift = moving ? Mathf.Abs(Mathf.Sin(_march * Mathf.PI * 2.4f)) * 0.14f : Mathf.Abs(Mathf.Sin(_march * Mathf.PI * 1.2f)) * 0.04f;
            body.transform.localPosition = new Vector3(0f, Mathf.Round(lift * FarmDemoConfig.PixelsPerUnit) / FarmDemoConfig.PixelsPerUnit, 0f);
        }

        void Stop(PlayerController player)
        {
            Playing = false;
            PlayingFor = 0f;
            var body = player.GetComponentInChildren<SpriteSheetAnimator>();
            if (body != null && !Creatures.Riding) body.transform.localPosition = Vector3.zero;
        }

        void Trade(PlayerController player)
        {
            if (_lark == null || Hud.Busy || player.Locked) return;
            Vector2 feet = (Vector2)player.transform.position + new Vector2(0f, 0.15f);
            if (Vector2.Distance(feet, (Vector2)_lark.position + new Vector2(0f, 0.15f)) > 1.7f) return;
            var held = Inventory.SelectedItem;
            if (!IsFruit(held)) return;
            _wantsTrade = true;
            Hud.SetPrompt($"F  Trade Lark your {held.Name.ToLower()} for the flute");
            if (!GameInput.FishPressed() || Inventory.Remove(held) == 0) return;
            _traded = true;
            Inventory.Add(Items.Flute);
            Toolbelt.Pick(Items.Flute);
            StartCoroutine(Creatures.HeartPop(_lark, 1.7f));
            Hud.ShowPopup(Items.Flute.Icon, "You got Lark's Flute!",
                "It's on your tool dial. Hold it and press F to play (F again to stop). You'll march along slowly while you play.");
        }

        // ------------------------------------------------------------- notes

        void SpawnNote(Vector2 at)
        {
            if (_notes == null) return;
            var sr = _spare.Count > 0 ? _spare.Pop() : NewNote();
            sr.gameObject.SetActive(true);
            sr.sprite = _notes[Random.Range(0, _notes.Length)];
            sr.color = NoteColours[Random.Range(0, NoteColours.Length)];
            sr.transform.position = at;
            _live.Add(new Note { Sprite = sr, From = at, Age = 0f, Sway = Random.Range(0f, 6.28f) });
        }

        SpriteRenderer NewNote()
        {
            var sr = new GameObject("Note").AddComponent<SpriteRenderer>();
            sr.transform.SetParent(transform, false);
            sr.sortingOrder = 31600;      // over the night shade, so you can see the music in the dark
            return sr;
        }

        void UpdateNotes()
        {
            for (int i = _live.Count - 1; i >= 0; i--)
            {
                var n = _live[i];
                n.Age += Time.deltaTime;
                float t = n.Age / NoteLife;
                if (t >= 1f)
                {
                    n.Sprite.gameObject.SetActive(false);
                    _spare.Push(n.Sprite);
                    _live.RemoveAt(i);
                    continue;
                }
                n.Sprite.transform.position = n.From + new Vector2(Mathf.Sin(n.Sway + t * 7f) * 0.18f, t * 1.1f);
                var c = n.Sprite.color;
                c.a = t < 0.7f ? 1f : 1f - (t - 0.7f) / 0.3f;
                n.Sprite.color = c;
            }
        }
    }
}
