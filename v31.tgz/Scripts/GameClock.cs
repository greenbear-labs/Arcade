using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// The time of day. The clock runs round the whole night: nobody makes you sleep, so you can stay out
    /// for night adventures. Each dawn (6 AM) is a new day: crops grow, hens lay, pots come back and the game
    /// saves. Going to bed is a choice (see Hud.OpenSleepMenu): sleep till morning, or nap till evening to
    /// skip ahead to the night. Either one refills your hearts. Day length is FarmDemoConfig.DayLengthSeconds
    /// (doubled with "Relaxed days" in the settings).
    /// </summary>
    public class GameClock : MonoBehaviour
    {
        /// <summary>Hour runs from StartHour (6 AM) to EndHour (6 AM the next morning), so night hours
        /// after midnight read 24 to 30 and "later than 7 PM" checks keep working all night.</summary>
        public const float StartHour = 6f, EndHour = 30f;
        /// <summary>Where a nap ends: 8 PM.</summary>
        public const float EveningHour = 20f;

        public static int Day { get; private set; } = 1;
        /// <summary>Hours since midnight, 6 to 30.</summary>
        public static float Hour { get; private set; } = StartHour;
        /// <summary>Fires each dawn, whether you slept or stayed up. After a sleep, it comes after WokeUp.</summary>
        public static event System.Action NewDay;
        /// <summary>Fires when you wake from sleep or a nap, while the screen is black: you're back home in bed.</summary>
        public static event System.Action WokeUp;

        /// <summary>Clock hours that pass per real second (the 20 hours from 6 AM to 2 AM take Settings.DayLength).</summary>
        public static float HoursPerSecond => 20f / Settings.DayLength;

        /// <summary>0 in daylight, up to 1 in the dead of night, easing off again before dawn.</summary>
        public static float Darkness
        {
            get
            {
                float dusk = Mathf.Clamp01((Hour - 17.5f) / 4f);         // 5:30 PM to 9:30 PM
                float dawn = Mathf.Clamp01((EndHour - Hour) / 1.75f);    // 4:15 AM to 6 AM
                return Mathf.Min(dusk, dawn);
            }
        }

        /// <summary>Is it dark out? (After 8 PM and before 6 AM.)</summary>
        public static bool Night => Hour >= EveningHour;

        /// <summary>A nap till evening only makes sense while it's still light out.</summary>
        public static bool CanNap => Hour < EveningHour - 0.5f;

        /// <summary>Black over the screen while you sleep: 0 none, 1 full.</summary>
        public static float Fade { get; private set; }

        public static string TimeText
        {
            get
            {
                int h = Mathf.FloorToInt(Hour) % 24;
                int m = Mathf.FloorToInt((Hour - Mathf.Floor(Hour)) * 6f) * 10;   // steps of 10 minutes
                return $"{(h % 12 == 0 ? 12 : h % 12)}:{m:00} {(h < 12 ? "AM" : "PM")}";
            }
        }

        static GameClock _instance;
        float _sleepClock = -1f;        // >= 0 while fading out / in
        bool _napping;                  // this sleep ends in the evening, not the next morning

        /// <summary>Jump to the morning of a given day (loading a save).</summary>
        public static void SetDay(int day)
        {
            Day = Mathf.Max(1, day);
            Hour = StartHour;
        }

        public static void ResetClock()
        {
            Day = 1;
            Hour = StartHour;
            Fade = 0f;
        }

        /// <summary>Go to bed now and wake up tomorrow morning.</summary>
        public static void Sleep() => StartSleep(false);

        /// <summary>Nap through the rest of the day and wake up at 8 PM.</summary>
        public static void Nap() { if (CanNap) StartSleep(true); }

        static void StartSleep(bool nap)
        {
            if (_instance == null || _instance._sleepClock >= 0f) return;
            _instance._sleepClock = 0f;
            _instance._napping = nap;
        }

        public static bool Sleeping => _instance != null && _instance._sleepClock >= 0f;

        void Awake() => _instance = this;

        void Update()
        {
            if (_sleepClock >= 0f) { UpdateSleep(); return; }

            // The clock stops while you're reading something, like in Stardew.
            if (!Hud.Busy) Hour += Time.deltaTime * HoursPerSecond;

            // The sun comes up on a new day, even if you never went to bed.
            if (Hour >= EndHour)
            {
                StartNewDay();
                Hud.Toast($"{Seasons.DateText}. The sun's coming up. Your farm is saved.", 4f);
            }

            if (GameInput.SleepPressed() && !Hud.Busy) Hud.OpenSleepMenu();
        }

        void UpdateSleep()
        {
            const float fadeOut = 1f, hold = 0.6f, fadeIn = 1f;
            float before = _sleepClock;
            _sleepClock += Time.deltaTime;

            if (before < fadeOut + hold && _sleepClock >= fadeOut + hold) Wake();

            if (_sleepClock < fadeOut) Fade = _sleepClock / fadeOut;
            else if (_sleepClock < fadeOut + hold) Fade = 1f;
            else Fade = 1f - (_sleepClock - fadeOut - hold) / fadeIn;

            if (_sleepClock >= fadeOut + hold + fadeIn) { Fade = 0f; _sleepClock = -1f; }
        }

        // The middle of a sleep, while the screen is black.
        void Wake()
        {
            PlayerStats.Health = PlayerStats.MaxHealth;
            WokeUp?.Invoke();
            if (_napping)
            {
                Hour = EveningHour;
                Hud.Toast("You wake up as the sun goes down. The night is yours.", 4f);
                return;
            }
            StartNewDay();
            Hud.Toast($"{Seasons.DateText}. Good morning! Your farm is saved.", 4f);
        }

        static void StartNewDay()
        {
            Day++;
            Hour = StartHour;
            NewDay?.Invoke();
        }

        void OnDestroy()
        {
            if (_instance == this) { _instance = null; NewDay = null; WokeUp = null; }
        }
    }
}
