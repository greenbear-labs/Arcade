using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// Everything the townsfolk say about creatures, all in one place so it's easy to rewrite:
    /// each person's line for each trust stage (Afraid, Wary, Curious, Welcoming, Connected),
    /// where their meter starts, their two gifts, the clues they give, and the speech bubbles
    /// that pop up when a creature comes near or when two of them get chatting.
    /// </summary>
    public static class TownLines
    {
        static Trust.Gift G(ItemDef item, int count, string line) => new Trust.Gift { Item = item, Count = count, Line = line };
        static Trust.Gift Gold(int gold, string line) => new Trust.Gift { Gold = gold, Line = line };

        public static void Register()
        {
            Trust.Reset();

            // ---------------------------------------------------------------- outside town
            Trust.Register("Grandpa Turnip", "Grandpa Turnip", 65, new[]
            {
                "", "", "",
                "Your grandma always said the creatures would come round to folk, if folk came round to them. Look at you.",
                "Creatures in the square, children laughing. I've waited sixty years to see this valley like this.",
            }, G(Items.PumpkinSeeds, 4, "Your grandma's pumpkin seeds. Kept 'em all these years. Plant them anywhere, they'll grow."),
               G(Items.HoneyCake, 2, "For you and that creature of yours. Don't tell Mabel I can bake."),
               new[] { null, null, null, "Grandpa Turnip has always believed in creatures. He's quietly proud of you.", null });

            Trust.Register("Old Gil", "Gil", 14, new[]
            {
                "Forty years on this pond, I've learned one thing. If it's got teeth and it isn't a fish, leave it be.",
                "Saw one of your creatures by the water. Didn't scare the fish off. I'll grant it that.",
                "Do creatures fish? I'd pay good money to see a turtle with a rod.",
                "Bring your creature by the pond any time. It's good company. Quieter than Pip.",
                "Funny. All those years I sat here alone, and the creatures were right there in the hills.",
            }, G(Items.GoldenTrout, 1, "Caught this one thinking of your creature. Seemed only right it went to you."),
               Gold(250, "My prize money from the '72 fishing derby. Buy your creature something nice."));

            Trust.Register("Dot the Miner", "Dot", 18, new[]
            {
                "Slimes I can handle. The big things that clank about on the mountain at night? No thank you.",
                "That turtle of yours sniffs out gems, I hear. Still wouldn't turn my back on it.",
                "Can your creatures see in the dark? Asking for a miner.",
                "If your turtle ever wants a job, I've got a tunnel full of rocks that need ramming.",
                "I sing to the walls down there now. The creatures in the deep sing back. Don't laugh.",
            }, G(Items.Gem, 3, "Dug these out deep. One for you, one for the turtle, one for luck."),
               G(Items.IronOre, 8, "The good iron, from the bottom. Take it to Ingrid."));

            // ---------------------------------------------------------------- the square
            Trust.Register("Pip", "Pip", 28, new[]
            {
                "The others say creatures are dangerous. The raccoons say otherwise. I'm one of the raccoons. Well. Three of them.",
                "Creatures are just raccoons with better PR. I'm not scared. The middle raccoon is a bit scared.",
                "Does your creature have a name? Does it have a hat? It should have a hat.",
                "The fountain's got company now! Your creature can watch it with me any time.",
                "Me, the fountain and the creatures. Best job in town. Still unpaid.",
            }, G(Items.GoldenTrout, 1, "Found this in the trench coat. Don't ask which raccoon had it."),
               G(Items.OldBoot, 1, "The raccoons want you to have this. It's their best boot. It means a lot."));

            Trust.Register("Mabel the Baker", "Mabel", 6, new[]
            {
                "Sweetie, keep those wild beasts out of my bakery. They'll have the pies and maybe the baker too.",
                "I suppose your creature hasn't eaten anyone yet. But I'm counting.",
                "What does a creature like to eat, anyway? I could bake something. Not that I'm offering.",
                "I've started saving the burnt crusts for your creature. Don't tell anyone, I have a reputation.",
                "I bake a little creature biscuit now. Shaped like a turtle. They sell out every morning.",
            }, G(Items.PumpkinPie, 1, "A whole pie, sweetie. The crust is for your creature."),
               Gold(300, "From the bakery till. Creature biscuits have been very good for business."));

            Trust.Register("Hazel", "Hazel", 2, new[]
            {
                "Keep that animal away from my greenhouse. And away from my children.",
                "Wren and Tuck won't stop talking about your creatures. I'd rather they didn't.",
                "Hank says creatures used to help farm this valley, long ago. I never knew that.",
                "The kids have drawn your creatures on every wall. I've stopped scrubbing them off.",
                "I was so scared for my children. Now they've got a whole new kind of friend.",
            }, G(Items.AppleSapling, 1, "An apple tree for your farm. Plant one where your creatures can nap in the shade."),
               G(Items.CherrySapling, 2, "Cherry trees, from the kids and me. Thank you for being patient with us."),
               new[] { "Hazel is frightened of creatures, and most of all for her children.", null, null, null, null });

            Trust.Register("Hank", "Hank", 0, new[]
            {
                "Wild beasts and livestock don't mix. One of them gets in my yard and I lose a whole herd to fright.",
                "My hens didn't even notice your creature. Don't let it go to your head.",
                "Do creatures herd? I've got a goat who could use some herding.",
                "Bring your creature round the yard. The cows have taken a shine to it.",
                "Turns out creatures and livestock get on fine. It was just me that was the problem.",
            }, G(Items.Cheese, 2, "From my best cow. She asked about your creature, so to speak."),
               G(Items.ChickenFeed, 20, "Feed for your hens. And a scoop for the creature, if it's peckish."),
               new[] { "Hank thinks creatures will spook his animals.", null, null, null, null });

            Trust.Register("Poppy", "Poppy", 10, new[]
            {
                "I'd love creatures if they weren't so... bitey. Are they bitey? Everyone says they're bitey.",
                "Your creature walked right past my tulips and didn't trample one. I'm almost impressed.",
                "Do creatures like flowers? The blimp bee loves lavender, they say. Is that true?",
                "I've planted a bed of lavender just for the creatures. And for me. Mostly the creatures.",
                "Flowers grow where your Snawfus walks, you know. I've started following it around with a basket.",
            }, G(Items.Lavender, 5, "Lavender, for any bees you know. Big ones especially."),
               G(Items.SunflowerSeeds, 6, "Sunflowers! Tall enough for a creature to hide behind."));

            Trust.Register("Chef Basil", "Basil", 6, new[]
            {
                "A creature in my kitchen? Over my dead souffle.",
                "Your creature has very good manners for a wild animal. Better than most of my customers.",
                "What do they eat? Could I cook for them? Purely research, you understand.",
                "I've put a creature dish on the menu. Nobody orders it. The creatures love it.",
                "Cooking for creatures has taught me more than cooking school. Don't tell my old teacher.",
            }, G(Items.FishStew, 2, "My fish stew. One bowl for you, one for your creature."),
               G(Items.HoneyCake, 2, "Honey cakes, a new recipe. The creatures helped. Mostly by eating the mistakes."));

            Trust.Register("Ingrid", "Ingrid", 0, new[]
            {
                "Creatures burned my old forge to the ground, years back. I won't have one in here. Ever.",
                "I saw your creature. It didn't burn anything down. Yet.",
                "My boy Flint keeps sneaking off to the mountain to look at the phoenix's nest. He thinks I don't know.",
                "Maybe it wasn't a creature that started that fire. Maybe I just needed something to blame.",
                "The phoenix keeps my forge warm on cold mornings now. Don't you dare tell the others I said that.",
            }, G(Items.IronOre, 6, "Good iron. Make something sturdy. Something a creature can't chew."),
               G(Items.Gem, 2, "Two of my best stones. I'd been saving them for something that mattered."),
               new[] { "Ingrid blames a creature for burning down her old forge. She won't hear a word for them.", null, null, null, null });

            Trust.Register("Oakley", "Oakley", 8, new[]
            {
                "My mum always said: never whittle near a wild creature. I never asked why. Too scared.",
                "Your creature sat and watched me plane a board for an hour. Not a bad audience.",
                "Could I build a little house for a creature? What size? What shape? I've got sketches.",
                "I've started on a creature house for the square. It's mostly roof. Creatures like roofs, right?",
                "The creature house is finished. Three creatures moved in on the first night. Best thing I've built.",
            }, G(Items.Wood, 25, "Good timber. Build your creatures something nice."),
               G(Items.Wood, 40, "More timber. You've got more creatures now, I'd guess."));

            Trust.Register("Dr. Quill", "Dr. Quill", 12, new[]
            {
                "Creatures are dangerous, unpredictable, and impossible to study. Which is why nobody has. Hmm.",
                "Fascinating. Your creature obeys no known law of animal behaviour. It seems to... like you?",
                "I've started a notebook on your creatures. Page one says 'Help.' Page two is better.",
                "My research suggests creatures are friendly to anyone who is friendly first. Groundbreaking.",
                "I've given up science for creatures. No, wait, creatures ARE science now. My science.",
            }, G(Items.Gem, 1, "A sample from my collection. Its readings change when a creature is near. Isn't that marvellous?"),
               Gold(200, "A research grant. Well, from my own pocket. For the person who taught this town about creatures."));

            Trust.Register("Bea", "Bea", 6, new[]
            {
                "Oh, dear. A creature near my thread? It'll have the whole spool unravelled in a minute.",
                "Your creature has lovely fur. Not that I'd touch it. Well. Maybe one day.",
                "Could a creature wear a little scarf? Just asking. Purely professional curiosity.",
                "I've knitted your creature a scarf. If it doesn't like it, it can chew on it. I won't mind. Much.",
                "Half my orders are creature scarves now. I've never been busier, dear.",
            }, G(Items.Tulip, 4, "Tulips, from my window box. A thank-you for my door."),
               Gold(150, "From the creature scarf money. It's only fair."),
               new[] { "Bea is nervous of creatures, and worried for her shop.", null, null, null, null });

            Trust.Register("Brick", "Brick", 8, new[]
            {
                "Wild creatures? Keep 'em off my building sites. One wrong step and down comes the scaffolding.",
                "Seen your turtle work. Strong little thing. Doesn't mean I trust it with a hammer.",
                "How much could a turtle carry, do you reckon? Asking for the business.",
                "If your creature ever wants a job on the crew, it's hired. Pays in sandwiches.",
                "The turtle's an honorary member of the crew now. Got its own hard hat and everything.",
            }, G(Items.Wood, 30, "Spare wood from the yard. Don't say I never give you anything."),
               G(Items.Wood, 50, "A whole load. The turtle helped carry it."));

            Trust.Register("Nails", "Nails", 4, new[]
            {
                "I don't do creatures. I do nails. Nails don't bite.",
                "Your creature sat on my toolbox. I didn't scream. That's growth.",
                "Do you reckon a creature could hold a nail for me? My thumb's had enough.",
                "Your creature held a nail for me today! I only hit it once. The nail, I mean.",
                "Me and the creatures, we're a team now. A crooked team, but a team.",
            }, G(Items.Wood, 10, "Offcuts. They're the best bits, honestly."),
               G(Items.Sprinkler, 2, "Built these myself. Measured three times. They might work."));

            Trust.Register("Plank", "Plank", 10, new[]
            {
                "My brother Beam got chased by something with horns once. He's never been the same. Neither has his hat.",
                "Your creature's alright, I think. Beam still isn't convinced.",
                "Is it true creatures choose you? Can a creature choose Beam? He needs it.",
                "Beam patted a creature today! Well, he pointed at one. Baby steps.",
                "A creature chose Beam! It's a very small one. He's never been happier.",
            }, G(Items.Wood, 10, "From me and Beam. Mostly me."),
               G(Items.TurnipSoup, 2, "Beam made soup to say thanks. It's... soup."));

            // ---------------------------------------------------------------- the kids (Hazel and Hank's)
            Trust.Register("Wren", "Wren", 30, new[]
            {
                "Mum says creatures are dangerous. But I saw one from my window and it looked so soft!",
                "Is your creature friendly? Mum says don't touch. I'm not touching. I'm just looking really hard.",
                "I've drawn your creature eleven times! Do you want to see? It's the blob with the eyes.",
                "Can your creature come to my birthday? Mum said maybe! Maybe means yes!",
                "When I grow up I'm going to be a creature friend, just like you!",
            }, G(Items.WildBerries, 5, "Wild berries! I picked them for your creatures. I only ate a few."),
               G(Items.Strawberry, 5, "My best strawberries. Tuck wanted to give you a worm, but I said no."));

            Trust.Register("Tuck", "Tuck", 32, new[]
            {
                "Are creatures real monsters? Wren says no. Mum says yes. I say COOL.",
                "Does it bite? Does it bite REALLY hard? Can I see it bite something?",
                "I'm going to ride a creature one day! A big one! With wings!",
                "Your creature licked me! Mum said wash my face. I'm never washing my face again.",
                "Me and your creature are best friends. Don't tell Wren. She thinks she's its best friend.",
            }, G(Items.OldBoot, 1, "I found this in the pond! It's a treasure! You can have it."),
               G(Items.Carrot, 3, "Carrots! For your creature. I didn't lick them. Much."));

            // ---------------------------------------------------------------- clues: who tells you about whose trouble
            Trust.AddClue("rubble", "Bea", "Bea",
                "A wall came down in the night and buried my door in rubble. Brick says it's far too heavy to shift by hand. My poor shop!",
                "Bea can't get into her sewing room: rubble from a fallen wall is piled against her door.", () => TownEvents.RubbleCleared);
            Trust.AddClue("rubble-brick", "Brick", "Bea",
                "That wall that fell on Bea's door? The boys and I can't budge it. You'd need something built like a cannonball.",
                "Brick says the rubble at Bea's door needs something built like a cannonball to clear it.", () => TownEvents.RubbleCleared);
            Trust.AddClue("lamps", "Hank", "Hank",
                "The lamps round the square stopped working at night. Folk are scared to walk home in the dark, and so am I, if I'm honest.",
                "Hank is bothered that the town square lamps stopped working at night.", () => TownEvents.LampsLit);
            Trust.AddClue("lamps-pip", "Pip", "Hank",
                "The square lamps went out. It's very dark at the fountain at night. The raccoons don't mind. Hank minds a lot.",
                "Pip says Hank is scared of the dark square since the lamps went out. They need a flame.", () => TownEvents.LampsLit);
            Trust.AddClue("frisbee", "Wren", "Wren",
                "Tuck threw our frisbee onto the bakery roof! We're not allowed to climb. It's stuck forever!",
                "Wren and Tuck's frisbee is stuck on the bakery roof, and they aren't allowed to climb up.", () => TownEvents.FrisbeeFetched);
            Trust.AddClue("frisbee-mabel", "Mabel the Baker", "Tuck",
                "Hazel's little ones got their frisbee stuck on my roof. Poor Tuck's been moping about it all morning.",
                "Mabel says Tuck has been moping since the frisbee got stuck on her roof.", () => TownEvents.FrisbeeFetched);
        }

        // ---------------------------------------------------------------- when your creature is right there

        static readonly string[][] Here =
        {
            new[] { "Eek! Keep that beast back! ...Fine, what do you want? Quickly.", "Don't let it near me! I'll talk to you, but it stays over there!" },
            new[] { "Just keep it where I can see it, alright?", "...It's staring at me. Why is it staring at me?" },
            new[] { "Oh! Is that one of yours? Hello, creature. Hello.", "Can I look at it? Just look. From here." },
            new[] { "Look who's come to visit! Hello, you!", "Ah, my favourite creature! And you too, I suppose." },
            new[] { "There's my friend! Come here, you!", "Hello, both of you. The creature first, obviously." },
        };

        /// <summary>The first thing someone says with your creature beside you.</summary>
        public static string CreatureHere(Trust.Person p)
        {
            var pool = Here[(int)p.Stage];
            return pool[(p.Name.Length + GameClock.Day) % pool.Length];
        }

        // ---------------------------------------------------------------- speech bubbles

        static readonly string[][] Reactions =
        {
            new[] { "Eek! A monster!", "Oh no, a scary beast!", "Stay back! Stay back!", "Get it away from me!", "Somebody help!", "Run!" },
            new[] { "Keep it over there...", "Is it going to bite?", "Hmph. Just keep walking.", "I'm watching you, creature." },
            new[] { "Ooh, look at it!", "What IS that?", "Is it friendly?", "Look, it's sniffing!" },
            new[] { "Hello, little one!", "There's our creature!", "Aww, look who's here!", "Hi there!" },
            new[] { "Hey, buddy!", "Who's a good creature?", "Come here, you!", "My favourite!" },
        };

        static readonly string[][] Chatter =
        {
            new[] { "Did you see what the farmer's got following them?", "I keep my door locked at night now.", "Wild creatures are dangerous. Everyone knows that.",
                    "Somebody should do something about those beasts.", "My gran always said: never look a creature in the eye." },
            new[] { "It didn't hurt anyone, I'll give it that.", "Still. I wouldn't let one near my kids.", "Maybe the farmer knows what they're doing. Maybe.",
                    "I saw one sitting perfectly still. Like it was waiting." },
            new[] { "Did you see the turtle clear Bea's door? BAM!", "I wonder what they eat.", "Maybe they're not all bad.",
                    "Do you think they get lonely, up in the hills?" },
            new[] { "I saved a treat in case the farmer's creature comes by.", "The square feels livelier with creatures about.",
                    "Remember when we were scared of them? Silly." },
            new[] { "Can't remember why we were ever scared.", "This town's never been happier.", "Creatures are family now." },
        };

        /// <summary>What someone blurts out when your creature comes close.</summary>
        public static string Reaction(TrustStage stage) => Pick(Reactions[(int)stage]);
        /// <summary>A remark to whoever's nearby: how the town feels, at their stage.</summary>
        public static string Chat(TrustStage stage) => Pick(Chatter[(int)stage]);

        static string Pick(string[] pool) => pool[Random.Range(0, pool.Length)];
    }
}
