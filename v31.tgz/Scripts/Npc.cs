using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// A villager who breathes, turns to look at you when you're close, shows an
    /// "E" prompt, and says their lines when you press E. Townsfolk also feel something
    /// about creatures (see Trust): the first chat each day starts with what they think,
    /// a speech bubble pops up when your creature comes near or when two of them get
    /// talking, and while they're still afraid they back away from your creature.
    /// </summary>
    public class Npc : MonoBehaviour
    {
        public string displayName = "Villager";
        [TextArea] public string[] lines = { "Hello!" };
        public float talkRange = 1.4f;
        public float idleFps = 2f;

        static readonly List<Npc> All = new List<Npc>();
        /// <summary>Every villager in the scene right now (the ones out of sight aren't in it).</summary>
        public static IReadOnlyList<Npc> Everyone => All;

        /// <summary>The town places this one every frame (see Town); otherwise it stands where it was put.</summary>
        [System.NonSerialized] public bool Managed;
        /// <summary>How far they've backed away from your creature, while they're afraid of it.</summary>
        [System.NonSerialized] public Vector2 Shy;
        Vector2 _anchor;
        float _reactCool, _chatCool;
        const float ScaredRange = 2.6f, ReactRange = 3.2f, ShyDistance = 1.4f, ShySpeed = 3f;

        /// <summary>True while a townsperson walks between home and work: they don't stop to chat.</summary>
        public bool Walking;
        /// <summary>Which way they're walking.</summary>
        public Facing WalkFacing = Facing.Down;

        System.Func<string[]> _script;     // optional: pick lines at talk time
        System.Action _afterTalk;           // optional: runs once the last line is read

        /// <summary>Choose what to say each time you talk, and what happens after.</summary>
        public void SetScript(System.Func<string[]> lines, System.Action afterTalk)
        {
            _script = lines;
            _afterTalk = afterTalk;
        }

        Sprite[][] _frames;            // [Facing][frame]
        SpriteRenderer _sprite;
        SpriteRenderer _prompt;
        Facing _facing = Facing.Down;
        float _clock;
        float _lookAwayTimer;

        public void Init(string name, string[] says, Sprite[][] frames, Sprite promptSprite)
        {
            displayName = name;
            lines = says;
            _frames = frames;
            _sprite = GetComponent<SpriteRenderer>();

            var prompt = new GameObject("Talk prompt").AddComponent<SpriteRenderer>();
            prompt.transform.SetParent(transform, false);
            prompt.sprite = promptSprite;
            prompt.sortingOrder = 32000;     // always on top
            prompt.enabled = false;
            _prompt = prompt;
            _clock = Random.value;
            _reactCool = Random.Range(1f, 4f);
            _chatCool = Random.Range(12f, 40f);
        }

        void OnEnable() => All.Add(this);
        void OnDisable() => All.Remove(this);

        void Update()
        {
            if (_frames == null) return;
            Feelings();
            if (Walking)
            {
                // Walk sheets are stand, breathe, step, step: the walk is stand, step, stand, step.
                _prompt.enabled = false;
                _clock += Time.deltaTime;
                var walk = _frames[(int)WalkFacing];
                int step = Mathf.FloorToInt(_clock * FarmDemoConfig.WalkFps) % 4;
                _sprite.sprite = walk.Length >= 4 ? walk[step == 1 ? 2 : step == 3 ? 3 : 0] : walk[0];
                _facing = WalkFacing;
                return;
            }
            var player = PlayerController.Instance;
            float distance = player != null ? Vector2.Distance(player.transform.position, transform.position) : float.MaxValue;
            bool talkingToMe = ReferenceEquals(Hud.Speaker, this);

            // Turn toward the player while they're nearby, then drift back to facing down.
            if (distance < talkRange * 1.6f)
            {
                _facing = Art.FacingToward((Vector2)player.transform.position - (Vector2)transform.position);
                _lookAwayTimer = 1.5f;
            }
            else if ((_lookAwayTimer -= Time.deltaTime) <= 0f)
            {
                _facing = Facing.Down;
            }

            _clock += Time.deltaTime;
            var set = _frames[(int)_facing];
            _sprite.sprite = set[Mathf.FloorToInt(_clock * idleFps) % Mathf.Min(set.Length, 2)];

            bool closest = distance < talkRange && ReferenceEquals(Closest(player), this) && (!Hud.Busy || talkingToMe);
            _prompt.enabled = closest && !talkingToMe;
            // Bob the prompt by one whole pixel so it stays crisp.
            float bob = Mathf.Sin(Time.time * 5f) > 0f ? 1f / FarmDemoConfig.PixelsPerUnit : 0f;
            _prompt.transform.localPosition = new Vector3(0f, 1.75f + bob, 0f);

            if (closest && GameInput.TalkPressed())
            {
                if (talkingToMe) Hud.AdvanceDialogue();
                else
                {
                    // What they think of creatures first (once a day), then their usual lines.
                    var first = Trust.Chat(displayName, transform.position);
                    var usual = _script != null ? _script() : lines;
                    var all = new string[first.Length + usual.Length];
                    first.CopyTo(all, 0);
                    usual.CopyTo(all, first.Length);
                    var after = _afterTalk;
                    var gift = Trust.GiftIfDue(displayName);
                    Hud.OpenDialogue(this, displayName, all,
                        after == null && gift == null ? null : (System.Action)(() => { after?.Invoke(); gift?.Invoke(); }));
                }
            }
            else if (talkingToMe && distance > talkRange + 0.75f)
            {
                Hud.CloseDialogue();   // walked away mid-chat
            }
        }

        /// <summary>True when someone is close enough to talk to.</summary>
        public static bool AnyNear(Vector2 at)
        {
            foreach (var npc in All)
                if (!npc.Walking && Vector2.Distance(at, npc.transform.position) < npc.talkRange) return true;
            return false;
        }

        // How they feel about your creature: back away while afraid, blurt something out when it
        // comes close, and now and then say something to whoever's standing near them.
        void Feelings()
        {
            var trust = Trust.Get(displayName);
            Vector2 want = Vector2.zero;
            if (trust != null)
            {
                Vector2 here = (Vector2)transform.position - Shy;
                bool talking = ReferenceEquals(Hud.Speaker, this);
                bool near = Creatures.FollowerAt(out var creature) && Vector2.Distance(creature, here) < ReactRange;
                if (near && trust.Stage == TrustStage.Afraid && !Walking && !talking && Vector2.Distance(creature, here) < ScaredRange)
                    want = (here - creature).sqrMagnitude > 0.0001f ? (here - creature).normalized * ShyDistance : Vector2.down * ShyDistance;

                _reactCool -= Time.deltaTime;
                _chatCool -= Time.deltaTime;
                if (near && _reactCool <= 0f && !talking && !Bubbles.Speaking(transform))
                {
                    Bubbles.Say(transform, TownLines.Reaction(trust.Stage));
                    _reactCool = trust.Stage == TrustStage.Afraid ? Random.Range(6f, 10f) : Random.Range(14f, 26f);
                }
                else if (!near && _chatCool <= 0f)
                {
                    _chatCool = Random.Range(25f, 50f);
                    var partner = Partner();
                    var player = PlayerController.Instance;
                    if (partner != null && !talking && player != null && Vector2.Distance(player.transform.position, transform.position) < 10f)
                    {
                        Bubbles.Say(transform, TownLines.Chat(trust.Stage));
                        var other = Trust.Get(partner.displayName);
                        Bubbles.Say(partner.transform, TownLines.Chat(other.Stage), 2.2f);
                        partner._chatCool = Random.Range(25f, 50f);
                    }
                }
            }

            // Back away (or come back) smoothly. The town places its residents itself, adding Shy;
            // anyone else stands where they were put, so they're placed here.
            var next = Vector2.MoveTowards(Shy, want, ShySpeed * Time.deltaTime);
            if (!Managed)
            {
                if (Shy.sqrMagnitude < 0.000001f) _anchor = transform.position;
                if (next.sqrMagnitude > 0.000001f || Shy.sqrMagnitude > 0.000001f) transform.position = _anchor + next;
            }
            Shy = next;
        }

        // Someone with a meter standing close by, with nothing to say right now.
        Npc Partner()
        {
            foreach (var npc in All)
            {
                if (npc == this || !Trust.Knows(npc.displayName)) continue;
                if (Vector2.Distance(npc.transform.position, transform.position) > 3.5f) continue;
                if (Bubbles.Speaking(npc.transform) || ReferenceEquals(Hud.Speaker, npc)) continue;
                return npc;
            }
            return null;
        }

        static Npc Closest(PlayerController player)
        {
            Npc best = null;
            float bestDistance = float.MaxValue;
            foreach (var npc in All)
            {
                if (npc.Walking) continue;
                float d = Vector2.Distance(player.transform.position, npc.transform.position);
                if (d < bestDistance) { bestDistance = d; best = npc; }
            }
            return best;
        }
    }
}
