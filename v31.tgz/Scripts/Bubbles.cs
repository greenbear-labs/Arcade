using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// Little speech bubbles over people's heads: what townsfolk blurt out when your creature
    /// comes near, what they say to each other, and their reactions in the town events.
    /// They follow whoever's talking, fade after a few seconds, and are drawn under the HUD.
    /// </summary>
    public class Bubbles : MonoBehaviour
    {
        const float Life = 2.8f, Head = 1.95f;

        class Bubble
        {
            public Transform Over;      // follows this, or stays at At if it's null
            public Vector2 At;
            public string Text;
            public float Start, End;
        }

        static Bubbles _instance;
        readonly List<Bubble> _bubbles = new List<Bubble>();
        Texture2D _white;
        GUIStyle _style;

        void Awake()
        {
            _instance = this;
            _white = Texture2D.whiteTexture;
        }

        void OnDestroy()
        {
            if (_instance == this) _instance = null;
        }

        /// <summary>Pop a bubble over someone, after an optional delay (so a reply comes after the remark).</summary>
        public static void Say(Transform over, string text, float delay = 0f, float seconds = Life)
        {
            if (_instance == null || over == null || string.IsNullOrEmpty(text)) return;
            if (delay <= 0f) _instance._bubbles.RemoveAll(b => b.Over == over && b.Start <= Time.time);     // a new remark replaces the last one
            float start = Time.time + delay;
            _instance._bubbles.Add(new Bubble { Over = over, Text = text, Start = start, End = start + seconds + text.Length * 0.03f });
        }

        /// <summary>A bubble from a spot (a window, a doorway) rather than a person.</summary>
        public static void SayAt(Vector2 at, string text, float delay = 0f, float seconds = Life)
        {
            if (_instance == null || string.IsNullOrEmpty(text)) return;
            float start = Time.time + delay;
            _instance._bubbles.Add(new Bubble { At = at, Text = text, Start = start, End = start + seconds + text.Length * 0.03f });
        }

        /// <summary>Is this person in the middle of saying something (or about to)?</summary>
        public static bool Speaking(Transform over)
        {
            if (_instance == null) return false;
            foreach (var b in _instance._bubbles) if (b.Over == over && Time.time < b.End) return true;
            return false;
        }

        void Update()
        {
            _bubbles.RemoveAll(b => Time.time >= b.End || (b.Over == null && b.At == Vector2.zero));
        }

        void OnGUI()
        {
            if (_bubbles.Count == 0 || Hud.MenuOpen || Hud.InTransition) return;
            var cam = Camera.main;
            if (cam == null) return;
            GUI.depth = 5;      // under the HUD (which draws at depth 0)
            int s = Mathf.Max(2, Mathf.RoundToInt(Screen.height / 270f));
            if (_style == null) _style = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, wordWrap = true, fontStyle = FontStyle.Bold };
            _style.fontSize = 5 * s;
            _style.normal.textColor = new Color32(0x2b, 0x1d, 0x1a, 0xff);

            foreach (var b in _bubbles)
            {
                if (Time.time < b.Start) continue;
                if (b.Over != null && !b.Over.gameObject.activeInHierarchy) continue;
                Vector2 world = b.Over != null ? (Vector2)b.Over.position + new Vector2(0f, Head) : b.At;
                Vector3 sp = cam.WorldToScreenPoint(world);
                if (sp.z < 0f || sp.x < -100 || sp.x > Screen.width + 100 || sp.y < -50 || sp.y > Screen.height + 100) continue;

                float maxW = 80 * s;
                var content = new GUIContent(b.Text);
                float w = Mathf.Min(maxW, _style.CalcSize(content).x + 6 * s);
                float h = _style.CalcHeight(content, w - 4 * s) + 3 * s;
                float x = sp.x - w / 2f, y = Screen.height - sp.y - h - 3 * s;
                // Fade in quickly, and out at the end.
                float age = Time.time - b.Start, left = b.End - Time.time;
                float alpha = Mathf.Clamp01(Mathf.Min(age / 0.15f, left / 0.4f));

                var old = GUI.color;
                GUI.color = new Color(0.17f, 0.11f, 0.1f, alpha);
                GUI.DrawTexture(new Rect(x - s, y - s, w + 2 * s, h + 2 * s), _white);
                GUI.DrawTexture(new Rect(sp.x - 2 * s, y + h, 4 * s, 2 * s), _white);         // the tail
                GUI.DrawTexture(new Rect(sp.x - 1 * s, y + h + 2 * s, 2 * s, 1 * s), _white);
                GUI.color = new Color(1f, 0.98f, 0.92f, alpha);
                GUI.DrawTexture(new Rect(x, y, w, h), _white);
                GUI.DrawTexture(new Rect(sp.x - 1 * s, y + h, 2 * s, 1.5f * s), _white);
                GUI.color = new Color(1f, 1f, 1f, alpha);
                GUI.Label(new Rect(x + 2 * s, y, w - 4 * s, h), b.Text, _style);
                GUI.color = old;
            }
        }
    }
}
