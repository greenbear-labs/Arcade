using System.Collections;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// The first things your creatures do that win the town round. Each plays out in three beats:
    /// townsfolk point out the trouble in speech bubbles (and give you a clue when you chat), you
    /// sort it out with the right creature, and the town reacts: bubbles, and everyone's trust grows.
    ///
    /// - The rubble: a wall has come down on Bea's door. Your cannonball turtle rams it clear (three hits).
    ///   A town event: everyone's meter grows, and Bea's most of all.
    /// - The square lamps: the four lamps round the square have stopped working at night. Your phoenix
    ///   flies up and lights each one. A town event; Hank, who was scared of the dark square, most of all.
    /// - The frisbee: Wren and Tuck's frisbee is stuck on the bakery roof. Your Enfield portals up and
    ///   brings it down. A personal task: the kids' trust jumps a whole stage, and their mum and gran notice.
    /// </summary>
    public class TownEvents : MonoBehaviour
    {
        public static bool RubbleCleared { get; private set; }
        public static bool LampsLit { get; private set; }
        public static bool FrisbeeFetched { get; private set; }

        // ---------------------------------------------------------------- where it all happens

        /// <summary>The rubble heap, in front of Bea's door (her shop's door is at 56, 21).</summary>
        static readonly Vector2 Rubble = new Vector2(56f, 20.05f);
        /// <summary>Where you stand to set the turtle on it.</summary>
        static readonly Vector2 RubbleFront = new Vector2(56f, 19.35f);
        /// <summary>Where Bea frets while she can't get in.</summary>
        public static readonly Vector2 BeaWaits = new Vector2(58.9f, 19.4f);
        /// <summary>The frisbee, up on the bakery roof.</summary>
        static readonly Vector2 Frisbee = new Vector2(55f, 16.6f);
        /// <summary>Where you stand to ask the Enfield to fetch it: by the bakery's corner, clear of the door.</summary>
        static readonly Vector2 FrisbeeAsk = new Vector2(54.4f, 13.3f);
        /// <summary>Things up on the bakery roof sort just in front of the bakery.</summary>
        public const float RoofSortY = 13.9f;
        /// <summary>Where Wren and Tuck play, out front of the bakery.</summary>
        public static readonly Vector2[] KidSpots = { new Vector2(58.4f, 13.6f), new Vector2(59.5f, 13.2f) };

        const int RubbleHits = 3;
        const int TownEventTrust = 10, PersonalTrust = 20, OwnerBonus = 15, OnlookerTrust = 6;

        static readonly bool[] Lit = new bool[4];
        /// <summary>Is this square lamp working (all of them, once the phoenix has relit them)?</summary>
        public static bool LampLit(int i) => LampsLit || (i >= 0 && i < Lit.Length && Lit[i]);

        static TownEvents _instance;
        SpriteRenderer _rubble, _frisbee, _prompt;
        BoxCollider2D _rubbleBox;
        Sprite[] _rubbleFrames;
        int _hits;
        bool _ramming, _kindling, _fetching;
        float _setupCool, _darkCool;

        public static void Restore(bool rubble, bool lamps, bool frisbee)
        {
            RubbleCleared = rubble;
            LampsLit = lamps;
            FrisbeeFetched = frisbee;
            for (int i = 0; i < Lit.Length; i++) Lit[i] = lamps;
            if (_instance != null) _instance.Refresh();
        }

        public void Build(Sprite prompt)
        {
            _instance = this;
            RubbleCleared = LampsLit = FrisbeeFetched = false;
            for (int i = 0; i < Lit.Length; i++) Lit[i] = false;

            _rubbleFrames = Art.Strip("rubble", 32, 24);
            var rubble = new GameObject("Rubble");
            rubble.transform.SetParent(transform, false);
            rubble.transform.position = Rubble;
            _rubble = rubble.AddComponent<SpriteRenderer>();
            rubble.AddComponent<YSort>();
            FarmDemoWorld.Tall(rubble);
            _rubbleBox = rubble.AddComponent<BoxCollider2D>();
            _rubbleBox.size = new Vector2(2.6f, 1f);
            _rubbleBox.offset = new Vector2(0f, 0.5f);

            var frisbee = new GameObject("Frisbee");
            frisbee.transform.SetParent(transform, false);
            frisbee.transform.position = Frisbee;
            _frisbee = frisbee.AddComponent<SpriteRenderer>();
            _frisbee.sprite = Art.Single("frisbee", new Vector2(0.5f, 0.5f));
            _frisbee.sortingOrder = YSort.Order(RoofSortY) + 10;

            _prompt = new GameObject("Event prompt").AddComponent<SpriteRenderer>();
            _prompt.transform.SetParent(transform, false);
            _prompt.sprite = prompt;
            _prompt.sortingOrder = 32000;
            _prompt.enabled = false;
            Refresh();
        }

        void OnDestroy()
        {
            if (_instance == this) _instance = null;
        }

        void Refresh()
        {
            if (_rubble != null)
            {
                _rubble.enabled = !RubbleCleared;
                _rubbleBox.enabled = !RubbleCleared;
                if (_rubbleFrames != null) _rubble.sprite = _rubbleFrames[Mathf.Clamp(_hits, 0, _rubbleFrames.Length - 1)];
            }
            if (_frisbee != null) _frisbee.enabled = !FrisbeeFetched && !_fetching;
        }

        static Npc Find(string name)
        {
            foreach (var npc in Npc.Everyone) if (npc.displayName == name && npc.gameObject.activeInHierarchy) return npc;
            return null;
        }

        static void Say(string who, string text, float delay = 0f)
        {
            var npc = Find(who);
            if (npc != null) Bubbles.Say(npc.transform, text, delay, 3.2f);
        }

        // A line from whoever's nearby, about what just happened, in their own stage's voice.
        static void Onlookers(Vector2 at, float range, string[] byStage, float delay, params string[] skip)
        {
            int n = 0;
            foreach (var npc in Npc.Everyone)
            {
                if (n >= 3 || !Trust.Knows(npc.displayName) || System.Array.IndexOf(skip, npc.displayName) >= 0) continue;
                if (Vector2.Distance(npc.transform.position, at) > range) continue;
                Bubbles.Say(npc.transform, byStage[(int)Trust.Stage(npc.displayName)], delay + 0.6f * n, 3.2f);
                n++;
            }
        }

        void ShowPrompt(Vector2 over)
        {
            _prompt.enabled = true;
            _prompt.transform.position = over + new Vector2(0f, Mathf.Sin(Time.time * 5f) > 0f ? 1f / FarmDemoConfig.PixelsPerUnit : 0f);
        }

        // ---------------------------------------------------------------- every frame

        void Update()
        {
            _prompt.enabled = false;
            _setupCool -= Time.deltaTime;
            _darkCool -= Time.deltaTime;
            var player = PlayerController.Instance;
            if (player == null || Town.Inside || Home.Inside || Mine.Inside || Cavern.Inside || DarkCave.Inside) return;
            Vector2 feet = player.transform.position;
            Setup(feet);
            if (Hud.Busy || player.Locked || player.IsAttacking || Creatures.Riding) return;
            if (!RubbleCleared && RubbleTask(player, feet)) return;
            if (!LampsLit && LampTask(feet)) return;
            if (!FrisbeeFetched) FrisbeeTask(feet);
        }

        // Beat one: as you come near, the people with the trouble point it out.
        void Setup(Vector2 feet)
        {
            if (_setupCool > 0f) return;
            if (!RubbleCleared && Vector2.Distance(feet, Rubble) < 6f && !_ramming)
            {
                _setupCool = 25f;
                Say("Bea", "My door! My poor shop!");
                Say("Bea", "Who could ever move all that?", 3.4f);
                return;
            }
            if (!FrisbeeFetched && Vector2.Distance(feet, KidSpots[0]) < 6f && !_fetching)
            {
                _setupCool = 25f;
                Say("Tuck", "Our frisbee! It's stuck!");
                Say("Wren", "Up on Grandma's roof. Forever.", 2.4f);
                return;
            }
            if (!LampsLit && GameClock.Darkness > 0.25f && Vector2.Distance(feet, Town.Fountain) < 9f && _darkCool <= 0f && !_kindling)
            {
                _darkCool = 40f;
                _setupCool = 10f;
                Bubbles.SayAt(Town.PipsDoor + new Vector2(0f, 2.6f), "(from a window) It's so dark out there...");
                var pip = Find("Pip");
                if (pip != null) Bubbles.Say(pip.transform, "Um. Hello? Anybody? Who turned the lamps off?", 1.5f);
            }
        }

        // ---------------------------------------------------------------- the rubble

        bool RubbleTask(PlayerController player, Vector2 feet)
        {
            if (_ramming && !CannonTurtle.IsRamming) _ramming = false;
            if (_ramming) return true;
            if (Vector2.Distance(feet, RubbleFront) > 1.1f || player.Facing != Facing.Up) return false;
            if (!CannonTurtle.Following)
            {
                Hud.SetPrompt(CannonTurtle.Friend ? "A heap of fallen stones blocks Bea's door. Your cannonball turtle could ram it! (Bag > Creatures)"
                    : "A heap of fallen stones blocks Bea's door. Something built like a cannonball might shift it...");
                return true;
            }
            ShowPrompt(Rubble + new Vector2(0f, 2.2f));
            Hud.SetPrompt("E  Ram the rubble");
            if (GameInput.TalkPressed() && CannonTurtle.Ram(Rubble + new Vector2(0f, 0.3f), RubbleHit))
            {
                _ramming = true;
                Hud.Toast(_hits == 0 ? "Go on, turtle! Ram it!" : "Again! Ram it!", 1.5f);
            }
            return true;
        }

        void RubbleHit()
        {
            _ramming = false;
            _hits++;
            CameraFollow.Shake(0.35f, 0.15f);
            if (_hits < RubbleHits)
            {
                Refresh();
                Hud.Toast(_hits == 1 ? "CRUNCH! The heap shifts. Ram it again!" : "CRASH! Nearly there. Once more!", 2.5f);
                Onlookers(Rubble, 7f, new[] { "Eek! It's smashing things!", "What's it doing?!", "Whoa!", "Go on, turtle!", "Go, turtle, go!" }, 0.2f, "Bea");
                return;
            }
            RubbleCleared = true;
            Refresh();
            Hud.Toast("BOOM! The rubble's gone, and Bea's door is clear!", 3f);
            StartCoroutine(RubblePayoff());
        }

        // Beat three: Bea gets her shop back, and the town talks about the turtle.
        IEnumerator RubblePayoff()
        {
            Say("Bea", "My door! Oh, my door!");
            Say("Bea", "Th-thank you. And... thank you, turtle.", 3f);
            Onlookers(Rubble, 9f, new[] { "It could have flattened us!", "...Well. That'd have taken us a week.", "Did you see that?!", "Good turtle!", "That's our turtle!" }, 1.2f, "Bea");
            yield return new WaitForSeconds(3.5f);
            Trust.Add("Bea", OwnerBonus, quiet: true);
            Trust.Town(TownEventTrust, "Everyone's talking about the turtle that cleared Bea's door.");
        }

        // ---------------------------------------------------------------- the square lamps

        bool LampTask(Vector2 feet)
        {
            if (_kindling) return true;
            if (GameClock.Darkness < 0.25f) return false;
            int near = -1;
            for (int i = 0; i < Town.SquareLamps.Length; i++)
                if (!Lit[i] && Vector2.Distance(feet, Town.SquareLamps[i] + new Vector2(0f, -0.4f)) < 1.3f) near = i;
            if (near < 0) return false;
            if (!Phoenix.Following)
            {
                Hud.SetPrompt(Phoenix.Friend ? "The lamp's gone dark. Your phoenix could light it! (Bag > Creatures)"
                    : "The lamp's gone dark, and it won't relight. It needs a real flame...");
                return true;
            }
            ShowPrompt(Town.SquareLamps[near] + new Vector2(0f, 2.3f));
            Hud.SetPrompt("E  Ask the phoenix to light the lamp");
            int lamp = near;
            if (GameInput.TalkPressed() && Phoenix.Kindle(Town.SquareLamps[lamp], () => LampDone(lamp))) _kindling = true;
            return true;
        }

        void LampDone(int i)
        {
            _kindling = false;
            Lit[i] = true;
            int lit = 0;
            foreach (bool l in Lit) if (l) lit++;
            if (lit < Lit.Length)
            {
                Hud.Toast(lit == 1 ? "The lamp blazes into life! Three more round the square." : lit == 2 ? "Another lamp lit. Two to go." : "One lamp left!", 2.5f);
                return;
            }
            LampsLit = true;
            Hud.Toast("Every lamp round the square is shining again!", 3f);
            StartCoroutine(LampsPayoff());
        }

        // Beat three: faces at the windows, and the town sees the phoenix in a new light.
        IEnumerator LampsPayoff()
        {
            var windows = new[] { Town.PipsDoor, Town.Homes[0], Town.Homes[1], Town.BakeryDoor };
            string[] said = { "Fire! ...Oh. Oh, it's the lamps.", "Was that the phoenix?!", "Look at the square! It's beautiful.", "The lamps are back!" };
            for (int i = 0; i < windows.Length; i++) Bubbles.SayAt(windows[i] + new Vector2(0f, 2.7f), "(from a window) " + said[i], 0.4f + i * 1.1f, 3.4f);
            var pip = Find("Pip");
            if (pip != null) Bubbles.Say(pip.transform, "The fountain sparkles! The raccoons are weeping.", 4.6f, 3.4f);
            yield return new WaitForSeconds(4.5f);
            Trust.Add("Hank", OwnerBonus, quiet: true);
            Trust.Town(TownEventTrust, "The whole town saw your phoenix light up the square.");
        }

        // ---------------------------------------------------------------- the frisbee

        void FrisbeeTask(Vector2 feet)
        {
            if (_fetching) return;
            if (Vector2.Distance(feet, FrisbeeAsk) > 1f) return;
            if (!Enfield.Following)
            {
                Hud.SetPrompt(Enfield.Friend ? "A frisbee's stuck up on the bakery roof. Your Enfield could portal up there! (Bag > Creatures)"
                    : "A frisbee's stuck up on the bakery roof. Something that can hop through portals might reach it...");
                return;
            }
            ShowPrompt(Frisbee + new Vector2(0f, 0.8f));
            Hud.SetPrompt("E  Ask the Enfield to fetch the frisbee");
            if (!GameInput.TalkPressed()) return;
            if (!Enfield.Fetch(Frisbee + new Vector2(0f, -0.2f), () => { _fetching = true; Refresh(); }, FrisbeeBack)) return;
            Say("Tuck", "Whoa! Look!");
        }

        void FrisbeeBack()
        {
            _fetching = false;
            FrisbeeFetched = true;
            Refresh();
            StartCoroutine(FrisbeePayoff());
        }

        // Beat three: the kids get their frisbee, and Hazel sees it from her shop door.
        IEnumerator FrisbeePayoff()
        {
            Hud.Toast("The Enfield brought the frisbee down!", 2.5f);
            Say("Tuck", "IT GOT IT!! It just went POP and got it!");
            Say("Wren", "Thank you, Enfield! Can it play with us?", 2.2f);
            Bubbles.SayAt(Town.BakeryDoor + new Vector2(0f, 4.4f), "(Mabel, from the window) Well, I never.", 4.2f, 3.4f);
            yield return new WaitForSeconds(5f);
            Trust.Add("Wren", PersonalTrust);
            Trust.Add("Tuck", PersonalTrust);
            Trust.Add("Hazel", OnlookerTrust, quiet: true);
            Trust.Add("Mabel the Baker", OnlookerTrust, quiet: true);
        }
    }
}
