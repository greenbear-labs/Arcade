namespace FarmDemo
{
    /// <summary>
    /// Every number the demo depends on lives here. To swap in a different
    /// character sheet (Ninja Adventure, Sprout Lands, your own), drop the PNG in
    /// Assets/FarmDemo/Resources/FarmDemo/ and change the Character* values.
    /// </summary>
    public static class FarmDemoConfig
    {
        // One world unit = one tile = this many pixels.
        public const int PixelsPerUnit = 16;

        // Character sheet: Resources path (no extension), frame size, and layout.
        public const string CharacterSheet = "farmer";   // in Resources/FarmDemo/
        public const int CharacterFrameWidth = 16;
        public const int CharacterFrameHeight = 24;
        public const int CharacterFramesPerDirection = 4;

        // Which row (counted from the TOP of the image) holds each facing.
        public const int RowDown = 0;
        public const int RowUp = 1;
        public const int RowLeft = 2;
        public const int RowRight = 3;

        // Movement, in tiles per second, and walk animation speed.
        public const float WalkSpeed = 4.5f;
        public const float RunMultiplier = 1.6f;
        public const float WalkFps = 8f;

        // Tileset: 16x16 tiles, 8 per row. Indexes count left-to-right, top-to-bottom.
        public const string Tileset = "tiles";
        public const int TileSize = 16;
        public const int TileGrassA = 0, TileGrassB = 1, TileFlowersWhite = 2, TileFlowersPink = 3;
        public const int TilePath = 4, TileSoil = 5, TileGrassC = 6, TileGrassD = 7;
        // 16 water tiles; add a bitmask of land neighbours (N=1, E=2, S=4, W=8).
        public const int TileWaterBase = 8;

        // Camera: the game is drawn at this many pixels tall, then scaled up by a whole number.
        public const int TargetVerticalPixels = 180;

        // Map size in tiles.
        public const int MapLeft = -24;      // the mountain, west of the farm
        public const int MapWidth = 140;     // the farm (48 wide), then the town round its square, houses out to the east
        public const int MapHeight = 46;     // the farm (32 high), then the meadow to the north
        public const int MapBottom = -24;    // the forest, south of the town

        // Real seconds for the 20 waking hours from 6 AM to 2 AM. The clock keeps going through the night
        // at the same pace, so a whole day and night (6 AM to 6 AM) takes 1.2 times this.
        public const float DayLengthSeconds = 180f;

        // This region's season. Seasons don't change over time any more: each part of the world has its own
        // (later towns might be in fall or winter). Spring is the art as drawn.
        public const Season RegionSeason = Season.Spring;
    }
}
