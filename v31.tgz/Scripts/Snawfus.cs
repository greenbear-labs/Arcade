using System.Collections.Generic;
using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// The Snawfus: a forest deer whose antlers are little trees, with moss down its
    /// back. A music creature. Stand in the toadstool ring in the forest and play the
    /// flute, and it steps out of the trees and comes to you: then it's your friend.
    /// It walks along after you, and you can ride it (E beside it, or from the bag).
    /// Wherever it walks, little flowers bloom behind it for a moment and fade.
    /// </summary>
    public class Snawfus : MonoBehaviour
    {
        enum State { Away, Coming, Friend }

        const float TuneToCall = 2f;                // seconds of music in the ring
        const float ComeSpeed = 1.6f, FriendWalk = 4.2f, RiderLift = 0.6f, RideSpeedUp = 1.6f;
        const float BloomEvery = 0.45f, BloomGrow = 0.25f, BloomStay = 2.5f, BloomFade = 0.8f;

        static Snawfus _instance;
        public static bool Riding { get; private set; }
        public static bool Friend => _instance != null && _instance._state == State.Friend;
        public static bool Following => Friend && Creatures.Follower == CreatureKind.Snawfus;
        /// <summary>Where it is in the world right now.</summary>
        public static Vector2 Where => _instance != null ? (Vector2)_instance.transform.position : Vector2.zero;
        public static Sprite Icon => _instance != null && _instance._frames != null ? _instance._frames[0] : null;
        public static float SpeedBoost => Riding ? RideSpeedUp : 1f;
        static bool Indoors => Home.Inside || Mine.Inside || Cavern.Inside || DarkCave.Inside || Town.Inside;
        public static bool CanRide => Following && !Riding && !Creatures.Riding && !Indoors;

        State _state = State.Away;
        bool _shown;
        Vector2 _pos, _target, _lastPlayer;
        float _clock, _wait, _playerStill, _bloomWalk, _cooldown;
        Slime _slime;
        Sprite[] _frames, _blooms;
        Sprite[][] _farmer;
        SpriteRenderer _sprite, _shadow;

        class Bloom { public SpriteRenderer Sprite; public float Age; }
        readonly List<Bloom> _live = new List<Bloom>();
        readonly Stack<SpriteRenderer> _spare = new Stack<SpriteRenderer>();

        public static void Restore(bool friend)
        {
            if (_instance == null) return;
            _instance._state = friend ? State.Friend : State.Away;
        }

        public void Build()
        {
            _instance = this;
            Riding = false;
            _frames = Art.Strip("snawfus", 32, 32);
            _blooms = Art.Strip("bloom", 8, 8, new Vector2(0.5f, 0.2f));
            _farmer = Art.Directional(FarmDemoConfig.CharacterSheet, FarmDemoConfig.CharacterFrameWidth, FarmDemoConfig.CharacterFrameHeight);
            _shadow = new GameObject("Shadow").AddComponent<SpriteRenderer>();
            _shadow.transform.SetParent(transform, false);
            _shadow.sprite = Art.Single("shadow", new Vector2(0.5f, 0.5f));
            _shadow.sortingOrder = FarmDemoWorld.ShadowOrder;
            _shadow.transform.localScale = new Vector3(1.5f, 0.9f, 1f);
            _sprite = new GameObject("Sprite").AddComponent<SpriteRenderer>();
            _sprite.transform.SetParent(transform, false);
            GameClock.NewDay += Morning;
            GameClock.WokeUp += WakeUp;
        }

        void OnDestroy()
        {
            GameClock.NewDay -= Morning;
            GameClock.WokeUp -= WakeUp;
            if (_instance == this) { _instance = null; Riding = false; }
        }

        void WakeUp()
        {
            if (Riding) Dismount(true);
        }

        void Morning()
        {
            if (_state == State.Coming) _state = State.Away;     // it wandered back into the woods
        }

        // ------------------------------------------------------------- riding

        public static void Ride()
        {
            if (!CanRide || _instance == null || PlayerController.Instance == null) return;
            var player = PlayerController.Instance;
            Riding = true;
            var body = player.GetComponentInChildren<SpriteSheetAnimator>();
            if (body != null)
            {
                body.transform.localPosition = new Vector3(0f, RiderLift, 0f);
                var sort = body.GetComponent<YSort>();
                if (sort != null) sort.enabled = false;
            }
            _instance._pos = player.transform.position;
            Hud.Toast("Up you get! Flowers bloom wherever the Snawfus walks. Press E to get down.", 3f);
        }

        /// <summary>Climb down beside it.</summary>
        public static void Dismount(bool force)
        {
            if (!Riding) return;
            Riding = false;
            var player = PlayerController.Instance;
            if (player == null) return;
            var body = player.GetComponentInChildren<SpriteSheetAnimator>();
            if (body != null)
            {
                body.transform.localPosition = Vector3.zero;
                var sort = body.GetComponent<YSort>();
                if (sort != null) sort.enabled = true;
            }
            player.ShowPose(null);
            if (_instance != null)
            {
                _instance._pos = (Vector2)player.transform.position + new Vector2(player.Facing == Facing.Left ? 1.3f : -1.3f, 0f);
                _instance._target = _instance._pos;
                _instance._wait = 1f;
            }
        }

        // ------------------------------------------------------------- update

        void Update()
        {
            UpdateBlooms();
            bool shown = _state == State.Coming || (Following && (!Indoors || Riding));
            _sprite.enabled = _shadow.enabled = shown && _frames != null;
            var player = PlayerController.Instance;
            Vector2 playerPos = player != null ? (Vector2)player.transform.position : Forest.Ring;
            _playerStill = Vector2.Distance(playerPos, _lastPlayer) < 0.01f ? _playerStill + Time.deltaTime : 0f;
            _lastPlayer = playerPos;
            _clock += Time.deltaTime;

            if (_state == State.Away) { Listen(player, playerPos); return; }
            if (!shown || _frames == null) { _shown = false; return; }
            if (_state == State.Friend && !Riding && (!_shown || Vector2.Distance(_pos, playerPos) > 12f))
                _pos = _target = playerPos + new Vector2(-1.6f, 0.2f);
            _shown = true;

            Vector2 before = _pos;
            if (Riding) RideAlong(player);
            else if (_state == State.Coming) Come(player, playerPos);
            else Friendly(player, playerPos);

            // Flowers in its tracks.
            _bloomWalk += Vector2.Distance(before, _pos);
            if (_bloomWalk >= BloomEvery)
            {
                _bloomWalk = 0f;
                SpawnBloom(_pos + new Vector2(Random.Range(-0.35f, 0.35f), Random.Range(-0.15f, 0.1f)));
            }

            transform.position = _pos;
            bool walking = Riding ? player != null && _playerStill <= 0f : (_target - _pos).sqrMagnitude > 0.0004f;
            int frame = walking ? 1 + Mathf.FloorToInt(_clock * 6f) % 2 : _playerStill > 2f && !Riding ? 3 : 0;
            _sprite.sprite = _frames[Mathf.Min(frame, _frames.Length - 1)];
            if (!Riding) _sprite.sortingOrder = YSort.Order(_pos.y);
        }

        // Out in the woods: it hears a tune played in the toadstool ring.
        void Listen(PlayerController player, Vector2 playerPos)
        {
            if (player == null || !Flute.Playing || Flute.PlayingFor < TuneToCall || Indoors) return;
            Vector2 d = playerPos - Forest.Ring;
            if ((d.x / 2.6f) * (d.x / 2.6f) + (d.y / 1.9f) * (d.y / 1.9f) > 1f) return;
            // It steps out of the trees on the far side of the ring from you.
            float side = playerPos.x < Forest.Ring.x ? 1f : -1f;
            _pos = _target = Forest.Ring + new Vector2(side * 6.5f, 1.2f);
            _sprite.flipX = side < 0f;
            _state = State.Coming;
            Hud.Toast("Something is rustling in the trees...", 2.5f);
        }

        void Come(PlayerController player, Vector2 playerPos)
        {
            Vector2 d = playerPos - _pos;
            if (d.magnitude > 1.5f) { _target = playerPos; MoveToward(playerPos, ComeSpeed); return; }
            _target = _pos;
            _state = State.Friend;
            Creatures.Follow(CreatureKind.Snawfus);
            StartCoroutine(Creatures.HeartPop(transform, 1.9f));
            Hud.ShowPopup(_frames[0], "The Snawfus has chosen you!",
                "It came out of the woods for your music. It'll walk along with you, and you can ride it: walk up and press E. Only one creature follows you at a time.");
        }

        // A friend: walks after you, grazes when you stop, charges slimes, and lets you climb on.
        void Friendly(PlayerController player, Vector2 playerPos)
        {
            _cooldown -= Time.deltaTime;
            if (_slime == null || _slime.health <= 0) _slime = _cooldown <= 0f ? Creatures.NearestSlime(_pos, playerPos, 4.5f) : null;
            if (_slime != null)
            {
                // Head down, antlers first.
                Vector2 at = _slime.transform.position;
                _target = at;
                MoveToward(at, FriendWalk * 1.4f);
                if (Vector2.Distance(_pos, at) < 0.6f)
                {
                    _slime.Hit(_pos, 1);
                    _cooldown = 1.1f;
                    _slime = null;
                    _pos += (_pos - at).normalized * 0.5f;
                    _target = _pos;
                }
                return;
            }
            float far = Vector2.Distance(_pos, playerPos);
            if (far > 2.4f) { _target = playerPos + (_pos - playerPos).normalized * 1.8f; MoveToward(_target, far > 5f ? FriendWalk * 1.2f : FriendWalk); }
            else if (_playerStill > 1.5f && (_wait -= Time.deltaTime) <= 0f)
            {
                _target = playerPos + Random.insideUnitCircle.normalized * Random.Range(1.4f, 2.2f);
                _wait = Random.Range(2f, 4f);
            }
            else MoveToward(_target, 0.8f);

            if (player == null || Hud.Busy || player.Locked || !CanRide) return;
            if (Vector2.Distance((Vector2)player.transform.position, _pos) > 1.8f) return;
            Hud.SetPrompt("E  Ride the Snawfus");
            if (GameInput.TalkPressed()) Ride();
        }

        void RideAlong(PlayerController player)
        {
            if (player == null) return;
            if (Indoors) { Dismount(true); return; }
            _pos = player.transform.position;
            _target = _pos;
            if (player.Facing == Facing.Left || player.Facing == Facing.Right) _sprite.flipX = player.Facing == Facing.Right;

            // You sit on its back, with a gentle sway as it walks.
            int order = YSort.Order(_pos.y);
            _sprite.sortingOrder = order;
            var body = player.GetComponentInChildren<SpriteSheetAnimator>();
            if (body != null)
            {
                float sway = _playerStill <= 0f ? Mathf.Abs(Mathf.Sin(_clock * 6f * Mathf.PI / 2f)) * 0.06f : 0f;
                body.transform.localPosition = new Vector3(0f, RiderLift + Mathf.Round(sway * 16f) / 16f, 0f);
                var sr = body.GetComponent<SpriteRenderer>();
                if (sr != null) sr.sortingOrder = order + 1;
            }
            if (_farmer != null) player.ShowPose(_farmer[(int)player.Facing][0]);
            if (!Hud.Busy)
            {
                Hud.ForcePrompt("E  Get down");
                if (GameInput.TalkKey()) Dismount(false);
            }
        }

        void MoveToward(Vector2 goal, float speed)
        {
            Vector2 d = goal - _pos;
            float step = speed * Time.deltaTime;
            _pos = d.magnitude <= step ? goal : _pos + d.normalized * step;
            if (Mathf.Abs(d.x) > 0.05f) _sprite.flipX = d.x > 0f;      // the art faces left
        }

        // ------------------------------------------------------------- flowers

        void SpawnBloom(Vector2 at)
        {
            if (_blooms == null || Indoors) return;
            var sr = _spare.Count > 0 ? _spare.Pop() : NewBloom();
            sr.gameObject.SetActive(true);
            sr.sprite = _blooms[Random.Range(0, _blooms.Length)];
            sr.transform.position = at;
            sr.transform.localScale = Vector3.zero;
            sr.color = Color.white;
            _live.Add(new Bloom { Sprite = sr, Age = 0f });
        }

        SpriteRenderer NewBloom()
        {
            var sr = new GameObject("Bloom").AddComponent<SpriteRenderer>();
            sr.transform.SetParent(transform.parent, false);
            sr.sortingOrder = FarmDemoWorld.ShadowOrder - 10;     // on the grass, under everyone's feet
            return sr;
        }

        void UpdateBlooms()
        {
            for (int i = _live.Count - 1; i >= 0; i--)
            {
                var b = _live[i];
                b.Age += Time.deltaTime;
                if (b.Age >= BloomGrow + BloomStay + BloomFade)
                {
                    b.Sprite.gameObject.SetActive(false);
                    _spare.Push(b.Sprite);
                    _live.RemoveAt(i);
                    continue;
                }
                float grow = Mathf.Clamp01(b.Age / BloomGrow);
                b.Sprite.transform.localScale = Vector3.one * (Mathf.Round(grow * 4f) / 4f);
                float fade = b.Age - BloomGrow - BloomStay;
                b.Sprite.color = new Color(1f, 1f, 1f, fade > 0f ? 1f - fade / BloomFade : 1f);
            }
        }
    }
}
