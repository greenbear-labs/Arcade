using System.Collections;
using UnityEngine;

namespace FarmDemo
{
    public enum CreatureKind { None, Jackalope, Turtle, BlimpBee, Enfield, Snawfus, Phoenix }

    /// <summary>
    /// Your creature friends. Only one of them follows you at a time; the others
    /// stay at home (out of sight). Pick who comes along in the bag's Creatures tab.
    /// </summary>
    public static class Creatures
    {
        public static CreatureKind Follower { get; private set; }

        public static void Reset() => Follower = CreatureKind.None;

        /// <summary>This one comes along now; whoever was following goes home.</summary>
        public static void Follow(CreatureKind kind)
        {
            if (Follower == CreatureKind.BlimpBee && kind != CreatureKind.BlimpBee) BlimpBee.Land(true);
            if (Follower == CreatureKind.Snawfus && kind != CreatureKind.Snawfus) Snawfus.Dismount(true);
            Follower = kind;
        }

        public static void StayHome(CreatureKind kind)
        {
            if (Follower == kind) Follow(CreatureKind.None);
        }

        /// <summary>A creature wants F this frame (you're feeding it), so eating and picking wait.</summary>
        public static bool WantUse => Jackalope.WantsBerry || CannonTurtle.WantsGem || BlimpBee.WantsUse || Enfield.WantsTrout || Flute.WantsTrade;

        /// <summary>Up on a creature's back (the blimp bee or the Snawfus).</summary>
        public static bool Riding => BlimpBee.Riding || Snawfus.Riding;

        public static CreatureKind Parse(string name) =>
            System.Enum.TryParse(name, out CreatureKind k) ? k : CreatureKind.None;

        /// <summary>A heart floats up over a creature you've just made happy.</summary>
        public static IEnumerator HeartPop(Transform over, float height)
        {
            var heart = Art.Strip("heart", 9, 8, new Vector2(0.5f, 0f))?[0];
            if (heart == null) yield break;
            var sr = new GameObject("Heart").AddComponent<SpriteRenderer>();
            sr.sprite = heart;
            sr.sortingOrder = 31500;
            for (float k = 0f; k < 1f; k += Time.deltaTime / 0.9f)
            {
                if (over == null) break;
                sr.transform.position = (Vector2)over.position + new Vector2(0f, height + k * 0.6f);
                sr.color = new Color(1f, 1f, 1f, k < 0.6f ? 1f : 1f - (k - 0.6f) / 0.4f);
                yield return null;
            }
            Destroy(sr.gameObject);
        }

        static void Destroy(Object o) => Object.Destroy(o);

        /// <summary>The nearest live slime close to both you and this spot, or null.</summary>
        public static Slime NearestSlime(Vector2 from, Vector2 playerPos, float range)
        {
            Slime best = null;
            float bestD = range;
            foreach (var col in Physics2D.OverlapCircleAll(from, range))
            {
                var slime = col.GetComponent<Slime>();
                if (slime == null || slime.health <= 0) continue;
                float d = Vector2.Distance(from, slime.transform.position);
                if (d < bestD && Vector2.Distance(playerPos, slime.transform.position) < range + 1f) { bestD = d; best = slime; }
            }
            return best;
        }
    }

    /// <summary>
    /// The cannonball turtle, up in the mountains. Sometimes it walks about like any
    /// turtle; sometimes it tucks in and rolls around like an iron ball. While it's
    /// walking, give it a gem (face it and press F). Three gems and it's your friend.
    /// As a friend it trots after you, rolls to catch up, and bowls into slimes.
    /// </summary>
    public class CannonTurtle : MonoBehaviour
    {
        public const int GemsToBefriend = 3;
        const float WalkSpeed = 0.7f, RollSpeed = 3.2f, FriendWalk = 2.4f, FriendRoll = 7f;
        const float HomeRadius = 2.6f;     // its patch of the mountain, clear of the pines

        static CannonTurtle _instance;
        public static bool Friend => _instance != null && _instance._friend;
        public static bool Following => Friend && Creatures.Follower == CreatureKind.Turtle;
        public static int GemsGiven => _instance != null ? _instance._gems : 0;
        public static Sprite Icon => _instance != null && _instance._frames != null ? _instance._frames[0] : null;
        /// <summary>You're beside the walking wild turtle with a gem in hand: F is for giving it.</summary>
        public static bool WantsGem => _instance != null && _instance._near && !_instance._friend && !_instance._ball && Inventory.SelectedItem == Items.Gem;

        bool _friend, _ball, _near, _shown;
        int _gems;
        Vector2 _home, _pos, _target, _dir;
        float _modeTime, _pause, _tuck, _clock, _cooldown, _playerStill;
        Vector2 _lastPlayer;
        Slime _slime;
        Sprite[] _frames;
        SpriteRenderer _sprite, _shadow;

        public static void Restore(bool friend, int gems)
        {
            if (_instance == null) return;
            _instance._friend = friend;
            _instance._gems = friend ? GemsToBefriend : Mathf.Clamp(gems, 0, GemsToBefriend - 1);
        }

        public void Build(Vector2 home)
        {
            _instance = this;
            _home = _pos = _target = home;
            _modeTime = 5f;
            _frames = Art.Strip("turtle", 16, 16);
            _shadow = new GameObject("Shadow").AddComponent<SpriteRenderer>();
            _shadow.transform.SetParent(transform, false);
            _shadow.sprite = Art.Single("shadow", new Vector2(0.5f, 0.5f));
            _shadow.sortingOrder = FarmDemoWorld.ShadowOrder;
            _shadow.transform.localScale = new Vector3(0.75f, 0.75f, 1f);
            _sprite = new GameObject("Sprite").AddComponent<SpriteRenderer>();
            _sprite.transform.SetParent(transform, false);
            _sprite.gameObject.AddComponent<YSort>().isStatic = false;
            transform.position = _pos;
        }

        void OnDestroy()
        {
            if (_instance == this) _instance = null;
        }

        void Update()
        {
            bool shown = !_friend || Following;
            _sprite.enabled = _shadow.enabled = shown && _frames != null;
            _near = false;
            if (!shown || _frames == null) { _shown = false; return; }

            var player = PlayerController.Instance;
            Vector2 playerPos = player != null ? (Vector2)player.transform.position : _home;
            if (_friend && (!_shown || Vector2.Distance(_pos, playerPos) > 12f)) Teleport(playerPos);
            _shown = true;
            _playerStill = Vector2.Distance(playerPos, _lastPlayer) < 0.01f ? _playerStill + Time.deltaTime : 0f;
            _lastPlayer = playerPos;
            _clock += Time.deltaTime;
            _tuck -= Time.deltaTime;
            _cooldown -= Time.deltaTime;

            if (_friend) Friendly(playerPos);
            else
            {
                Wild();
                Befriend(player);
            }

            transform.position = _pos;
            int frame = _tuck > 0f ? 4 : _ball ? 2 + Mathf.FloorToInt(_clock * 12f) % 2
                : (_pause > 0f || (_target - _pos).sqrMagnitude < 0.01f ? 0 : Mathf.FloorToInt(_clock * 4f) % 2);
            _sprite.sprite = _frames[Mathf.Min(frame, _frames.Length - 1)];
        }

        void Teleport(Vector2 near)
        {
            _pos = _target = near + new Vector2(Random.value < 0.5f ? -1f : 1f, -0.3f);
            SetBall(false);
            _slime = null;
        }

        void SetBall(bool ball)
        {
            if (ball != _ball) _tuck = 0.25f;     // a moment half in, half out of its shell
            _ball = ball;
        }

        void MoveToward(Vector2 goal, float speed)
        {
            Vector2 d = goal - _pos;
            float step = speed * Time.deltaTime;
            if (d.magnitude <= step) _pos = goal;
            else _pos += d.normalized * step;
            if (Mathf.Abs(d.x) > 0.02f) _sprite.flipX = d.x > 0f;      // the art faces left
        }

        // Wild: walk for a while, then tuck in and roll about, then walk again.
        void Wild()
        {
            _modeTime -= Time.deltaTime;
            if (_tuck > 0f) return;
            if (_ball)
            {
                _pos += _dir * RollSpeed * Time.deltaTime;
                if (Vector2.Distance(_pos, _home) > HomeRadius)
                    _dir = ((_home - _pos).normalized + Random.insideUnitCircle * 0.6f).normalized;   // bounce back toward home
                if (Mathf.Abs(_dir.x) > 0.02f) _sprite.flipX = _dir.x > 0f;
                if (_modeTime <= 0f) { SetBall(false); _target = _pos; _modeTime = Random.Range(6f, 9f); }
                return;
            }

            if (_pause > 0f) { _pause -= Time.deltaTime; return; }
            // Someone's holding out a gem: stop and look at them.
            var player = PlayerController.Instance;
            if (player != null && Inventory.SelectedItem == Items.Gem && PlayerNear(3f))
            {
                _target = _pos;
                if (Mathf.Abs(player.transform.position.x - _pos.x) > 0.1f) _sprite.flipX = player.transform.position.x > _pos.x;
                return;
            }
            if ((_target - _pos).sqrMagnitude < 0.01f)
            {
                _pause = Random.Range(0.5f, 1.8f);
                _target = _home + Random.insideUnitCircle * (HomeRadius - 0.3f);
                return;
            }
            MoveToward(_target, WalkSpeed);
            // Time to roll, unless someone's standing right here with a gem for it.
            if (_modeTime <= 0f && !_near && !(Inventory.SelectedItem == Items.Gem && PlayerNear(2.5f)))
            {
                SetBall(true);
                _dir = Random.insideUnitCircle.normalized;
                _modeTime = Random.Range(3f, 5f);
            }
        }

        bool PlayerNear(float range)
        {
            var player = PlayerController.Instance;
            return player != null && Vector2.Distance((Vector2)player.transform.position + new Vector2(0f, 0.15f), _pos) <= range;
        }

        void Befriend(PlayerController player)
        {
            if (player == null || Hud.Busy || player.Locked || !PlayerNear(2f)) return;
            _near = true;
            if (_ball) { Hud.SetPrompt("A cannonball turtle, rolling about! Wait till it walks."); return; }
            if (Inventory.SelectedItem != Items.Gem)
            {
                Hud.SetPrompt(Inventory.Has(Items.Gem) ? "A cannonball turtle! Pick a gem to offer it"
                    : _gems > 0 ? $"The cannonball turtle remembers you. ({_gems}/{GemsToBefriend} gems)" : "A cannonball turtle. It's eyeing anything shiny...");
                return;
            }
            Hud.SetPrompt($"F  Give the turtle a gem ({_gems}/{GemsToBefriend})");
            if (!GameInput.FishPressed() || Inventory.Remove(Items.Gem) == 0) return;
            _gems++;
            _pause = 1.2f;
            _target = _pos;
            _sprite.flipX = player.transform.position.x > _pos.x;
            _modeTime = Mathf.Max(_modeTime, 4f);
            StartCoroutine(Creatures.HeartPop(transform, 0.9f));
            if (_gems < GemsToBefriend) { Hud.Toast(_gems == 1 ? "The turtle crunches the gem happily!" : "It wants one more...", 1.8f); return; }
            _friend = true;
            Creatures.Follow(CreatureKind.Turtle);
            Hud.ShowPopup(_frames[0], "The cannonball turtle is your friend!",
                "It'll trot after you and roll into slimes. Only one creature follows you at a time: swap them in your bag, under Creatures.");
        }

        // A friend: keep up (rolling if it falls behind), bowl into slimes, potter about when you stop.
        void Friendly(Vector2 playerPos)
        {
            if (_tuck > 0f) return;
            if (_slime == null || _slime.health <= 0) _slime = _cooldown <= 0f ? Creatures.NearestSlime(_pos, playerPos, 4.5f) : null;
            if (_slime != null)
            {
                SetBall(true);
                Vector2 at = (Vector2)_slime.transform.position;
                MoveToward(at, FriendRoll);
                if (Vector2.Distance(_pos, at) < 0.5f)
                {
                    _slime.Hit(_pos, 1);
                    _cooldown = 1.2f;
                    _slime = null;
                    _pos += (_pos - at).normalized * 0.4f;
                }
                return;
            }

            float far = Vector2.Distance(_pos, playerPos);
            if (far > 3.5f || (_ball && far > 1.6f))
            {
                SetBall(true);
                MoveToward(playerPos + (_pos - playerPos).normalized * 1.3f, FriendRoll);
                _target = _pos;
                return;
            }
            if (_ball) { SetBall(false); _target = _pos; return; }
            if (far > 1.8f) { _target = playerPos + (_pos - playerPos).normalized * 1.3f; MoveToward(_target, FriendWalk); return; }
            if (_pause > 0f) { _pause -= Time.deltaTime; return; }
            if (_playerStill > 1f && (_target - _pos).sqrMagnitude < 0.01f)
            {
                _target = playerPos + Random.insideUnitCircle.normalized * Random.Range(0.9f, 1.6f);
                _pause = Random.Range(0.8f, 2f);
                return;
            }
            MoveToward(_target, 0.9f);
        }
    }

    /// <summary>
    /// The blimp bee: a giant bumble bee in the meadow north of the farm. Shy: it
    /// flies off if you come close. Lay lavender on its flat rock and it lands by it;
    /// then give it honey and it's your friend. It flies along behind you, lands and
    /// toddles about when you stop, and you can ride it (E when it's landed, or from
    /// the bag) to fly over water, rocks, bushes and fences. Trees are too tall.
    /// </summary>
    public class BlimpBee : MonoBehaviour
    {
        const float FlyHeight = 1.0f, RideHeight = 0.55f, RiderLift = 0.85f;
        /// <summary>Physics layers: you on the bee, and things too tall to fly over.</summary>
        public const int RiderLayer = 1;

        static BlimpBee _instance;
        public static bool Riding { get; private set; }
        public static bool Friend => _instance != null && _instance._friend;
        public static bool Following => Friend && Creatures.Follower == CreatureKind.BlimpBee;
        public static bool Landed => _instance != null && _instance._height < 0.05f;
        public static Sprite Icon => _instance != null && _instance._frames != null ? _instance._frames[2] : null;
        public static bool WantsUse => _instance != null && _instance._wantsUse;
        /// <summary>The lavender is on the flat rock (until the bee eats it overnight).</summary>
        public static bool FlowerDown => _instance != null && _instance._flower;
        /// <summary>The flower the blimp bee can't resist.</summary>
        public static ItemDef Favourite => Items.Lavender;

        bool _friend, _flower, _wantsUse, _shown, _landing;
        Vector2 _home, _rock, _pos, _target;
        float _height, _clock, _playerStill, _wait;
        Vector2 _lastPlayer;
        Sprite[] _frames;
        Sprite[][] _farmer;
        SpriteRenderer _sprite, _shadow, _flowerSprite;

        public static void Restore(bool friend)
        {
            if (_instance == null) return;
            _instance._friend = friend;
        }

        public void Build(Vector2 rock)
        {
            _instance = this;
            Riding = false;
            _rock = rock;
            _home = _pos = _target = rock + new Vector2(-1.8f, 0.6f);
            _height = FlyHeight;
            _frames = Art.Strip("blimpbee", 32, 32, new Vector2(0.5f, 0.1f));
            _farmer = Art.Directional(FarmDemoConfig.CharacterSheet, FarmDemoConfig.CharacterFrameWidth, FarmDemoConfig.CharacterFrameHeight);
            _shadow = new GameObject("Shadow").AddComponent<SpriteRenderer>();
            _shadow.transform.SetParent(transform, false);
            _shadow.sprite = Art.Single("shadow", new Vector2(0.5f, 0.5f));
            _shadow.sortingOrder = FarmDemoWorld.ShadowOrder;
            _shadow.transform.localScale = new Vector3(1.6f, 1.3f, 1f);
            _sprite = new GameObject("Sprite").AddComponent<SpriteRenderer>();
            _sprite.transform.SetParent(transform, false);
            _flowerSprite = new GameObject("Lavender on the rock").AddComponent<SpriteRenderer>();
            _flowerSprite.transform.position = rock + new Vector2(0.2f, 0.35f);
            _flowerSprite.sprite = Items.Lavender.Icon;
            _flowerSprite.sortingOrder = YSort.Order(rock.y) + 1;
            _flowerSprite.enabled = false;
            transform.position = _pos;
            Physics2D.IgnoreLayerCollision(RiderLayer, 0, true);     // up on the bee you only bump into tall things
            GameClock.NewDay += Morning;
        }

        void OnDestroy()
        {
            GameClock.NewDay -= Morning;
            if (_instance == this) { _instance = null; Riding = false; }
        }

        void Morning()
        {
            if (Riding) Land(true);
            if (!_friend && _flower) { _flower = false; _flowerSprite.enabled = false; }   // it ate the lavender
        }

        // ------------------------------------------------------------- riding

        public static bool CanRide => Following && !Creatures.Riding && !Home.Inside && !Mine.Inside && !Cavern.Inside && !DarkCave.Inside && !Town.Inside;

        public static void Ride()
        {
            if (!CanRide || _instance == null || PlayerController.Instance == null) return;
            var player = PlayerController.Instance;
            Riding = true;
            player.gameObject.layer = RiderLayer;
            var shadow = player.transform.Find("Shadow");
            if (shadow != null) shadow.gameObject.SetActive(false);
            var body = player.GetComponentInChildren<SpriteSheetAnimator>();
            if (body != null)
            {
                body.transform.localPosition = new Vector3(0f, RiderLift, 0f);
                var sort = body.GetComponent<YSort>();
                if (sort != null) sort.enabled = false;
            }
            _instance._pos = player.transform.position;
            _instance._height = RideHeight;
            Hud.Toast("Up you go! Fly over water, rocks and hedges. Press E to land.", 3f);
        }

        /// <summary>Climb down. Unless forced, only where there's room to stand.</summary>
        public static bool Land(bool force)
        {
            if (!Riding) return true;
            var player = PlayerController.Instance;
            if (player == null) { Riding = false; return true; }
            Vector2 feet = player.transform.position;
            if (!force && !ClearToLand(feet)) { Hud.Toast("Nowhere to stand here. Find some open ground.", 1.8f); return false; }
            Riding = false;
            player.gameObject.layer = 0;
            var shadow = player.transform.Find("Shadow");
            if (shadow != null) shadow.gameObject.SetActive(true);
            var body = player.GetComponentInChildren<SpriteSheetAnimator>();
            if (body != null)
            {
                body.transform.localPosition = Vector3.zero;
                var sort = body.GetComponent<YSort>();
                if (sort != null) sort.enabled = true;
            }
            player.ShowPose(null);
            if (_instance != null)
            {
                _instance._pos = LandSpot(feet, feet + new Vector2(player.Facing == Facing.Left ? 1.4f : -1.4f, 0f));
                _instance._height = 0f;
                _instance._target = _instance._pos;
                _instance._wait = 1f;
            }
            return true;
        }

        /// <summary>Somewhere near you that isn't water, for it to set down (you might be on a little island).</summary>
        static Vector2 LandSpot(Vector2 near, Vector2 wanted)
        {
            if (!FarmDemoWorld.IsWater(wanted + new Vector2(0f, 0.15f))) return wanted;
            for (float r = 1.4f; r >= 0.7f; r -= 0.35f)
            for (int i = 0; i < 8; i++)
            {
                float a = i * Mathf.PI / 4f;
                var at = near + new Vector2(Mathf.Cos(a) * r, Mathf.Sin(a) * r * 0.7f);
                if (!FarmDemoWorld.IsWater(at + new Vector2(0f, 0.15f))) return at;
            }
            return near;
        }

        static bool ClearToLand(Vector2 feet)
        {
            if (FarmDemoWorld.IsWater(feet + new Vector2(0f, 0.15f))) return false;
            foreach (var col in Physics2D.OverlapBoxAll(feet + new Vector2(0f, 0.15f), new Vector2(0.6f, 0.3f), 0f))
            {
                if (col.isTrigger) continue;
                if (PlayerController.Instance != null && col.attachedRigidbody != null && col.attachedRigidbody.gameObject == PlayerController.Instance.gameObject) continue;
                return false;
            }
            return true;
        }

        // ------------------------------------------------------------- update

        void Update()
        {
            _wantsUse = false;
            bool indoors = Home.Inside || Mine.Inside || Cavern.Inside || DarkCave.Inside || Town.Inside;      // too big to come in; it waits outside
            bool shown = (!_friend || Following) && (!indoors || Riding);
            _sprite.enabled = _shadow.enabled = shown && _frames != null;
            _flowerSprite.enabled = _flower;
            if (!shown || _frames == null) { _shown = false; return; }

            var player = PlayerController.Instance;
            Vector2 playerPos = player != null ? (Vector2)player.transform.position : _home;
            if (_friend && !Riding && (!_shown || Vector2.Distance(_pos, playerPos) > 14f))
            {
                _pos = _target = playerPos + new Vector2(-1.5f, 0.3f);
                _height = FlyHeight;
            }
            _shown = true;
            _playerStill = Vector2.Distance(playerPos, _lastPlayer) < 0.01f ? _playerStill + Time.deltaTime : 0f;
            _lastPlayer = playerPos;
            _clock += Time.deltaTime;

            if (Riding) RideAlong(player);
            else if (_friend) Friendly(player, playerPos);
            else Wild(player, playerPos);

            // Draw: the body floats over its shadow; on the ground its little legs toddle.
            transform.position = _pos;
            float bob = _height > 0.05f ? Mathf.Sin(_clock * 3f) * 0.08f : 0f;
            _sprite.transform.localPosition = new Vector3(0f, _height + bob, 0f);
            bool walking = _height < 0.05f && (_target - _pos).sqrMagnitude > 0.004f;
            int frame = Riding || _height > 0.05f ? Mathf.FloorToInt(_clock * 14f) % 2 : walking ? 2 + Mathf.FloorToInt(_clock * 6f) % 2 : 2;
            _sprite.sprite = _frames[frame];
            if (!Riding) _sprite.sortingOrder = YSort.Order(_pos.y);
            _shadow.transform.localScale = new Vector3(1.6f - _height * 0.3f, 1.3f - _height * 0.25f, 1f);
        }

        void MoveToward(Vector2 goal, float speed)
        {
            Vector2 d = goal - _pos;
            float step = speed * Time.deltaTime;
            _pos = d.magnitude <= step ? goal : _pos + d.normalized * step;
            if (Mathf.Abs(d.x) > 0.05f) _sprite.flipX = d.x > 0f;      // the art faces left
        }

        void Rise(float to, float speed) => _height = Mathf.MoveTowards(_height, to, speed * Time.deltaTime);

        // Wild: drifts about its meadow, and flees if you get close, unless there's lavender on the rock.
        void Wild(PlayerController player, Vector2 playerPos)
        {
            Vector2 flowerSpot = _rock + new Vector2(-1.3f, -0.1f);
            if (_flower)
            {
                if (Vector2.Distance(_pos, flowerSpot) > 0.05f && _height > 0.05f) { MoveToward(flowerSpot, 2.2f); _target = _pos; }
                else
                {
                    Rise(0f, 1.2f);
                    if (_height < 0.05f)
                    {
                        // Munching the lavender, shuffling about beside the rock.
                        if ((_wait -= Time.deltaTime) <= 0f) { _target = flowerSpot + Random.insideUnitCircle * 0.4f; _wait = Random.Range(1f, 2.5f); }
                        MoveToward(_target, 0.4f);
                    }
                }
            }
            else
            {
                Rise(FlyHeight, 1.5f);
                Vector2 away = _pos - playerPos;
                if (away.magnitude < 3.2f)
                {
                    // Off it goes, away from you (but it never strays far from its meadow).
                    Vector2 flee = _pos + (away.sqrMagnitude > 0.01f ? away.normalized : Vector2.right) * 3f;
                    _target = _home + Vector2.ClampMagnitude(flee - _home, 6.5f);
                    if ((_target - _pos).magnitude < 0.5f) _target = _home + Random.insideUnitCircle.normalized * 4f;   // cornered: dart round you
                    MoveToward(_target, 3.6f);
                }
                else
                {
                    if ((_wait -= Time.deltaTime) <= 0f || (_target - _pos).sqrMagnitude < 0.01f)
                    {
                        _target = _home + Random.insideUnitCircle * 3f;
                        _wait = Random.Range(2f, 4f);
                    }
                    MoveToward(_target, 1.1f);
                }
            }

            if (player == null || Hud.Busy || player.Locked) return;
            Vector2 feet = (Vector2)player.transform.position + new Vector2(0f, 0.15f);
            var held = Inventory.SelectedItem;

            // At the flat rock: lay down the lavender.
            if (!_flower && Vector2.Distance(feet + Art.Dir(player.Facing) * 0.6f, _rock + new Vector2(0f, 0.3f)) < 1.3f)
            {
                if (held == Favourite)
                {
                    _wantsUse = true;
                    Hud.SetPrompt("F  Lay lavender on the flat rock");
                    if (GameInput.FishPressed() && Inventory.Remove(Favourite) > 0)
                    {
                        _flower = true;
                        _wait = 0f;
                        Hud.Toast("You lay a sprig of lavender on the rock. Now step back and wait...", 3f);
                    }
                }
                else Hud.SetPrompt("A big flat rock. Something fuzzy keeps buzzing round it.");
                return;
            }

            // Beside the landed bee: offer it honey.
            if (!_flower || _height > 0.05f || Vector2.Distance(feet, _pos) > 2.4f) return;     // it's a big bee
            if (held != Items.Honey)
            {
                Hud.SetPrompt(Inventory.Has(Items.Honey) ? "The blimp bee is munching lavender. Pick your honey to offer it some"
                    : "The blimp bee is munching lavender. It looks like it wants something sweet...");
                return;
            }
            _wantsUse = true;
            Hud.SetPrompt("F  Give the blimp bee some honey");
            if (!GameInput.FishPressed() || Inventory.Remove(Items.Honey) == 0) return;
            _friend = true;
            _flower = false;
            Creatures.Follow(CreatureKind.BlimpBee);
            StartCoroutine(Creatures.HeartPop(transform, 1.6f));
            Hud.ShowPopup(_frames[2], "The blimp bee is your friend!",
                "It'll float along behind you. When it lands, walk up and press E to ride it over water, rocks and hedges. Only one creature follows you at a time.");
        }

        // A friend: hovers along behind you; lands and toddles about when you stop; offers you a ride.
        void Friendly(PlayerController player, Vector2 playerPos)
        {
            float far = Vector2.Distance(_pos, playerPos);
            bool settle = _playerStill > 1f && far < 3.5f;
            if (settle || (_height < 0.05f && far <= 2.5f))
            {
                if (!_landing)
                {
                    _landing = true;
                    _target = LandSpot(playerPos, playerPos + new Vector2(Random.value < 0.5f ? -1.5f : 1.5f, Random.Range(-0.6f, 0.4f)));
                }
                if (_height > 0.05f && Vector2.Distance(_pos, _target) > 0.05f) MoveToward(_target, 2.5f);
                else
                {
                    Rise(0f, 1.4f);
                    if (_height < 0.05f && (_wait -= Time.deltaTime) <= 0f)
                    {
                        _target = LandSpot(playerPos, playerPos + Random.insideUnitCircle.normalized * Random.Range(1.2f, 1.9f));
                        _wait = Random.Range(1.5f, 3f);
                    }
                    if (_height < 0.05f) MoveToward(_target, 0.5f);
                }
            }
            else
            {
                _landing = false;
                Rise(FlyHeight, 1.6f);
                // Float along behind you.
                Vector2 behind = player != null ? playerPos - Art.Dir(player.Facing) * 1.5f + new Vector2(0f, 0.3f) : _home;
                _target = behind;
                float t = 1f - Mathf.Exp(-3f * Time.deltaTime);
                Vector2 next = Vector2.Lerp(_pos, behind, t);
                if (Mathf.Abs(next.x - _pos.x) > 0.002f) _sprite.flipX = next.x > _pos.x;
                _pos = next;
            }

            // Walk up to it on the ground and hop on.
            if (player == null || Hud.Busy || player.Locked || _height > 0.05f) return;
            if (Vector2.Distance((Vector2)player.transform.position, _pos) > 2f) return;
            Hud.SetPrompt("E  Ride the blimp bee");
            if (GameInput.TalkPressed()) Ride();
        }

        void RideAlong(PlayerController player)
        {
            if (player == null) return;
            if (Home.Inside || Mine.Inside || Cavern.Inside || DarkCave.Inside || Town.Inside) { Land(true); return; }
            _pos = player.transform.position;
            _height = RideHeight;
            _target = _pos;
            bool left = player.Facing == Facing.Left, right = player.Facing == Facing.Right;
            if (left || right) _sprite.flipX = right;

            // You sit on its back, drawn above whatever you're flying over.
            int order = YSort.Order(_pos.y - 1.5f);
            _sprite.sortingOrder = order;
            var body = player.GetComponentInChildren<SpriteSheetAnimator>();
            if (body != null)
            {
                body.transform.localPosition = new Vector3(0f, RiderLift + _height - RideHeight + Mathf.Sin(_clock * 3f) * 0.08f, 0f);
                var sr = body.GetComponent<SpriteRenderer>();
                if (sr != null) sr.sortingOrder = order + 1;
            }
            if (_farmer != null) player.ShowPose(_farmer[(int)player.Facing][0]);
            if (!Hud.Busy)
            {
                Hud.ForcePrompt("E  Land");
                if (GameInput.TalkKey()) Land(false);
            }
        }
    }
}
