using UnityEngine;

namespace FarmDemo
{
    /// <summary>
    /// The island in the meadow lake is no island: it's the back of an Aspidochelone,
    /// an ancient island turtle. There's no way across but to fly, on the blimp bee.
    /// It looks like any little island with a tree on it, but out past its east shore
    /// bubbles rise, and on that shore a ring of flowers marks where to stand. Play
    /// the flute in the ring and the island shakes, the shell's outline shows through
    /// the water all round it, and its head rises out of the bubbles and speaks: you
    /// must find balance with the creatures of Mythica. The first time, it gives you
    /// an old spell book that throws small fireballs (see Spells). When it's done
    /// talking it sinks back down, and it's just an island again.
    /// </summary>
    public class Aspidochelone : MonoBehaviour
    {
        enum State { Down, Shaking, Rising, Up, Sinking, Settling }

        // The island (its shell), the causeway, and where its head is.
        public static readonly Vector2 Island = new Vector2(12f, 39.2f);
        static readonly Vector2 IslandSize = new Vector2(2.9f, 1.95f);
        public static readonly Vector2 Bubbles = Island + new Vector2(IslandSize.x + 2.4f, 0f);
        /// <summary>The ring of flowers on the east shore, where you stand to play.</summary>
        public static readonly Vector2 RingSpot = new Vector2(14f, 39f);
        /// <summary>Where the shell's art is centred (the middle of the island's grass tiles).</summary>
        static readonly Vector2 ShellCentre = new Vector2(12f, 39f);
        const float RingRadius = 0.75f, TuneToWake = 2f, ShakeTime = 1.6f, RiseTime = 1.6f, StayUp = 8f, SettleTime = 1.2f;

        public static bool OnIsland(Vector2 at, float margin)
        {
            float px = (at.x - Island.x) / (IslandSize.x + margin), py = (at.y - Island.y) / (IslandSize.y + margin);
            return px * px + py * py <= 1f;
        }

        static Aspidochelone _instance;
        /// <summary>It has given you the spell book. (Kept in the save.)</summary>
        public static bool Gifted
        {
            get => _instance != null && _instance._gifted;
            set { if (_instance != null) _instance._gifted = value; }
        }

        bool _gifted;
        State _state = State.Down;
        float _t, _clock;
        Sprite[] _head, _bubbles;
        SpriteRenderer _headSprite, _bubbleSprite, _rim;
        Transform _tree;
        Vector3 _treeHome;
        readonly SpriteRenderer[] _splash = new SpriteRenderer[10];

        static readonly string[] FirstWords =
        {
            "...Hrrrmmm. A song. It has been a long age since anyone played for me.",
            "I am the Aspidochelone. This lake was a puddle when I lay down in it, and the grass on my back has grown for a thousand summers.",
            "The creatures of Mythica are stirring again. Jackalopes, Enfields, Snawfus... and older, stranger things. They choose whom they trust.",
            "Listen well, little farmer. You must find balance with the creatures of Mythica. Not to own them. Never that. To live beside them.",
            "Take this. An old book of embers, dropped on my shell by a wizard who swam badly. Small fire, for a small farmer. Use it kindly.",
        };

        static readonly string[] LaterWords =
        {
            "...Hrrrmmm. The flute again. You have not forgotten me.",
            "Balance, little farmer. Every creature you befriend is a weight on the scale. Keep it level.",
        };

        public void Build(Transform parent, Transform tree)
        {
            _instance = this;
            _tree = tree;
            if (tree != null) _treeHome = tree.position;
            // The shell and flippers, under the water round the grassy island: hidden until it wakes.
            _rim = new GameObject("Aspidochelone shell").AddComponent<SpriteRenderer>();
            _rim.transform.SetParent(parent, false);
            _rim.transform.position = ShellCentre;
            _rim.sprite = Art.Single("aspido_rim", new Vector2(0.5f, 0.5f));
            _rim.sortingOrder = FarmDemoWorld.ShadowOrder - 990;     // over the water and grass tiles, under everything standing
            _rim.color = Color.clear;
            // The ring of flowers on the east shore.
            var ring = new GameObject("Flower ring").AddComponent<SpriteRenderer>();
            ring.transform.SetParent(parent, false);
            ring.transform.position = RingSpot;
            ring.sprite = Art.Single("flowerring", new Vector2(0.5f, 0.5f));
            ring.sortingOrder = FarmDemoWorld.ShadowOrder - 985;
            _head = Art.Strip("aspido_head", 32, 48);
            _bubbles = Art.Strip("bubbles", 8, 8, new Vector2(0.5f, 0.5f));
            _headSprite = new GameObject("Aspidochelone head").AddComponent<SpriteRenderer>();
            _headSprite.transform.SetParent(parent, false);
            _headSprite.transform.position = Bubbles + new Vector2(0f, -0.35f);
            _headSprite.sortingOrder = YSort.Order(Bubbles.y - 0.35f);
            _headSprite.enabled = false;
            _bubbleSprite = new GameObject("Bubbles").AddComponent<SpriteRenderer>();
            _bubbleSprite.transform.SetParent(parent, false);
            _bubbleSprite.transform.position = Bubbles;
            _bubbleSprite.sortingOrder = FarmDemoWorld.ShadowOrder - 980;
            // Splashes all round the shell's edge while it heaves up out of the lake.
            for (int i = 0; i < _splash.Length; i++)
            {
                _splash[i] = new GameObject("Splash").AddComponent<SpriteRenderer>();
                _splash[i].transform.SetParent(parent, false);
                float a = i * Mathf.PI * 2f / _splash.Length;
                _splash[i].transform.position = ShellCentre + new Vector2(Mathf.Cos(a) * 4f, Mathf.Sin(a) * 2.8f);
                _splash[i].sortingOrder = FarmDemoWorld.ShadowOrder - 980;
                _splash[i].enabled = false;
            }
        }

        void OnDestroy()
        {
            if (_instance == this) _instance = null;
        }

        void Update()
        {
            _clock += Time.deltaTime;
            _t += Time.deltaTime;
            var player = PlayerController.Instance;

            // Bubbles while its head is under; they come in little bursts.
            bool bubbling = _state == State.Down && _bubbles != null && Mathf.Repeat(_clock, 3f) < 2.2f;
            _bubbleSprite.enabled = bubbling;
            if (bubbling)
            {
                _bubbleSprite.sprite = _bubbles[Mathf.FloorToInt(_clock * 5f) % _bubbles.Length];
                _bubbleSprite.transform.position = Bubbles + new Vector2(Mathf.Sin(_clock * 1.3f) * 0.15f, 0f);
            }

            switch (_state)
            {
                case State.Down: Listen(player); break;
                case State.Shaking: if (_t >= ShakeTime) { _state = State.Rising; _t = 0f; } break;
                case State.Rising: if (_t >= RiseTime) Speak(); break;
                case State.Up: StayAwake(player); break;
                case State.Sinking: if (_t >= RiseTime) { _state = State.Settling; _t = 0f; } break;
                case State.Settling: if (_t >= SettleTime) { _state = State.Down; _t = 0f; } break;
            }
            Draw();
        }

        /// <summary>Standing in the ring of flowers.</summary>
        static bool Near(PlayerController player)
        {
            if (player == null || Creatures.Riding) return false;
            return Vector2.Distance(player.transform.position, RingSpot) <= RingRadius;
        }

        // A tune played in the ring of flowers, close to where it sleeps, wakes it.
        void Listen(PlayerController player)
        {
            if (!Near(player)) return;
            if (!Flute.Playing)
            {
                if (!Hud.Busy) Hud.SetPrompt(Toolbelt.Has(Items.Flute) ? "A ring of flowers by the water. A good spot for a song..." : "A ring of flowers by the water. Bubbles rise out past it.");
                return;
            }
            if (Flute.PlayingFor < TuneToWake) return;
            Flute.StopPlaying();
            _state = State.Shaking;
            _t = 0f;
            CameraFollow.Shake(ShakeTime, 0.12f);
            Hud.Toast("The ground shakes! The island is moving...", 2f);
        }

        void Speak()
        {
            _state = State.Up;
            _t = 0f;
            Hud.OpenDialogue(this, "Aspidochelone", _gifted ? LaterWords : FirstWords, _gifted ? null : (System.Action)Gift);
        }

        void Gift()
        {
            _gifted = true;
            _t = 0f;
            Inventory.Add(Items.SpellBook);
            Toolbelt.Pick(Items.SpellBook);
            Hud.ShowPopup(Items.SpellBook.Icon, "You got the Spell Book!",
                "A key item, on your tool dial. Hold it and press F to throw a small fireball, up to 3 tiles ahead.");
        }

        void StayAwake(PlayerController player)
        {
            if (Hud.Speaker == (object)this)
            {
                _t = 0f;
                if (GameInput.TalkPressed() || GameInput.FishPressed()) Hud.AdvanceDialogue();
                return;
            }
            if (Hud.Busy) return;
            if (Near(player))
            {
                Hud.SetPrompt("E  Talk to the Aspidochelone");
                if (GameInput.TalkPressed()) { Speak(); return; }
            }
            if (_t >= StayUp) { _state = State.Sinking; _t = 0f; }
        }

        void Draw()
        {
            // The shell shows through the water while it's awake, and fades as it settles back down.
            float shell = _state == State.Down ? 0f : _state == State.Shaking ? Mathf.Clamp01(_t / ShakeTime * 1.4f)
                : _state == State.Settling ? 1f - Mathf.Clamp01(_t / SettleTime) : 1f;
            _rim.color = new Color(1f, 1f, 1f, shell);
            bool heaving = _state == State.Shaking || (_state == State.Rising && _t < 0.6f);
            if (_tree != null) _tree.position = _treeHome + (heaving ? new Vector3(Mathf.Sin(_clock * 40f) * 0.06f, 0f, 0f) : Vector3.zero);
            for (int i = 0; i < _splash.Length; i++)
            {
                _splash[i].enabled = heaving && _bubbles != null;
                if (_splash[i].enabled) _splash[i].sprite = _bubbles[(Mathf.FloorToInt(_clock * 8f) + i) % _bubbles.Length];
            }
            if (_head == null) return;
            int frame;
            if (_state == State.Down || _state == State.Shaking || _state == State.Settling) { _headSprite.enabled = false; return; }
            float k = Mathf.Clamp01(_t / RiseTime);
            if (_state == State.Rising) frame = Mathf.Min(3, Mathf.FloorToInt(k * 4f));
            else if (_state == State.Sinking) frame = Mathf.Max(0, 3 - Mathf.FloorToInt(k * 4f));
            else frame = Hud.Speaker == (object)this && Mathf.FloorToInt(_clock * 6f) % 2 == 0 ? 4 : 3;     // its beak moves as it talks
            _headSprite.enabled = true;
            _headSprite.sprite = _head[Mathf.Min(frame, _head.Length - 1)];
        }
    }
}
