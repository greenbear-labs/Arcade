using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Tilemaps;

namespace FarmDemo
{
    /// <summary>
    /// Builds the whole demo in code when you press Play: a tilemap farm with a
    /// path, a pond and a field, trees and rocks, breakable pots, slimes, a little
    /// village to the east with the bakery and the quest board, villagers (one runs a shop), a chicken coop, a day clock with seasons that
    /// repaint the farm, an animated player the camera follows, and the HUD.
    /// Nothing has to be set up by hand.
    ///
    /// It starts itself in any scene that is still empty (only a camera / light),
    /// and never touches a scene you've built yourself. You can also add this
    /// component to a GameObject to build the demo on purpose.
    /// </summary>
    public class FarmDemoWorld : MonoBehaviour
    {
        enum Ground { Grass, Path, Soil, Water, Dirt, Stone }

        /// <summary>The map runs from MapLeft (the mountain, west of the farm) to MapWidth (the village's east edge).</summary>
        const int L = -FarmDemoConfig.MapLeft;      // array column of world x = 0
        public static Rect OutdoorBounds => new Rect(FarmDemoConfig.MapLeft, FarmDemoConfig.MapBottom, FarmDemoConfig.MapWidth - FarmDemoConfig.MapLeft,
            FarmDemoConfig.MapHeight - FarmDemoConfig.MapBottom);

        /// <summary>The farm is the west part of the map; the village is east of it.</summary>
        public const int FarmWidth = 48;
        /// <summary>The farm is the south part of the map; the meadow is north of it.</summary>
        public const int FarmHeight = 32;
        /// <summary>Physics layer for things too tall to fly over on the blimp bee (trees, buildings, the map's edge).</summary>
        public const int TallLayer = 4;
        public static void Tall(GameObject go)
        {
            if (go != null) go.layer = TallLayer;
        }
        /// <summary>Mornings until filled-in dirt is grass again.</summary>
        const int DaysToGrass = 3;

        public const int ShadowOrder = -29000;
        const int GroundOrder = -30000;

        Ground[,] _ground;
        static FarmDemoWorld _current;
        readonly Dictionary<Vector2Int, int> _dirt = new Dictionary<Vector2Int, int>();
        Tile _dirtTile;

        /// <summary>Is this world position on a pond tile?</summary>
        public static bool IsWater(Vector2 world)
        {
            if (_current == null || _current._ground == null) return false;
            return _current.IsWater(Mathf.FloorToInt(world.x), Mathf.FloorToInt(world.y));
        }

        /// <summary>Is this tile a path (the road, the town square, its lanes and walks)?</summary>
        public static bool IsPath(Vector2Int cell)
        {
            if (_current == null || _current._ground == null) return false;
            var g = _current._ground;
            return cell.x + L >= 0 && cell.y >= 0 && cell.x + L < g.GetLength(0) && cell.y < g.GetLength(1) && g[cell.x + L, cell.y] == Ground.Path;
        }

        /// <summary>Is this tile part of the tilled field?</summary>
        public static bool IsSoil(Vector2Int cell)
        {
            if (_current == null || _current._ground == null) return false;
            var g = _current._ground;
            return cell.x + L >= 0 && cell.y >= 0 && cell.x + L < g.GetLength(0) && cell.y < g.GetLength(1) && g[cell.x + L, cell.y] == Ground.Soil;
        }

        /// <summary>Can the hoe dig here? Open grass or dirt on the farm, with nothing standing on it.</summary>
        public static bool CanTill(Vector2Int cell)
        {
            if (_current == null || _current._ground == null) return false;
            var g = _current._ground;
            if (cell.x < 3 || cell.y < 2 || cell.x >= FarmWidth - 3 || cell.y >= FarmHeight - 3) return false;
            var here = g[cell.x + L, cell.y];
            if ((here != Ground.Grass && here != Ground.Dirt) || Animals.Covers(cell) || Barn.Covers(cell)) return false;
            foreach (var col in Physics2D.OverlapBoxAll(new Vector2(cell.x + 0.5f, cell.y + 0.5f), new Vector2(0.8f, 0.8f), 0f))
            {
                if (col.isTrigger) continue;
                if (PlayerController.Instance != null && col.attachedRigidbody != null &&
                    col.attachedRigidbody.gameObject == PlayerController.Instance.gameObject) continue;
                return false;   // a tree, rock, pot, villager or slime is in the way
            }
            return true;
        }

        /// <summary>Has Grandpa handed over the turnip seeds yet? (Kept in the save.)</summary>
        public static bool GrandpaGaveSeeds
        {
            get => _current != null && _current._grandpaGaveSeeds;
            set { if (_current != null) _current._grandpaGaveSeeds = value; }
        }

        /// <summary>Every soil tile, the starting field and anything you've dug since.</summary>
        public static List<Vector2Int> SoilCells()
        {
            var cells = new List<Vector2Int>();
            if (_current == null || _current._ground == null) return cells;
            var g = _current._ground;
            for (int x = 0; x < g.GetLength(0); x++)
            for (int y = 0; y < g.GetLength(1); y++)
                if (g[x, y] == Ground.Soil) cells.Add(new Vector2Int(x - L, y));
            return cells;
        }

        /// <summary>Make a grass tile soil without the hoe's checks (loading a save).</summary>
        public static void SetSoil(Vector2Int cell)
        {
            if (_current == null || _current._ground == null) return;
            var g = _current._ground;
            if (cell.x + L < 0 || cell.y < 0 || cell.x + L >= g.GetLength(0) || cell.y >= g.GetLength(1)) return;
            if (g[cell.x + L, cell.y] != Ground.Grass && g[cell.x + L, cell.y] != Ground.Dirt) return;
            g[cell.x + L, cell.y] = Ground.Soil;
            _current._dirt.Remove(cell);
            _current._groundMap.SetTile(new Vector3Int(cell.x, cell.y, 0), _current._soilTile);
        }

        /// <summary>Turn a grass (or dirt) tile into farm soil.</summary>
        public static void Till(Vector2Int cell)
        {
            if (!CanTill(cell)) return;
            _current._ground[cell.x + L, cell.y] = Ground.Soil;
            _current._dirt.Remove(cell);
            _current._groundMap.SetTile(new Vector3Int(cell.x, cell.y, 0), _current._soilTile);
        }

        /// <summary>The shovel: fill a soil tile back in. It's bare dirt for a few days, then grass.</summary>
        public static void Untill(Vector2Int cell)
        {
            if (!IsSoil(cell)) return;
            _current._ground[cell.x + L, cell.y] = Ground.Dirt;
            _current._dirt[cell] = 0;
            _current._groundMap.SetTile(new Vector3Int(cell.x, cell.y, 0), _current._dirtTile);
        }

        public static void ExportDirt(List<SaveGame.CellDays> list)
        {
            if (_current == null) return;
            foreach (var pair in _current._dirt) list.Add(new SaveGame.CellDays { x = pair.Key.x, y = pair.Key.y, days = pair.Value });
        }

        public static void ImportDirt(List<SaveGame.CellDays> list)
        {
            if (_current == null || _current._ground == null) return;
            foreach (var d in list)
            {
                var cell = new Vector2Int(d.x, d.y);
                if (!IsSoil(cell)) SetSoil(cell);
                Untill(cell);
                if (_current._dirt.ContainsKey(cell)) _current._dirt[cell] = d.days;
            }
        }

        // Each morning, filled-in dirt grows a little more grass.
        void GrowGrass()
        {
            var cells = new List<Vector2Int>(_dirt.Keys);
            foreach (var cell in cells)
            {
                if (++_dirt[cell] < DaysToGrass) continue;
                _dirt.Remove(cell);
                _ground[cell.x + L, cell.y] = Ground.Grass;
                _groundMap.SetTile(new Vector3Int(cell.x, cell.y, 0), _tiles[Random.Range(0, 2) == 0 ? FarmDemoConfig.TileGrassA : FarmDemoConfig.TileGrassB]);
            }
        }

        Tilemap _groundMap, _waterMap, _forestMap;
        Tile _soilTile;
        Tile[] _tiles;
        // Trees and bushes, repainted when the season changes.
        readonly List<(SpriteRenderer renderer, string art)> _foliage = new List<(SpriteRenderer, string)>();
        Season _shownSeason;
        bool _grandpaGaveSeeds;
        Npc _mabel, _pip;
        readonly List<(Vector2 spot, GameObject pot)> _pots = new List<(Vector2, GameObject)>();
        Sprite _potSprite, _potBrokenSprite;
        Transform _potParent;
        readonly HashSet<Vector2Int> _blocked = new HashSet<Vector2Int>();
        System.Random _rng;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void AutoStartOnce()
        {
            AutoStart();
            // "Start a new farm" reloads the scene; build the farm again when it does.
            SceneManager.sceneLoaded += (scene, mode) => AutoStart();
        }

        static void AutoStart()
        {
            if (FindAnyObjectByTypeCompat<FarmDemoWorld>() != null) return;
            if (!SceneIsEmpty()) return;
            new GameObject("Farm Demo").AddComponent<FarmDemoWorld>();
        }

        void Awake()
        {
            _current = this;
            _rng = new System.Random(42);
            PlayerStats.Reset();
            Upgrades.Reset();
            Sprinklers.Reset();
            Inventory.Reset();
            Creatures.Reset();
            Toolbelt.Reset();
            Toolbelt.Give(Items.Sword);
            Toolbelt.Give(Items.Axe);
            Toolbelt.Give(Items.Shovel);
            Toolbelt.Give(Items.Shears);
            GameClock.ResetClock();
            Sprite[] tiles = LoadTiles();
            Sprite[][] farmer = Art.Directional(FarmDemoConfig.CharacterSheet,
                FarmDemoConfig.CharacterFrameWidth, FarmDemoConfig.CharacterFrameHeight);
            if (tiles == null || farmer == null) return;

            gameObject.AddComponent<GameClock>();
            new GameObject("Lighting").AddComponent<Lighting>().transform.SetParent(transform, false);
            gameObject.AddComponent<TouchControls>();
            GameClock.NewDay += RespawnPots;
            GameClock.NewDay += ShowSeason;
            GameClock.NewDay += GrowGrass;
            BuildGround(tiles);
            BuildBorder();
            PlacePots();
            PlaceNpcs();
            PlaceHouse();
            PlaceCoop();
            PlaceBarn();
            var apiary = new GameObject("Apiary").AddComponent<Apiary>();
            apiary.transform.SetParent(transform, false);
            apiary.Build();
            var chests = new GameObject("Chests").AddComponent<Chests>();
            chests.transform.SetParent(transform, false);
            chests.Build();
            new GameObject("Woodcutting").AddComponent<Woodcutting>().transform.SetParent(transform, false);
            var orchard = new GameObject("Fruit trees").AddComponent<FruitTrees>();
            orchard.transform.SetParent(transform, false);
            orchard.Build();
            new GameObject("Wilds").AddComponent<Wilds>().transform.SetParent(transform, false);
            PlaceVillage();
            PlaceTown();
            PlaceMine();          // before the quest board, which asks the mine how deep you've been
            PlaceMountain();
            PlaceMeadow();
            PlaceForest();
            PlaceQuestBoard();
            PlaceWorkbench();
            PlaceKitchen();
            PlaceSlimes();
            ScatterProps();
            Transform player = BuildPlayer(farmer, new Vector2(24f, 12f));
            SetUpCamera(player);
            var jackalope = new GameObject("Jackalope").AddComponent<Jackalope>();
            jackalope.transform.SetParent(transform, false);
            jackalope.Build(Town.JackalopeHome);
            var turtle = new GameObject("Cannonball turtle").AddComponent<CannonTurtle>();
            turtle.transform.SetParent(transform, false);
            turtle.Build(new Vector2(-16.5f, 7f));
            var bee = new GameObject("Blimp bee").AddComponent<BlimpBee>();
            bee.transform.SetParent(transform, false);
            bee.Build(FlatRock);
            var enfield = new GameObject("Enfield").AddComponent<Enfield>();
            enfield.transform.SetParent(transform, false);
            enfield.Build();
            var snawfus = new GameObject("Snawfus").AddComponent<Snawfus>();
            snawfus.transform.SetParent(transform, false);
            snawfus.Build();
            new GameObject("HUD").AddComponent<Hud>().transform.SetParent(transform, false);
            gameObject.AddComponent<SaveGame>();

            if (SaveGame.Load())
                Hud.Toast($"Welcome back! It's {Seasons.DateText}.", 4f);
            else
            {
                // A new farm: you start with your tools, on the tool dial.
                Inventory.Add(Items.Hoe);
                Inventory.Add(Items.WateringCan);
                Toolbelt.Pick(Items.Hoe);
                Hud.Toast("Your tools are on the dial, top left. Slide it up or down (or press Q / R) to switch.", 6f);
            }
            _shownSeason = Season.Spring;
            ShowSeason();
        }

        // ------------------------------------------------------------- seasons

        /// <summary>Repaint the grass, trees and bushes if the season has changed.</summary>
        void ShowSeason()
        {
            var season = Seasons.Current;
            if (season == _shownSeason || _tiles == null) return;
            _shownSeason = season;

            int size = FarmDemoConfig.TileSize;
            var sheet = season == Season.Spring
                ? Art.PaddedSheet(FarmDemoConfig.Tileset, size, size, new Vector2(0.5f, 0.5f))
                : Art.PaddedSheet(FarmDemoConfig.Tileset, size, size, new Vector2(0.5f, 0.5f), season.ToString(),
                    c => Seasons.Recolor(c, season, false));
            if (sheet == null) return;
            int i = 0;
            foreach (var row in sheet)
            foreach (var sprite in row)
                if (i < _tiles.Length) _tiles[i++].sprite = sprite;
            _groundMap.RefreshAllTiles();
            _waterMap.RefreshAllTiles();
            if (_forestMap != null) _forestMap.RefreshAllTiles();

            foreach (var (renderer, art) in _foliage)
            {
                if (renderer == null) continue;
                var chop = renderer.GetComponent<ChoppableTree>();
                if (chop != null && chop.Stump) continue;       // stumps look the same all year
                renderer.sprite = Seasons.Prop(art, season);
            }
        }

        // ------------------------------------------------------------- loading

        static Sprite[] LoadTiles()
        {
            int size = FarmDemoConfig.TileSize;
            var sheet = Art.PaddedSheet(FarmDemoConfig.Tileset, size, size, new Vector2(0.5f, 0.5f));
            if (sheet == null) return null;
            var flat = new List<Sprite>();
            foreach (var row in sheet) flat.AddRange(row);
            return flat.ToArray();
        }

        static Sprite LoadProp(string name) => Art.Single(name);

        // ------------------------------------------------------------- world

        void BuildGround(Sprite[] tileSprites)
        {
            int W = FarmDemoConfig.MapWidth, H = FarmDemoConfig.MapHeight;
            _ground = new Ground[W + L, H];

            Vector2 pond = new Vector2(36f, 23.5f);
            for (int x = -L; x < W; x++)
            for (int y = 0; y < H; y++)
            {
                if (y >= FarmHeight)
                {
                    _ground[x + L, y] = NorthGround(x, y);
                    continue;
                }
                if (x < 0)
                {
                    _ground[x + L, y] = MountainGround(x, y);
                    continue;
                }
                float px = (x + 0.5f - pond.x) / 6.5f, py = (y + 0.5f - pond.y) / 4.5f;
                if (px * px + py * py <= 1f) _ground[x + L, y] = Ground.Water;
                else if (x >= 6 && x <= 15 && y >= 18 && y <= 25) _ground[x + L, y] = Ground.Soil;
                else if ((y == 11 || y == 12) && x <= W - 3) _ground[x + L, y] = Ground.Path;
                else if ((x == 23 || x == 24) && y >= 2) _ground[x + L, y] = Ground.Path;      // and on north to the meadow
                else if (x >= 10 && x <= 11 && y >= 13 && y <= 17) _ground[x + L, y] = Ground.Path; // to the field
                else if (x >= 19 && x <= 20 && y >= 13 && y <= 18) _ground[x + L, y] = Ground.Path; // to the house
                else if (Town.IsStreet(x, y)) _ground[x + L, y] = Ground.Path;                     // the town square, its lanes and walks
            }

            var tiles = _tiles = new Tile[tileSprites.Length];
            for (int i = 0; i < tiles.Length; i++)
            {
                tiles[i] = ScriptableObject.CreateInstance<Tile>();
                tiles[i].sprite = tileSprites[i];
                tiles[i].colliderType = Tile.ColliderType.None;
            }
            for (int m = 0; m < 16; m++) tiles[FarmDemoConfig.TileWaterBase + m].colliderType = Tile.ColliderType.Grid;

            var grid = new GameObject("Grid", typeof(Grid));
            grid.transform.SetParent(transform, false);
            Tilemap ground = NewTilemap(grid.transform, "Ground", GroundOrder);
            Tilemap water = NewTilemap(grid.transform, "Water (solid)", GroundOrder + 1);
            water.gameObject.AddComponent<TilemapCollider2D>();
            _groundMap = ground;
            _waterMap = water;
            _soilTile = tiles[FarmDemoConfig.TileSoil];
            _dirtTile = ScriptableObject.CreateInstance<Tile>();
            _dirtTile.sprite = Art.Single("dirt", new Vector2(0.5f, 0.5f)) ?? tileSprites[FarmDemoConfig.TilePath];
            _dirtTile.colliderType = Tile.ColliderType.None;

            // The village and the mountain draw their tiles from their own dice, so the farm looks just as it always has.
            var villageRng = new System.Random(7);
            var mountainRng = new System.Random(11);
            var northRng = new System.Random(13);
            var stone = Art.Strip("mtn_tiles", 16, 16, new Vector2(0.5f, 0.5f));
            var stoneTiles = new Tile[stone != null ? stone.Length : 0];
            for (int i = 0; i < stoneTiles.Length; i++)
            {
                stoneTiles[i] = ScriptableObject.CreateInstance<Tile>();
                stoneTiles[i].sprite = stone[i];
            }
            for (int x = -L; x < W; x++)
            for (int y = 0; y < H; y++)
            {
                var cell = new Vector3Int(x, y, 0);
                bool north = y >= FarmHeight;
                if (!north && x >= 0 && x < FarmWidth && WasGrass(x, y) && _ground[x + L, y] != Ground.Grass) PickGrass();   // the road's new ends
                switch (_ground[x + L, y])
                {
                    case Ground.Stone:
                        if (stoneTiles.Length >= 4)
                        {
                            int r = (north ? northRng : mountainRng).Next(100);
                            ground.SetTile(cell, stoneTiles[r < 50 ? 0 : r < 80 ? 1 : r < 92 ? 2 : 3]);
                        }
                        else ground.SetTile(cell, tiles[FarmDemoConfig.TilePath]);
                        break;
                    case Ground.Water: water.SetTile(cell, tiles[FarmDemoConfig.TileWaterBase + WaterMask(x, y)]); break;
                    case Ground.Soil: ground.SetTile(cell, tiles[FarmDemoConfig.TileSoil]); break;
                    case Ground.Path: ground.SetTile(cell, tiles[FarmDemoConfig.TilePath]); break;
                    default: ground.SetTile(cell, tiles[north ? MeadowGrass(northRng) : x >= 0 && x < FarmWidth ? PickGrass() : VillageGrass(villageRng, y)]); break;
                }
            }

            // South of it all, the forest floor: shadier, on its own map so it can be tinted. Stone under the mountain.
            var forest = _forestMap = NewTilemap(grid.transform, "Forest floor", GroundOrder);
            forest.color = new Color(0.84f, 0.9f, 0.84f);
            var forestRng = new System.Random(19);
            for (int x = -L; x < W; x++)
            for (int y = FarmDemoConfig.MapBottom; y < 0; y++)
            {
                var cell = new Vector3Int(x, y, 0);
                if (x < 0 && stoneTiles.Length >= 4) forest.SetTile(cell, stoneTiles[forestRng.Next(100) < 70 ? 0 : 1]);
                else if (Forest.IsTrail(x, y)) forest.SetTile(cell, tiles[FarmDemoConfig.TilePath]);
                else forest.SetTile(cell, tiles[VillageGrass(forestRng, 20)]);
            }
        }

        // The road used to stop two tiles short of the farm's east edge; it runs on to the village now.
        // The same goes for its west end, which now runs on through the trees to the mountain.
        // The north path used to stop short of the trees too; it runs on to the meadow now.
        bool WasGrass(int x, int y) => _ground[x + L, y] == Ground.Grass || ((y == 11 || y == 12) && ((x >= FarmWidth - 2 && x < FarmWidth) || x <= 1))
            || ((x == 23 || x == 24) && y >= FarmHeight - 2 && y < FarmHeight);

        /// <summary>The meadow's lake, north-west of the path, and its size (half-widths).</summary>
        static readonly Vector2 MeadowPond = new Vector2(12f, 38.5f);
        static readonly Vector2 LakeSize = new Vector2(9.5f, 5.2f);

        /// <summary>In the lake (grown by a margin)? The island counts as lake: nothing else goes on it.</summary>
        static bool InLake(Vector2 at, float margin)
        {
            float px = (at.x - MeadowPond.x) / (LakeSize.x + margin), py = (at.y - MeadowPond.y) / (LakeSize.y + margin);
            return px * px + py * py <= 1f;
        }

        // North of the farm: the meadow (grass, a lake with the Aspidochelone's island in it, the end of the
        // path), with stone above the mountain.
        static Ground NorthGround(int x, int y)
        {
            if (x < 0) return Ground.Stone;
            if (x >= FarmWidth) return Ground.Grass;
            var cell = new Vector2(x + 0.5f, y + 0.5f);
            if (Aspidochelone.OnIsland(cell, 0f)) return Ground.Grass;
            if (InLake(cell, 0f)) return Ground.Water;
            if ((x == 23 || x == 24) && y <= FarmHeight + 2) return Ground.Path;
            return Ground.Grass;
        }

        // Meadow lawns: wildflowers everywhere.
        static int MeadowGrass(System.Random rng)
        {
            int r = rng.Next(100);
            if (r < 16) return r % 2 == 0 ? FarmDemoConfig.TileFlowersWhite : FarmDemoConfig.TileFlowersPink;
            if (r < 50) return FarmDemoConfig.TileGrassA;
            if (r < 75) return FarmDemoConfig.TileGrassB;
            return r < 88 ? FarmDemoConfig.TileGrassC : FarmDemoConfig.TileGrassD;
        }

        // The mountain: stony ground, the road, and paths up to the three caves in the cliff.
        static Ground MountainGround(int x, int y)
        {
            if ((y == 11 || y == 12) && x >= -21) return Ground.Path;
            if (y >= 13 && y <= 21 && (x == Mine.Mouth.x - 1 || x == Mine.Mouth.x || x == Cavern.Mouth.x - 1 || x == Cavern.Mouth.x || x == DarkCave.Mouth.x - 1 || x == DarkCave.Mouth.x)) return Ground.Path;
            return Ground.Stone;
        }

        // Village lawns: more flowers, especially in the meadow south of the road.
        static int VillageGrass(System.Random rng, int y)
        {
            int r = rng.Next(100), flowers = y < 11 ? 22 : 10;
            if (r < flowers) return r % 2 == 0 ? FarmDemoConfig.TileFlowersWhite : FarmDemoConfig.TileFlowersPink;
            if (r < 55) return FarmDemoConfig.TileGrassA;
            if (r < 80) return FarmDemoConfig.TileGrassB;
            return r < 90 ? FarmDemoConfig.TileGrassC : FarmDemoConfig.TileGrassD;
        }

        static Tilemap NewTilemap(Transform parent, string name, int order)
        {
            var go = new GameObject(name, typeof(Tilemap), typeof(TilemapRenderer));
            go.transform.SetParent(parent, false);
            go.GetComponent<TilemapRenderer>().sortingOrder = order;
            return go.GetComponent<Tilemap>();
        }

        int WaterMask(int x, int y)
        {
            int mask = 0;
            if (!IsWater(x, y + 1)) mask |= 1;
            if (!IsWater(x + 1, y)) mask |= 2;
            if (!IsWater(x, y - 1)) mask |= 4;
            if (!IsWater(x - 1, y)) mask |= 8;
            return mask;
        }

        bool IsWater(int x, int y) =>
            x + L >= 0 && y >= 0 && x + L < _ground.GetLength(0) && y < _ground.GetLength(1) && _ground[x + L, y] == Ground.Water;

        int PickGrass()
        {
            int r = _rng.Next(100);
            if (r < 45) return FarmDemoConfig.TileGrassA;
            if (r < 75) return FarmDemoConfig.TileGrassB;
            if (r < 85) return FarmDemoConfig.TileGrassC;
            if (r < 95) return FarmDemoConfig.TileGrassD;
            return r < 98 ? FarmDemoConfig.TileFlowersWhite : FarmDemoConfig.TileFlowersPink;
        }

        void BuildBorder()
        {
            int W = FarmDemoConfig.MapWidth, H = FarmDemoConfig.MapHeight, F = FarmHeight;
            var tree = LoadProp("tree");
            var parent = new GameObject("Border").transform;
            parent.SetParent(transform, false);

            // A ring of trees for looks...
            for (int x = 1 - L; x < W; x += 2)
            {
                // The south edge, open where the lane goes on into the forest.
                if (x != Town.ForestLaneX && x != Town.ForestLaneX + 2) Foliage(PlaceProp(parent, tree, new Vector2(x, 0f), new Vector2(0.5f, 0.3f)), "tree");
                Foliage(PlaceProp(parent, tree, new Vector2(x, H - 2f), new Vector2(0.5f, 0.3f)), "tree");
                // The farm's old north edge, open where the path goes on up to the meadow.
                if (x != 23 && x != 25) Foliage(PlaceProp(parent, tree, new Vector2(x, F - 2f), new Vector2(0.5f, 0.3f)), "tree");
            }
            for (int y = 2; y < H - 2; y += 2)
            {
                if (y == F - 2) continue;      // that row's already planted
                Foliage(PlaceProp(parent, tree, new Vector2(1f - L, y), new Vector2(0.5f, 0.3f)), "tree");
                Foliage(PlaceProp(parent, tree, new Vector2(W - 1f, y), new Vector2(0.5f, 0.3f)), "tree");
                // The old west edge of the farm is a line of trees now, open where the road goes up to the mountain.
                if (y < 9 || y > 13) Foliage(PlaceProp(parent, tree, new Vector2(1f, y), new Vector2(0.5f, 0.3f)), "tree");
                // A line of trees between the farm and the village, open where the road runs through.
                if (y < 9 || y > 13) Foliage(PlaceProp(parent, tree, new Vector2(FarmWidth - 1f, y), new Vector2(0.5f, 0.3f)), "tree");
            }

            // ...and invisible walls so nothing can leave the map.
            float gate = Town.ForestLaneX, gateEnd = Town.ForestLaneX + 2;
            AddWall(parent, new Vector2((-L - 1f + gate) / 2f, 0.1f), new Vector2(gate + L + 1f, 2.2f));
            AddWall(parent, new Vector2((gateEnd + W + 1f) / 2f, 0.1f), new Vector2(W + 1f - gateEnd, 2.2f));
            AddWall(parent, new Vector2((W - L) / 2f, H - 1.5f), new Vector2(W + L + 2f, 1f));
            AddWall(parent, new Vector2((-L - 1f + 22.5f) / 2f, F - 1.5f), new Vector2(22.5f + L + 1f, 1f));
            AddWall(parent, new Vector2((25.5f + W + 1f) / 2f, F - 1.5f), new Vector2(W + 1f - 25.5f, 1f));
            AddWall(parent, new Vector2(1f - L, H / 2f), new Vector2(1f, H + 2f));
            AddWall(parent, new Vector2(1f, 4.25f), new Vector2(1f, 10.5f));
            AddWall(parent, new Vector2(1f, (14.5f + H + 1f) / 2f), new Vector2(1f, H + 1f - 14.5f));
            AddWall(parent, new Vector2(W - 1f, H / 2f), new Vector2(1f, H + 2f));
            AddWall(parent, new Vector2(FarmWidth - 1f, 4.25f), new Vector2(1f, 10.5f));
            AddWall(parent, new Vector2(FarmWidth - 1f, (14.5f + H + 1f) / 2f), new Vector2(1f, H + 1f - 14.5f));
        }

        static void AddWall(Transform parent, Vector2 center, Vector2 size)
        {
            var go = new GameObject("Wall");
            go.transform.SetParent(parent, false);
            go.transform.position = center;
            go.AddComponent<BoxCollider2D>().size = size;
            Tall(go);
        }

        void ScatterProps()
        {
            var props = new[] { ("tree", new Vector2(0.5f, 0.3f), 2),
                                ("rock", new Vector2(0.8f, 0.45f), 1),
                                ("bush", new Vector2(0.8f, 0.45f), 1) };
            var parent = new GameObject("Props").transform;
            parent.SetParent(transform, false);

            int W = FarmWidth, H = FarmHeight;
            var spawn = new Vector2Int(24, 12);
            for (int attempt = 0, placed = 0; attempt < 400 && placed < 45; attempt++)
            {
                int x = _rng.Next(3, W - 3), y = _rng.Next(2, H - 4);
                var (art, collider, radius) = props[_rng.Next(10) < 5 ? 0 : _rng.Next(1, 3)];
                if (Mathf.Abs(x - spawn.x) < 4 && Mathf.Abs(y - spawn.y) < 4) continue;
                if (!AreaIsOpenGrass(x, y, radius)) continue;

                var prop = PlaceProp(parent, LoadProp(art), new Vector2(x + 0.5f, y + 0.1f), collider);
                if (art != "rock") Foliage(prop, art);
                if (art == "tree" && prop != null) prop.gameObject.AddComponent<ChoppableTree>().Cell = new Vector2Int(x, y);
                if (art != "tree" && prop != null) Wilds.Register(prop.gameObject, art == "rock" ? WildProp.Kind.Rock : WildProp.Kind.Bush, new Vector2Int(x, y));
                for (int dx = -radius; dx <= radius; dx++)
                for (int dy = -radius; dy <= radius; dy++)
                    _blocked.Add(new Vector2Int(x + dx, y + dy));
                placed++;
            }
        }

        bool AreaIsOpenGrass(int x, int y, int radius)
        {
            for (int dx = -radius; dx <= radius; dx++)
            for (int dy = -radius; dy <= radius + 1; dy++)
            {
                int cx = x + dx, cy = y + dy;
                if (cx < 0 || cy < 0 || cx + L >= _ground.GetLength(0) || cy >= _ground.GetLength(1)) return false;
                if (!WasGrass(cx, cy) || _blocked.Contains(new Vector2Int(cx, cy))) return false;
            }
            return true;
        }

        void Foliage(SpriteRenderer renderer, string art)
        {
            if (renderer != null) _foliage.Add((renderer, art));
        }

        /// <summary>Props too tall to fly over on the blimp bee.</summary>
        static readonly string[] TallArt = { "tree", "pine", "bakery", "cottage", "lamp", "cliff", "fruittree", "standingstone" };

        static SpriteRenderer PlaceProp(Transform parent, Sprite sprite, Vector2 position, Vector2 colliderSize)
        {
            if (sprite == null) return null;
            var go = new GameObject(sprite.texture.name);
            go.transform.SetParent(parent, false);
            go.transform.position = position;
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            go.AddComponent<YSort>();
            var box = go.AddComponent<BoxCollider2D>(); // only the base is solid, so you can walk "behind" the top
            box.size = colliderSize;
            box.offset = new Vector2(0f, colliderSize.y * 0.5f);
            if (System.Array.IndexOf(TallArt, go.name) >= 0) Tall(go);
            return sr;
        }

        // ------------------------------------------------------------- pots, villagers, slimes

        void PlacePots()
        {
            _potSprite = LoadProp("pot");
            _potBrokenSprite = LoadProp("pot_broken");
            _potParent = new GameObject("Pots").transform;
            _potParent.SetParent(transform, false);

            // A cluster by Grandpa, a couple by the crossroads, a few more by the field and pond.
            Vector2[] spots =
            {
                new Vector2(14.5f, 14.2f), new Vector2(15.5f, 14.2f), new Vector2(15.0f, 15.1f),
                new Vector2(27.5f, 9.3f), new Vector2(28.5f, 9.3f),
                new Vector2(16.5f, 17.2f), new Vector2(26.5f, 9.3f), new Vector2(43.5f, 15.2f),
            };
            foreach (var spot in spots)
            {
                _pots.Add((spot, SpawnPot(spot)));
                Reserve(spot, 1);
            }
        }

        GameObject SpawnPot(Vector2 spot)
        {
            var go = new GameObject("Pot");
            go.transform.SetParent(_potParent, false);
            go.transform.position = spot;
            go.AddComponent<SpriteRenderer>().sprite = _potSprite;
            go.AddComponent<YSort>();
            var box = go.AddComponent<BoxCollider2D>();
            box.size = new Vector2(0.7f, 0.45f);
            box.offset = new Vector2(0f, 0.22f);
            go.AddComponent<Pot>().brokenSprite = _potBrokenSprite;
            return go;
        }

        // Smashed pots are back every morning. (Someone in this village really likes pots.)
        void RespawnPots()
        {
            for (int i = 0; i < _pots.Count; i++)
                if (_pots[i].pot == null) _pots[i] = (_pots[i].spot, SpawnPot(_pots[i].spot));
        }

        void OnDestroy()
        {
            GameClock.NewDay -= RespawnPots;
            GameClock.NewDay -= ShowSeason;
            GameClock.NewDay -= GrowGrass;
        }

        void PlaceNpcs()
        {
            var prompt = Art.Single("key_e", new Vector2(0.5f, 0f));
            var parent = new GameObject("Villagers").transform;
            parent.SetParent(transform, false);

            // What each villager likes to be given, and their thank-you at five hearts.
            Friendship.Reset();
            Friendship.Add("Grandpa Turnip", new[] { Items.Turnip, Items.Pumpkin, Items.TurnipSoup, Items.Cheese, Items.HoneyCake }, new[] { Items.Honey, Items.Carrot, Items.Strawberry, Items.Egg, Items.LargeEgg, Items.Tomato, Items.Lavender },
                new[] { Items.OldBoot, Items.Carp }, "Plant these come fall. Biggest pumpkins in the valley, I promise.", Items.PumpkinSeeds, 4);
            Friendship.Add("Mabel the Baker", new[] { Items.GoldenTrout, Items.LargeEgg, Items.Strawberry, Items.StrawberryJam, Items.Truffle }, new[] { Items.Egg, Items.Milk, Items.Corn, Items.Pumpkin, Items.Tomato, Items.Tulip },
                new[] { Items.OldBoot }, "A little something from the bakery till. You've earned it, sweetie.", rewardGold: 300);
            Friendship.Add("Pip", new[] { Items.OldBoot, Items.Tomato, Items.FishStew, Items.Melon, Items.Honey, Items.Sunflower }, new[] { Items.Bluegill, Items.Carp, Items.Egg },
                new[] { Items.Turnip }, "Found this in the trench coat. Don't ask which raccoon had it.", Items.GoldenTrout);
            Friendship.Add("Dot the Miner", new[] { Items.Gem, Items.Pumpkin, Items.PumpkinPie, Items.Truffle }, new[] { Items.Egg, Items.LargeEgg, Items.Tomato, Items.Carp },
                new[] { Items.Strawberry }, "Found these way down deep. Don't tell the others how far I go.", Items.Gem, 3);
            Friendship.Add("Old Gil", new[] { Items.GoldenTrout, Items.Carp, Items.FishStew, Items.GoatCheese }, new[] { Items.Bluegill, Items.Pumpkin },
                new[] { Items.OldBoot, Items.Strawberry }, "My prize money from the '72 fishing derby. Buy yourself a better hat.", rewardGold: 250);

            // Grandpa Turnip starts you off with some seeds.
            var grandpa = AddNpc(parent, "npc_grandpa", "Grandpa Turnip", new Vector2(12.5f, 15.6f), prompt, null);
            if (grandpa != null)
            {
                grandpa.SetScript(
                    () => _grandpaGaveSeeds
                        ? new[]
                        {
                            "Crops only grow on nights after you water them. Fill your can at the pond.",
                            "Want a bigger field? Pick your hoe and dig up some grass.",
                            "Your bed's in the house next door. Or stay up till 2 AM and pass out like I do.",
                            "Follow the road east past the trees. There's a little village: Mabel's bakery, Pip, and the notice board.",
                            "The village has grown into a proper town round the fountain. Seeds, flowers, livestock, a blacksmith, the lot. Shops open around nine.",
                            "Take the lane south from the town square, past the workshops. There's a forest down there, and folk with wings, they say.",
                            "Hazel in her greenhouse on the square sells fruit trees. Plant one and you'll have cherries or apples for years.",
                            "Chopped a tree down? Keep swinging at the stump and you'll have it out of the ground.",
                            "West of the farm the road climbs into the mountains. Dot's mine is up there now, and another cave besides.",
                            "Take the path north past the trees. There's a meadow of long grass up there, and a bee the size of a sheep. Shy thing.",
                            "Those little bushes about the place? Snip them with your shears if they're in the way. Rocks, take a pickaxe to.",
                            "Trees in the way? Take the axe to them. Good wood makes a good chest.",
                            "That hen by your house lays an egg every morning, as long as her trough has feed. Pet her, too.",
                            "Turnips grow in spring and fall. Come winter, nothing grows at all.",
                            "There's a stove in your kitchen. Two turnips make a soup that'd warm a snowman. Pick food and press F to eat it.",
                            "I've been growing this beard since 1962. Still my best crop.",
                        }
                        : new[]
                        {
                            "Back in my day we didn't have slimes. We had regular jelly, and we were grateful.",
                            "That field up there is going to waste. Here, take some turnip seeds.",
                            "Pick them on your item bar, face the dirt, and press F. Then water them every day.",
                        },
                    () =>
                    {
                        if (_grandpaGaveSeeds) return;
                        if (!Inventory.Add(Items.TurnipSeeds, 5)) { Hud.Toast("Your bag is full!"); return; }
                        _grandpaGaveSeeds = true;
                        Inventory.Select(SlotOf(Items.TurnipSeeds));
                        Hud.ShowPopup(Items.TurnipSeeds.Icon, "You got 5 Turnip Seeds!",
                            "Face a dirt tile in the field and press F to plant. Water them, sleep, and they grow.");
                    });
            }

            // Mabel and Pip walk to work each morning now: the town sets them going (see Town).
            Reserve(new Vector2(32.5f, 16.6f), 1);   // where Mabel used to stand, so the farm keeps its trees where they were
            _mabel = AddNpc(parent, "npc_mabel", "Mabel the Baker", new Vector2(55.9f, 13.6f), prompt, null);
            Reserve(new Vector2(17.5f, 6.6f), 1);    // Pip's old spot on the farm
            _pip = AddNpc(parent, "npc_pip", "Pip", new Vector2(67.9f, 13.6f), prompt, new[]
            {
                "Psst. Don't tell anyone, but I'm actually three raccoons in a trench coat.",
                "The hat is real though. The hat is very real.",
                "That's my cottage. All three of us sleep in the one bed. It's fine.",
                "I don't have a job. I have the fountain. I watch it all day so it doesn't run off.",
            });

            // Dot the Miner lends you a pickaxe for the mine.
            Reserve(new Vector2(20.6f, 26.4f), 1);   // Dot's old spot on the farm
            var dot = AddNpc(parent, "npc_miner", "Dot the Miner", Mine.Mouth + new Vector2(2.6f, -0.6f), prompt, null);
            if (dot != null)
            {
                string[][] chat =
                {
                    new[] { "Every fifth floor, I'll remember how deep you got. Next time you can start from there." },
                    new[] { "See that workbench by your house? Bring it ore and it'll make you sprinklers. Ingrid in town forges better tools." },
                    new[] { "Copper's orange, iron's pinkish, and gems... you'll know a gem when you see one." },
                    new[] { "Feeling woozy down there? Pick some food and press F to eat it." },
                    new[] { "If you faint, I'll haul you out. Happens to the best of us." },
                    new[] { "The slimes get meaner the deeper you go. Green ones, blue ones... I don't talk about the red ones." },
                    new[] { "See the other cave, along the cliff? No ladders in that one. Just tunnels, crystals and a lot of echo." },
                    new[] { "Somebody hid a chest in the crystal cave years ago. Never found it. Too many dead ends for my knees." },
                    new[] { "Met the Red Cap yet? Little fellow, big hat. Knows every critter on this mountain." },
                };
                int next = 0;
                dot.SetScript(
                    () => Inventory.Has(Items.Pickaxe)
                        ? chat[next++ % chat.Length]
                        : new[]
                        {
                            "Hiya! I'm Dot. I dig.",
                            "That cave goes down and down. Rocks, ore, gems... and slimes. Lots of slimes.",
                            "You look like you could swing a pickaxe. Here, take my spare!",
                        },
                    () =>
                    {
                        if (Inventory.Has(Items.Pickaxe)) return;
                        if (!Inventory.Add(Items.Pickaxe)) { Hud.Toast("Your bag is full!"); return; }
                        Toolbelt.Pick(Items.Pickaxe);
                        Hud.ShowPopup(Items.Pickaxe.Icon, "You got a Pickaxe!",
                            "It's on your tool dial. Go into the cave, face a rock and press F to break it. One rock on every floor hides the ladder down.");
                    });
            }

            // The Red Cap, a gnome in the mountains who knows all about creatures.
            var redCap = AddNpc(parent, "npc_redcap", "Red Cap", new Vector2(-5.2f, 17.4f), prompt, null);
            if (redCap != null)
            {
                string[][] tips =
                {
                    new[] { "Hoo! A visitor. I'm a Red Cap. The hat is red. The rest of me is mostly beard." },
                    new[] { "Feed a jackalope wild berries and it will become your friend." },
                    new[] { "Bond with a cannonball turtle by gathering gems for it. Three, it likes. Hand them over while it's walking, mind, not rolling." },
                    new[] { "The blimp bee in the north meadow is shy. But lay lavender on its flat rock and it'll come down to land." },
                    new[] { "A landed blimp bee with a belly full of honey will let you ride it. Over ponds, rocks and hedges! Not trees, though. Never trees." },
                    new[] { "Only one creature can follow you at a time. Choose who comes along in your bag, under Creatures." },
                    new[] { "Gems turn up deep in Dot's mine. The turtle can smell them, I swear it." },
                };
                int next = 0;
                redCap.SetScript(() => tips[next++ % tips.Length], null);
            }

            // Old Gil hands you his fishing rod the first time you chat.
            var gil = AddNpc(parent, "npc_fisher", "Old Gil", new Vector2(40.5f, 18.4f), prompt, null);
            if (gil != null)
            {
                gil.SetScript(
                    () => Inventory.Has(Items.FishingRod)
                        ? new[]
                        {
                            "Turn your tool dial to the rod, face the water and press F. When you see the \"!\", press F again. Quick!",
                            "I once caught a fish so big, I had to let it go. Out of respect.",
                        }
                        : new[]
                        {
                            "Name's Gil. Been fishing this pond for forty years.",
                            "Caught mostly boots. Seven boots. None of them match.",
                            "My back's done for. Here, you take my old rod!",
                        },
                    () =>
                    {
                        if (Inventory.Has(Items.FishingRod)) return;
                        if (!Inventory.Add(Items.FishingRod)) { Hud.Toast("Your bag is full!"); return; }
                        Toolbelt.Pick(Items.FishingRod);
                        Hud.ShowPopup(Items.FishingRod.Icon, "You got a Fishing Rod!",
                            "It's on your tool dial. Face the pond and press F to cast. When the ! pops up, press F again.");
                    });
            }
        }

        static int SlotOf(ItemDef item)
        {
            for (int i = 0; i < Inventory.SlotCount; i++)
                if (Inventory.All[i] != null && Inventory.All[i].Item == item) return i;
            return Inventory.Selected;
        }

        Npc AddNpc(Transform parent, string sheet, string name, Vector2 position, Sprite prompt, string[] lines)
        {
            var frames = Art.Directional(sheet, FarmDemoConfig.CharacterFrameWidth, FarmDemoConfig.CharacterFrameHeight);
            if (frames == null) return null;

            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.position = position;
            AddShadow(go.transform, 1f);
            go.AddComponent<SpriteRenderer>();
            go.AddComponent<YSort>();
            var box = go.AddComponent<BoxCollider2D>();    // solid, so you bump into them
            box.size = new Vector2(0.6f, 0.3f);
            box.offset = new Vector2(0f, 0.15f);
            var npc = go.AddComponent<Npc>();
            npc.Init(name, lines, frames, prompt);
            Reserve(position, 1);
            return npc;
        }

        void PlaceHouse()
        {
            var home = new GameObject("Home").AddComponent<Home>();
            home.transform.SetParent(transform, false);
            home.Build(home.transform);
            Reserve(Home.DoorOutside + new Vector2(0f, 1.5f), 3);
        }

        void PlaceQuestBoard()
        {
            var board = new GameObject("Quests").AddComponent<QuestBoard>();
            board.transform.SetParent(transform, false);
            board.Build(board.transform);
            Reserve(new Vector2(21.6f, 13.1f), 1);   // where the board stood on the farm
        }

        /// <summary>The village east of the farm: the square with its fountain, Mabel's bakery and Pip's cottage. The rest of the town is in Town.</summary>
        void PlaceVillage()
        {
            var parent = new GameObject("Village").transform;
            parent.SetParent(transform, false);

            PlaceProp(parent, LoadProp("bakery"), Town.BakeryDoor, new Vector2(3.7f, 1.7f));
            PlaceProp(parent, LoadProp("cottage"), Town.PipsDoor, new Vector2(2.7f, 1.4f));
            PlaceProp(parent, LoadProp("fountain"), Town.Fountain, new Vector2(1.7f, 0.8f));
            PlaceProp(parent, LoadProp("signpost"), new Vector2(49.6f, 13.8f), new Vector2(0.3f, 0.25f));

            // Trees about the town, for looks and for wood.
            var tree = LoadProp("tree");
            foreach (var c in Town.TreeSpots())
            {
                var sr = PlaceProp(parent, tree, new Vector2(c.x + 0.5f, c.y + 0.1f), new Vector2(0.5f, 0.3f));
                Foliage(sr, "tree");
                if (sr != null) sr.gameObject.AddComponent<ChoppableTree>().Cell = c;
            }
            var bush = LoadProp("bush");
            foreach (var at in new[] { new Vector2(59.4f, 16.1f), new Vector2(81.5f, 17.1f), new Vector2(66.5f, 8.1f), new Vector2(77.5f, 8.1f) })
            {
                var sr = PlaceProp(parent, bush, at, new Vector2(0.8f, 0.45f));
                Foliage(sr, "bush");
                if (sr != null) Wilds.Register(sr.gameObject, WildProp.Kind.Bush, Vector2Int.FloorToInt(at));
            }

            // Wild berry bushes up behind Mabel's and Pip's, where the jackalope lives.
            var j = Town.JackalopeHome;
            foreach (var at in new[] { j + new Vector2(-3f, -0.1f), j + new Vector2(2f, -0.6f), j + new Vector2(-1f, 1.4f), j + new Vector2(3f, 1.2f) })
                Wilds.AddBerryBush(parent, at);
        }

        /// <summary>The forest south of town: thick woods, a winding trail, and three clearings (see Forest).</summary>
        void PlaceForest()
        {
            var parent = new GameObject("Forest").transform;
            parent.SetParent(transform, false);
            var rng = new System.Random(31);

            // Trees everywhere you can't walk, and an invisible hedge of tiles so you can't slip between them.
            var forestTree = LoadProp("foresttree");
            var tree = LoadProp("tree");
            var pine = LoadProp("pine");
            foreach (var at in Forest.TreeSpots(-L, FarmDemoConfig.MapWidth, FarmDemoConfig.MapBottom))
            {
                int r = rng.Next(10);
                string art = at.x < 0 || r < 2 ? "pine" : r < 7 ? "foresttree" : "tree";
                var sr = Deco(parent, art == "pine" ? pine : art == "tree" ? tree : forestTree, at);
                if (art != "pine") Foliage(sr, art);
            }
            var hedge = new GameObject("Forest (solid)", typeof(Tilemap), typeof(TilemapCollider2D));
            hedge.transform.SetParent(_groundMap.transform.parent, false);
            Tall(hedge);
            var map = hedge.GetComponent<Tilemap>();
            var solid = ScriptableObject.CreateInstance<Tile>();
            solid.sprite = _tiles[FarmDemoConfig.TilePath].sprite;
            solid.colliderType = Tile.ColliderType.Grid;
            for (int x = Forest.Left; x <= Forest.Right; x++)
            for (int y = FarmDemoConfig.MapBottom; y < 0; y++)
                if (!Forest.IsOpen(x, y)) map.SetTile(new Vector3Int(x, y, 0), solid);

            // The clearings: ferns and toadstools here and there.
            var fern = LoadProp("fern");
            var toadstool = LoadProp("toadstool");
            foreach (var (at, size) in Forest.Groves)
                for (int i = 0; i < 9; i++)
                {
                    float a = (float)rng.NextDouble() * Mathf.PI * 2f, d = 0.75f + (float)rng.NextDouble() * 0.2f;
                    var p = at + new Vector2(Mathf.Cos(a) * size.x * d, Mathf.Sin(a) * size.y * d);
                    if (Forest.IsTrail(Mathf.FloorToInt(p.x), Mathf.FloorToInt(p.y))) continue;
                    Foliage(Deco(parent, i % 3 == 0 ? toadstool : fern, p), i % 3 == 0 ? "toadstool" : "fern");
                }

            // The Ventara's huts, and the Ventara, who has heard things.
            var huts = Forest.Huts;
            for (int i = 0; i < 3; i++)
            {
                var spot = huts + (i == 0 ? new Vector2(-4.5f, 2.4f) : i == 1 ? new Vector2(-2.5f, -3.4f) : new Vector2(4.5f, -2.8f));
                var sr = PlaceProp(parent, LoadProp($"hut{i}"), spot, new Vector2(1.6f, 0.6f));
                if (sr != null) Tall(sr.gameObject);
            }
            var ventara = AddNpc(parent, "npc_ventara", "Ventara", huts + new Vector2(0.5f, -0.6f), Art.Single("key_e", new Vector2(0.5f, 0f)), null);
            if (ventara != null)
            {
                int next = 0;
                var says = Forest.Rumours;
                // The first chat is the hello; after that, a different rumour each time, and every third
                // time (until you've bonded with it) a tip about the Enfield in the great oak.
                ventara.SetScript(() =>
                {
                    int k = next++;
                    if (k == 0) return new[] { says[0] };
                    if (!Enfield.Friend && k % 3 == 1) return new[] { Forest.EnfieldTips[(k / 3) % Forest.EnfieldTips.Length] };
                    return new[] { says[1 + (k - 1) % (says.Length - 1)] };
                }, null);
            }

            // Lark, another Ventara, playing the flute by the huts. Lark will swap it for fruit (see Flute).
            var lark = AddNpc(parent, "npc_ventara_flute", "Lark", huts + new Vector2(3.5f, 1.4f), Art.Single("key_e", new Vector2(0.5f, 0f)), null);
            if (lark != null) lark.SetScript(Flute.LarkSays, null);
            var flute = new GameObject("Flute").AddComponent<Flute>();
            flute.transform.SetParent(transform, false);
            flute.Build(lark != null ? lark.transform : null);

            // The toadstool ring, with standing stones round it and glowing mushrooms in the middle.
            var ring = Forest.Ring;
            for (int i = 0; i < 9; i++)
            {
                float a = i * Mathf.PI * 2f / 9f;
                Deco(parent, toadstool, ring + new Vector2(Mathf.Cos(a) * 2.6f, Mathf.Sin(a) * 1.9f));
            }
            var glow = LoadProp("mushroom");
            Deco(parent, glow, ring + new Vector2(-0.6f, 0.2f));
            Deco(parent, glow, ring + new Vector2(0.7f, -0.3f));
            var stone = LoadProp("standingstone");
            foreach (var at in new[] { new Vector2(82.8f, -6.4f), new Vector2(90.0f, -6.8f), new Vector2(84.6f, -5.6f) })
                PlaceProp(parent, stone, at, new Vector2(0.6f, 0.3f));

            // The great old oak, a fallen log, and berries.
            var oak = PlaceProp(parent, LoadProp("bigoak"), Forest.Oak + new Vector2(0.5f, 0.4f), new Vector2(2.6f, 0.8f));
            if (oak != null) { Tall(oak.gameObject); Foliage(oak, "bigoak"); }
            PlaceProp(parent, LoadProp("log"), new Vector2(100.5f, -18.6f), new Vector2(1.6f, 0.4f));
            foreach (var at in new[] { new Vector2(92.0f, -20.2f), new Vector2(100.3f, -16.0f), new Vector2(99.6f, -20.6f) })
                Wilds.AddBerryBush(parent, at);
        }

        /// <summary>A picture with nothing solid about it (trees deep in the woods, ferns, toadstools).</summary>
        static SpriteRenderer Deco(Transform parent, Sprite sprite, Vector2 position)
        {
            if (sprite == null) return null;
            var go = new GameObject(sprite.texture.name);
            go.transform.SetParent(parent, false);
            go.transform.position = position;
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            go.AddComponent<YSort>();
            return sr;
        }

        void PlaceTown()
        {
            var town = new GameObject("Town").AddComponent<Town>();
            town.transform.SetParent(transform, false);
            town.Build(_mabel, _pip, Art.Single("key_e", new Vector2(0.5f, 0f)));
        }

        void PlaceWorkbench()
        {
            var bench = new GameObject("Crafting").AddComponent<Workbench>();
            bench.transform.SetParent(transform, false);
            bench.Build(bench.transform);
            Reserve(Workbench.Spot, 1);
        }

        void PlaceKitchen()
        {
            var kitchen = new GameObject("Kitchen").AddComponent<Kitchen>();
            kitchen.transform.SetParent(transform, false);
            kitchen.Build(kitchen.transform);
        }

        void PlaceMine()
        {
            var mine = new GameObject("Mine").AddComponent<Mine>();
            mine.transform.SetParent(transform, false);
            mine.Build(mine.transform);
            Reserve(new Vector2(17.5f, 28f), 2);    // where the mine used to be, so the farm keeps its trees where they were
        }

        /// <summary>The mountain west of the farm: a cliff with three caves, pines, boulders and berry bushes.</summary>
        void PlaceMountain()
        {
            var parent = new GameObject("Mountain").transform;
            parent.SetParent(transform, false);

            var cavern = new GameObject("Cavern").AddComponent<Cavern>();
            cavern.transform.SetParent(transform, false);
            cavern.Build(cavern.transform);
            var dark = new GameObject("Dark cave").AddComponent<DarkCave>();
            dark.transform.SetParent(transform, false);
            dark.Build(dark.transform);

            // The cliff: two rows of rock face along the top, with the cave mouths set into it.
            var cliff = LoadProp("cliff");
            for (int row = 0; row < 2; row++)
            for (float x = 1f - L; x < 0f; x += 2f)
            {
                if (row == 0 && (Mathf.Abs(x - Mine.Mouth.x) < 0.5f || Mathf.Abs(x - Cavern.Mouth.x) < 0.5f || Mathf.Abs(x - DarkCave.Mouth.x) < 0.5f)) continue;
                PlaceProp(parent, cliff, new Vector2(x, 22.4f + row * 2.6f), new Vector2(2f, 0.1f));
            }
            AddWall(parent, new Vector2(-L / 2f, 22.7f + (FarmDemoConfig.MapHeight - 22.7f) / 2f), new Vector2(L, FarmDemoConfig.MapHeight - 22.7f));
            // Rock between the caves and the cliff face, so you can't slip behind them.
            foreach (var mouth in new[] { Mine.Mouth, Cavern.Mouth, DarkCave.Mouth })
            {
                AddWall(parent, mouth + new Vector2(-1.9f, 0.5f), new Vector2(0.6f, 0.6f));
                AddWall(parent, mouth + new Vector2(1.9f, 0.5f), new Vector2(0.6f, 0.6f));
            }
            PlaceProp(parent, LoadProp("signpost"), new Vector2(-0.8f, 13.8f), new Vector2(0.3f, 0.25f));

            var pine = LoadProp("pine");
            foreach (var at in new[] { new Vector2(-21.5f, 17.1f), new Vector2(-19.5f, 5.1f), new Vector2(-11.5f, 3.1f), new Vector2(-3.5f, 6.1f),
                                       new Vector2(-22.5f, 8.1f), new Vector2(-9.5f, 16.1f), new Vector2(-2.5f, 18.6f), new Vector2(-13.5f, 7.1f),
                                       new Vector2(-6.5f, 3.1f), new Vector2(-18.5f, 19.6f) })
                PlaceProp(parent, pine, at, new Vector2(0.6f, 0.3f));
            var boulder = LoadProp("boulder");
            foreach (var at in new[] { new Vector2(-19f, 14.2f), new Vector2(-3.6f, 14.6f), new Vector2(-10.2f, 8.4f) })
                PlaceProp(parent, boulder, at, new Vector2(1.6f, 0.6f));
            var rock = LoadProp("rock");
            foreach (var at in new[] { new Vector2(-20.5f, 9.1f), new Vector2(-17.5f, 15.1f), new Vector2(-12.5f, 14.1f), new Vector2(-9.5f, 4.6f),
                                       new Vector2(-4.5f, 9.1f), new Vector2(-1.5f, 16.1f), new Vector2(-13.5f, 19.6f), new Vector2(-22.5f, 13.1f) })
            {
                var sr = PlaceProp(parent, rock, at, new Vector2(0.8f, 0.45f));
                if (sr != null) Wilds.Register(sr.gameObject, WildProp.Kind.Rock, Vector2Int.FloorToInt(at));
            }
            foreach (var at in new[] { new Vector2(-12.5f, 17.1f), new Vector2(-1.5f, 4.1f), new Vector2(-22.5f, 20.1f) })
                Wilds.AddBerryBush(parent, at);

            // The phoenix's nest, ringed by three cold torches.
            var phoenix = new GameObject("Phoenix").AddComponent<Phoenix>();
            phoenix.transform.SetParent(transform, false);
            phoenix.Build(parent);
        }

        /// <summary>Where the blimp bee's flat rock sits in the meadow.</summary>
        static readonly Vector2 FlatRock = new Vector2(35.5f, 38.2f);

        /// <summary>
        /// The meadow north of the farm: long grass, a pond, a few trees, and the blimp
        /// bee's flat rock. Woods fill the land north of the village and the mountain.
        /// </summary>
        void PlaceMeadow()
        {
            var parent = new GameObject("Meadow").transform;
            parent.SetParent(transform, false);
            var rng = new System.Random(17);
            int W = FarmDemoConfig.MapWidth, H = FarmDemoConfig.MapHeight;

            // Deep woods above the village and the mountain, where you can't go.
            var tree = LoadProp("tree");
            for (int x = FarmWidth + 1; x < W - 1; x += 2)
            for (int y = FarmHeight; y < H - 2; y += 2)
                Foliage(PlaceProp(parent, tree, new Vector2(x + (float)rng.NextDouble() * 0.8f - 0.4f, y + (float)rng.NextDouble() * 0.6f), new Vector2(0.5f, 0.3f)), "tree");
            var pine = LoadProp("pine");
            for (int x = 2 - L; x < 0; x += 2)
            for (int y = 28; y < H - 2; y += 2)
                PlaceProp(parent, pine, new Vector2(x + (float)rng.NextDouble() * 0.8f - 0.4f, y + (float)rng.NextDouble() * 0.6f), new Vector2(0.6f, 0.3f));

            // The meadow's trees (choppable), bushes, rocks and berries.
            var taken = new List<Vector2>();
            foreach (var c in new[] { new Vector2Int(4, 33), new Vector2Int(15, 33), new Vector2Int(41, 33), new Vector2Int(30, 35),
                                      new Vector2Int(17, 41), new Vector2Int(29, 42), new Vector2Int(43, 41), new Vector2Int(6, 42) })
            {
                if (InLake(new Vector2(c.x + 0.5f, c.y + 0.5f), 0.8f)) continue;      // the lake grew over it
                var sr = PlaceProp(parent, tree, new Vector2(c.x + 0.5f, c.y + 0.1f), new Vector2(0.5f, 0.3f));
                Foliage(sr, "tree");
                if (sr != null) sr.gameObject.AddComponent<ChoppableTree>().Cell = c;
                taken.Add(new Vector2(c.x + 0.5f, c.y + 0.5f));
            }
            var bush = LoadProp("bush");
            foreach (var at in new[] { new Vector2(19.5f, 36.1f), new Vector2(27.5f, 39.1f), new Vector2(44.5f, 36.1f), new Vector2(12.5f, 34.1f) })
            {
                if (InLake(at, 0.8f)) continue;
                var sr = PlaceProp(parent, bush, at, new Vector2(0.8f, 0.45f));
                Foliage(sr, "bush");
                if (sr != null) Wilds.Register(sr.gameObject, WildProp.Kind.Bush, Vector2Int.FloorToInt(at));
                taken.Add(at);
            }
            var rock = LoadProp("rock");
            foreach (var at in new[] { new Vector2(38.5f, 42.1f), new Vector2(21.5f, 32.6f), new Vector2(9.5f, 42.1f) })
            {
                if (InLake(at, 0.8f)) continue;
                var sr = PlaceProp(parent, rock, at, new Vector2(0.8f, 0.45f));
                if (sr != null) Wilds.Register(sr.gameObject, WildProp.Kind.Rock, Vector2Int.FloorToInt(at));
                taken.Add(at);
            }
            foreach (var at in new[] { new Vector2(3.5f, 37.1f), new Vector2(44.5f, 39.1f), new Vector2(23.5f, 41.1f) })
            {
                if (InLake(at, 0.8f)) continue;
                Wilds.AddBerryBush(parent, at);
                taken.Add(at);
            }
            PlaceProp(parent, LoadProp("flatrock"), FlatRock, new Vector2(1.8f, 0.5f));

            // The island in the lake, which is really an Aspidochelone's back, with a tree growing on it.
            var island = new GameObject("Aspidochelone").AddComponent<Aspidochelone>();
            island.transform.SetParent(parent, false);
            var islandTree = PlaceProp(parent, tree, Aspidochelone.Island + new Vector2(-1.4f, 0.5f), new Vector2(0.5f, 0.3f));
            Foliage(islandTree, "tree");
            island.Build(parent, islandTree != null ? islandTree.transform : null);
            var spells = new GameObject("Spells").AddComponent<Spells>();
            spells.transform.SetParent(transform, false);
            spells.Build();
            PlaceProp(parent, LoadProp("signpost"), new Vector2(25.9f, 33.6f), new Vector2(0.3f, 0.25f));
            taken.Add(new Vector2(25.9f, 33.6f));

            // Long grass everywhere else, swaying in the breeze. You walk right through it.
            var grass = Art.Strip("longgrass", 16, 16);
            if (grass == null) return;
            var sway = parent.gameObject.AddComponent<MeadowSway>();
            sway.Frames = grass;
            for (int attempt = 0, placed = 0; attempt < 900 && placed < 150; attempt++)
            {
                var at = new Vector2(2.6f + (float)rng.NextDouble() * 43f, FarmHeight - 0.3f + (float)rng.NextDouble() * 11.2f);
                if (InLake(at, 1.1f)) continue;                                           // not in the lake
                if (at.x > 22.2f && at.x < 25.8f && at.y < FarmHeight + 3.6f) continue;   // or on the path
                if (Mathf.Abs(at.x - FlatRock.x) < 3.2f && Mathf.Abs(at.y - FlatRock.y - 0.3f) < 1.6f) continue;   // or on the bee's rock
                bool clear = true;
                foreach (var t in taken) if (Vector2.Distance(t, at) < 1f) { clear = false; break; }
                if (!clear) continue;
                var go = new GameObject("Long grass");
                go.transform.SetParent(parent, false);
                go.transform.position = at;
                var sr = go.AddComponent<SpriteRenderer>();
                sr.sprite = grass[0];
                go.AddComponent<YSort>();
                sway.Tufts.Add(sr);
                taken.Add(at + new Vector2(0f, 0.3f));
                placed++;
            }
        }

        void PlaceCoop()
        {
            var animals = new GameObject("Animals").AddComponent<Animals>();
            animals.transform.SetParent(transform, false);
            animals.Build(animals.transform);
            for (int x = 23; x <= 32; x++)
            for (int y = 12; y <= 23; y++)
                _blocked.Add(new Vector2Int(x, y));
        }

        void PlaceBarn()
        {
            var barn = new GameObject("Barn").AddComponent<Barn>();
            barn.transform.SetParent(transform, false);
            barn.Build(barn.transform);
            for (int x = 3; x <= 16; x++)
            for (int y = 2; y <= 10; y++)
                _blocked.Add(new Vector2Int(x, y));
        }

        void PlaceSlimes()
        {
            var frames = Art.Strip("slime", 16, 16);
            if (frames == null) return;
            var parent = new GameObject("Slimes").transform;
            parent.SetParent(transform, false);

            // They live in the south-east meadow, away from where you start.
            Vector2[] homes = { new Vector2(36.5f, 6.5f), new Vector2(41.5f, 9.5f), new Vector2(33.5f, 4.5f), new Vector2(42.5f, 4.5f) };
            foreach (var home in homes)
            {
                SpawnSlime(parent, home, frames);
                Reserve(home, 2);
            }
        }

        /// <summary>A slime that lives around this spot (the meadow ones, and the mine's).</summary>
        public static Slime SpawnSlime(Transform parent, Vector2 home, Sprite[] frames)
        {
            if (frames == null) return null;
            var root = new GameObject("Slime");
            root.transform.SetParent(parent, false);
            root.transform.position = home;
            var body = new GameObject("Sprite");   // first child: Slime looks for its sprite here
            body.transform.SetParent(root.transform, false);
            body.AddComponent<SpriteRenderer>().sprite = frames[0];
            body.AddComponent<YSort>().isStatic = false;
            AddShadow(root.transform, 1.1f);

            var rb = root.AddComponent<Rigidbody2D>();
            rb.gravityScale = 0f;
            rb.constraints = RigidbodyConstraints2D.FreezeRotation;
            rb.interpolation = RigidbodyInterpolation2D.Interpolate;
            var circle = root.AddComponent<CircleCollider2D>();
            circle.radius = 0.32f;
            circle.offset = new Vector2(0f, 0.3f);

            var slime = root.AddComponent<Slime>();
            slime.Init(frames);
            return slime;
        }

        /// <summary>Keeps randomly scattered trees and rocks away from this spot.</summary>
        void Reserve(Vector2 position, int radius)
        {
            int x = Mathf.FloorToInt(position.x), y = Mathf.FloorToInt(position.y);
            for (int dx = -radius; dx <= radius; dx++)
            for (int dy = -radius; dy <= radius + 1; dy++)
                _blocked.Add(new Vector2Int(x + dx, y + dy));
        }

        public static void AddShadow(Transform parent, float scale)
        {
            var shadow = new GameObject("Shadow").AddComponent<SpriteRenderer>();
            shadow.transform.SetParent(parent, false);
            shadow.transform.localPosition = new Vector3(0f, -0.1f, 0f);
            shadow.transform.localScale = new Vector3(scale, scale, 1f);
            shadow.sprite = LoadProp("shadow");
            shadow.sortingOrder = ShadowOrder;
        }

        // ------------------------------------------------------------- player + camera

        Transform BuildPlayer(Sprite[][] frames, Vector2 position)
        {
            var root = new GameObject("Player");
            root.transform.position = position;

            AddShadow(root.transform, 1f);

            var body = new GameObject("Sprite");
            body.transform.SetParent(root.transform, false);
            body.AddComponent<SpriteRenderer>();
            body.AddComponent<SpriteSheetAnimator>().Init(frames);
            body.AddComponent<YSort>().isStatic = false;

            var rb = root.AddComponent<Rigidbody2D>();
            rb.gravityScale = 0f;
            rb.constraints = RigidbodyConstraints2D.FreezeRotation;
            rb.interpolation = RigidbodyInterpolation2D.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;

            var feet = root.AddComponent<CapsuleCollider2D>(); // round feet slide along corners nicely
            feet.direction = CapsuleDirection2D.Horizontal;
            feet.size = new Vector2(0.6f, 0.3f);
            feet.offset = new Vector2(0f, 0.15f);

            root.AddComponent<PlayerController>().Init(Art.Directional("farmer_attack", 32, 32));
            root.AddComponent<FishingController>().Init(Art.Directional("farmer_fish", 32, 32));
            root.AddComponent<FarmingController>();
            return root.transform;
        }

        static void SetUpCamera(Transform player)
        {
            var cam = Camera.main;
            if (cam == null)
            {
                cam = new GameObject("Main Camera", typeof(Camera)).GetComponent<Camera>();
                cam.tag = "MainCamera";
            }
            cam.orthographic = true;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color32(0x2f, 0x7d, 0x3a, 0xff);
            cam.transform.position = new Vector3(player.position.x, player.position.y, -10f);

            var follow = cam.GetComponent<CameraFollow>();
            if (follow == null) follow = cam.gameObject.AddComponent<CameraFollow>();
            follow.target = player;
            follow.bounds = OutdoorBounds;
        }

        // ------------------------------------------------------------- helpers

        static bool SceneIsEmpty()
        {
            foreach (var root in SceneManager.GetActiveScene().GetRootGameObjects())
            {
                bool harmless = root.GetComponent<Camera>() != null || root.GetComponent<Light>() != null;
                foreach (var c in root.GetComponents<Component>())
                {
                    string n = c == null ? "" : c.GetType().Name;
                    if (n == "Light2D" || n == "Volume" || n == "EventSystem") harmless = true;
                }
                if (!harmless) return false;
            }
            return true;
        }

        static T FindAnyObjectByTypeCompat<T>() where T : Object
        {
#if UNITY_2023_1_OR_NEWER
            return FindAnyObjectByType<T>();
#else
            return FindObjectOfType<T>();
#endif
        }
    }

    /// <summary>Makes the meadow's long grass sway, in waves that roll across it.</summary>
    public class MeadowSway : MonoBehaviour
    {
        public Sprite[] Frames;
        public readonly List<SpriteRenderer> Tufts = new List<SpriteRenderer>();

        void Update()
        {
            if (Frames == null || Frames.Length < 2) return;
            float t = Time.time * 1.2f;
            foreach (var sr in Tufts)
            {
                if (sr == null) continue;
                var p = sr.transform.position;
                sr.sprite = Frames[Mathf.FloorToInt(t - p.x * 0.15f + p.y * 0.05f) & 1];
            }
        }
    }
}
